# Chronos-STA vs OpenSTA Detailed Comparison Report

## Summary

- **Total Designs Compared**: 11
- **Chronos Results**: 11
- **OpenSTA Results**: 3
- **Designs with Both Results**: 3

## Detailed Comparison (Common Metrics Only)

### adder_8bit (TT)

| Metric | Chronos-STA | OpenSTA | Difference | Match |
|--------|-------------|---------|------------|-------|
| WNS (Setup) | 0.000000 ns | N/A | N/A | - |
| TNS (Total Negative Slack) | 0.000000 ns | - | - | - |
| WHS/Hold Slack | N/A | N/A | N/A | - |
| Setup Violations | 0 | N/A | - | - |
| Hold Violations | 0 | N/A | - | - |
| Max Path Delay | N/A | N/A | N/A | - |
| Setup Slack | N/A | N/A | N/A | - |
| Runtime | 1.5151 s | N/A | - | - |
| Quality Assessment | MARGINAL | - | - | - |

### dff_logic_dff (TT)

| Metric | Chronos-STA | OpenSTA | Difference | Match |
|--------|-------------|---------|------------|-------|
| WNS (Setup) | 0.000000 ns | N/A | N/A | - |
| TNS (Total Negative Slack) | 0.000000 ns | - | - | - |
| WHS/Hold Slack | 0.150000 ns | N/A | N/A | - |
| Setup Violations | 0 | N/A | - | - |
| Hold Violations | 0 | N/A | - | - |
| Max Path Delay | N/A | N/A | N/A | - |
| Setup Slack | N/A | N/A | N/A | - |
| Runtime | 1.5266 s | N/A | - | - |
| Quality Assessment | MARGINAL | - | - | - |

### inv_chain (TT)

| Metric | Chronos-STA | OpenSTA | Difference | Match |
|--------|-------------|---------|------------|-------|
| WNS (Setup) | 0.000000 ns | 0.000000 ns | 0.000000 ns | ✓ |
| TNS (Total Negative Slack) | 0.000000 ns | - | - | - |
| WHS/Hold Slack | N/A | N/A | N/A | - |
| Setup Violations | 0 | N/A | - | - |
| Hold Violations | 0 | N/A | - | - |
| Max Path Delay | N/A | 0.300000 ns | N/A | - |
| Setup Slack | N/A | 9.500000 ns | N/A | - |
| Clock Period | - | 10.000000 ns | - | - |
| Frequency | - | 100.00 MHz | - | - |
| Runtime | 3.1488 s | N/A | - | - |
| Quality Assessment | MARGINAL | - | - | - |

## Legend

- **✓** - Values match within 0.001 ns tolerance
- **⚠** - Values differ beyond tolerance
- **-** - Cannot compare (data not available)
- **N/A** - Data not available from tool