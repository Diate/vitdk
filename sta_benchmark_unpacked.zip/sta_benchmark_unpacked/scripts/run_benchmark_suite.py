#!/usr/bin/env python3
"""
==============================================================================
STA Benchmark Test Suite
Purpose: Automated testing framework for STA tool validation
==============================================================================
"""

import os
import sys
import json
import subprocess
import time
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from datetime import datetime


@dataclass
class TestCase:
    """Represents a single test case"""
    name: str
    design: str
    verilog: Path
    liberty: Path
    sdc: Path
    spef: Optional[Path] = None
    corner: str = "TT"
    expected_wns: Optional[float] = None
    expected_tns: Optional[float] = None
    tolerance: float = 0.01  # 10ps


@dataclass
class TestResult:
    """Result of a single test case"""
    test_name: str
    passed: bool
    runtime_seconds: float
    memory_mb: float
    actual_wns: Optional[float] = None
    actual_tns: Optional[float] = None
    wns_diff: Optional[float] = None
    error_message: str = ""


@dataclass
class BenchmarkSuite:
    """Collection of test cases and results"""
    name: str
    test_cases: List[TestCase] = field(default_factory=list)
    results: List[TestResult] = field(default_factory=list)
    total_runtime: float = 0.0
    pass_count: int = 0
    fail_count: int = 0


class STABenchmarkRunner:
    """Runs STA benchmarks and collects results"""

    def __init__(self, benchmark_dir: Path, custom_sta_cmd: str = "sta"):
        self.benchmark_dir = benchmark_dir
        self.custom_sta_cmd = custom_sta_cmd
        self.opensta_cmd = "sta"  # OpenSTA command
        self.results_dir = benchmark_dir / "reports"
        self.results_dir.mkdir(exist_ok=True)

    def create_test_suite(self) -> BenchmarkSuite:
        """Create test suite from benchmark directory"""
        suite = BenchmarkSuite(name="STA Validation Suite")

        # Small designs
        small_designs = [
            ("inv_chain", "designs/small/inv_chain.v"),
            ("buf_chain", "designs/small/buf_chain.v"),
            ("dff_logic_dff", "designs/small/dff_logic_dff.v"),
            ("fanout_tree", "designs/small/fanout_tree.v"),
            ("clock_tree", "designs/small/clock_tree.v"),
        ]

        # Medium designs
        medium_designs = [
            ("adder_8bit", "designs/medium/adder_8bit.v"),
            ("multiplier_4x4", "designs/medium/multiplier_4x4.v"),
            ("priority_encoder", "designs/medium/priority_encoder.v"),
            ("shift_register", "designs/medium/shift_register.v"),
        ]

        # Add test cases for TT corner
        for name, verilog_path in small_designs + medium_designs:
            tc = TestCase(
                name=f"{name}_tt",
                design=name,
                verilog=self.benchmark_dir / verilog_path,
                liberty=self.benchmark_dir / "lib/simple_tt.lib",
                sdc=self.benchmark_dir / f"sdc/{name}.sdc",
                spef=self.benchmark_dir / f"spef/{name}.spef",
                corner="TT"
            )
            if tc.verilog.exists() and tc.liberty.exists():
                suite.test_cases.append(tc)

        # Add multi-corner tests for sequential design
        for corner, lib_file in [("SS", "simple_ss.lib"), ("FF", "simple_ff.lib")]:
            tc = TestCase(
                name=f"dff_logic_dff_{corner.lower()}",
                design="dff_logic_dff",
                verilog=self.benchmark_dir / "designs/small/dff_logic_dff.v",
                liberty=self.benchmark_dir / f"lib/{lib_file}",
                sdc=self.benchmark_dir / "sdc/dff_logic_dff.sdc",
                spef=self.benchmark_dir / "spef/dff_logic_dff.spef",
                corner=corner
            )
            if tc.liberty.exists():
                suite.test_cases.append(tc)

        return suite

    def run_opensta(self, test_case: TestCase) -> Dict:
        """Run OpenSTA on test case and return results"""
        # Generate TCL script
        tcl_content = f"""
read_liberty {test_case.liberty}
read_verilog {test_case.verilog}
link_design {test_case.design}
"""
        if test_case.spef and test_case.spef.exists():
            tcl_content += f"read_spef {test_case.spef}\n"

        tcl_content += f"""
read_sdc {test_case.sdc}

# Get worst slack
set worst_path [lindex [get_timing_paths -max_paths 1] 0]
if {{$worst_path ne ""}} {{
    set wns [get_property $worst_path slack]
    puts "WNS: $wns"
}}

set worst_hold [lindex [get_timing_paths -path_delay min -max_paths 1] 0]
if {{$worst_hold ne ""}} {{
    set whs [get_property $worst_hold slack]
    puts "WHS: $whs"
}}

exit
"""

        tcl_file = self.results_dir / f"temp_{test_case.name}.tcl"
        with open(tcl_file, 'w') as f:
            f.write(tcl_content)

        # Run OpenSTA
        start_time = time.time()
        try:
            result = subprocess.run(
                [self.opensta_cmd, str(tcl_file)],
                capture_output=True,
                text=True,
                timeout=300
            )
            runtime = time.time() - start_time

            # Parse output
            wns = None
            whs = None
            for line in result.stdout.split('\n'):
                if line.startswith("WNS:"):
                    wns = float(line.split(":")[1].strip())
                elif line.startswith("WHS:"):
                    whs = float(line.split(":")[1].strip())

            return {
                'success': True,
                'wns': wns,
                'whs': whs,
                'runtime': runtime,
                'stdout': result.stdout,
                'stderr': result.stderr
            }

        except subprocess.TimeoutExpired:
            return {'success': False, 'error': 'Timeout'}
        except Exception as e:
            return {'success': False, 'error': str(e)}
        finally:
            if tcl_file.exists():
                tcl_file.unlink()

    def run_test_case(self, test_case: TestCase) -> TestResult:
        """Run a single test case"""
        print(f"  Running: {test_case.name}...", end=" ", flush=True)

        start_time = time.time()

        # Run OpenSTA first to get reference
        opensta_result = self.run_opensta(test_case)

        if not opensta_result['success']:
            print("SKIP (OpenSTA failed)")
            return TestResult(
                test_name=test_case.name,
                passed=False,
                runtime_seconds=time.time() - start_time,
                memory_mb=0,
                error_message=f"OpenSTA failed: {opensta_result.get('error', 'Unknown')}"
            )

        # Compare results
        actual_wns = opensta_result.get('wns')
        runtime = time.time() - start_time

        # For now, just record OpenSTA results as baseline
        result = TestResult(
            test_name=test_case.name,
            passed=True,  # Baseline always passes
            runtime_seconds=runtime,
            memory_mb=0,  # TODO: measure memory
            actual_wns=actual_wns
        )

        print(f"OK (WNS: {actual_wns:.4f} ns, {runtime:.2f}s)")
        return result

    def run_suite(self, suite: BenchmarkSuite) -> BenchmarkSuite:
        """Run all test cases in suite"""
        print("=" * 60)
        print(f"Running Benchmark Suite: {suite.name}")
        print(f"Test Cases: {len(suite.test_cases)}")
        print("=" * 60)

        start_time = time.time()

        for test_case in suite.test_cases:
            result = self.run_test_case(test_case)
            suite.results.append(result)

            if result.passed:
                suite.pass_count += 1
            else:
                suite.fail_count += 1

        suite.total_runtime = time.time() - start_time

        return suite

    def print_summary(self, suite: BenchmarkSuite):
        """Print test suite summary"""
        print("\n" + "=" * 60)
        print("BENCHMARK SUMMARY")
        print("=" * 60)
        print(f"Total Tests:  {len(suite.results)}")
        print(f"Passed:       {suite.pass_count}")
        print(f"Failed:       {suite.fail_count}")
        print(f"Pass Rate:    {suite.pass_count / len(suite.results) * 100:.1f}%")
        print(f"Total Runtime: {suite.total_runtime:.2f}s")

        print("\n--- Individual Results ---")
        print(f"{'Test Name':<30} {'Status':<8} {'WNS (ns)':<12} {'Runtime (s)':<12}")
        print("-" * 62)

        for result in suite.results:
            status = "PASS" if result.passed else "FAIL"
            wns_str = f"{result.actual_wns:.4f}" if result.actual_wns else "N/A"
            print(f"{result.test_name:<30} {status:<8} {wns_str:<12} {result.runtime_seconds:<12.2f}")

    def export_results(self, suite: BenchmarkSuite, filepath: Path):
        """Export results to JSON"""
        data = {
            'suite_name': suite.name,
            'timestamp': datetime.now().isoformat(),
            'total_tests': len(suite.results),
            'passed': suite.pass_count,
            'failed': suite.fail_count,
            'total_runtime_seconds': suite.total_runtime,
            'results': [
                {
                    'test_name': r.test_name,
                    'passed': r.passed,
                    'runtime_seconds': r.runtime_seconds,
                    'memory_mb': r.memory_mb,
                    'actual_wns': r.actual_wns,
                    'error_message': r.error_message
                }
                for r in suite.results
            ]
        }

        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)

        print(f"\nResults exported to: {filepath}")


def main():
    # Get benchmark directory
    script_dir = Path(__file__).parent
    benchmark_dir = script_dir.parent

    print("STA Benchmark Test Suite")
    print(f"Benchmark Directory: {benchmark_dir}")

    # Create runner
    runner = STABenchmarkRunner(benchmark_dir)

    # Create and run test suite
    suite = runner.create_test_suite()
    suite = runner.run_suite(suite)

    # Print summary
    runner.print_summary(suite)

    # Export results
    results_file = benchmark_dir / "reports" / f"benchmark_results_{datetime.now():%Y%m%d_%H%M%S}.json"
    runner.export_results(suite, results_file)

    # Return exit code
    sys.exit(0 if suite.fail_count == 0 else 1)


if __name__ == "__main__":
    main()
