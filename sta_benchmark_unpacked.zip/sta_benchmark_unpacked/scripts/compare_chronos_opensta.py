#!/usr/bin/env python3
"""
Compare Chronos-STA and OpenSTA benchmark results
Author: Generated for benchmark comparison
Date: 2026-02-12
"""

import json
import os
import re
from pathlib import Path
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
import csv


@dataclass
class TimingResult:
    """Timing result data structure"""
    design: str
    corner: str
    tool: str
    wns: Optional[float] = None
    whs: Optional[float] = None
    tns: Optional[float] = None  # Total Negative Slack
    ths: Optional[float] = None  # Total Hold Slack
    setup_violations: Optional[int] = None
    hold_violations: Optional[int] = None
    total_endpoints: Optional[int] = None
    max_delay: Optional[float] = None
    setup_slack: Optional[float] = None
    hold_slack: Optional[float] = None
    clock_period: Optional[float] = None
    frequency: Optional[float] = None  # MHz
    runtime: Optional[float] = None
    quality_assessment: Optional[str] = None
    success: bool = True
    error: str = ""


class ChronosParser:
    """Parse Chronos benchmark results"""
    
    @staticmethod
    def parse_json(json_path: str) -> List[TimingResult]:
        """Parse Chronos JSON benchmark file"""
        results = []
        
        with open(json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        for result in data.get('results', []):
            wns = result.get('wns')
            whs = result.get('whs')
            
            # Handle Infinity values
            if whs == 'Infinity' or (isinstance(whs, float) and whs == float('inf')):
                whs = None
            
            timing_result = TimingResult(
                design=result.get('design', ''),
                corner=result.get('corner', ''),
                tool='Chronos-STA',
                wns=wns,
                whs=whs,
                runtime=result.get('runtime_seconds'),
                success=result.get('success', True),
                error=result.get('error_message', '')
            )
            results.append(timing_result)
        
        return results
    
    @staticmethod
    def parse_detailed_json(json_path: str, design: str, corner: str) -> Optional[TimingResult]:
        """Parse detailed Chronos timing JSON file"""
        try:
            with open(json_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # Extract timing metrics from the JSON structure
            wns = None
            whs = None
            tns = None
            ths = None
            setup_viol = None
            hold_viol = None
            quality = None
            
            # Look through sections for timing data
            for section in data.get('sections', []):
                if 'TIMING SUMMARY' in section.get('title', ''):
                    tables = section.get('tables', [])
                    if tables:
                        for row in tables[0].get('rows', []):
                            metric = row.get('Metric', '')
                            if metric == 'WNS (ns)':
                                wns_str = row.get('Setup', '')
                                wns = float(wns_str) if wns_str and wns_str != 'inf' else 0.0
                                whs_str = row.get('Hold', '')
                                if whs_str and whs_str != 'inf':
                                    whs = float(whs_str)
                            elif metric == 'TNS (ns)':
                                tns_str = row.get('Setup', '')
                                tns = float(tns_str) if tns_str else None
                                ths_str = row.get('Hold', '')
                                ths = float(ths_str) if ths_str else None
                            elif metric == 'Violations':
                                setup_viol = int(float(row.get('Setup', 0)))
                                hold_viol = int(float(row.get('Hold', 0)))
                
                elif 'TIMING QUALITY' in section.get('title', ''):
                    content = section.get('content', '')
                    # Extract quality assessment
                    match = re.search(r'Quality Assessment:\s*(\w+)', content)
                    if match:
                        quality = match.group(1)
            
            return TimingResult(
                design=design,
                corner=corner,
                tool='Chronos-STA',
                wns=wns,
                whs=whs,
                tns=tns,
                ths=ths,
                setup_violations=setup_viol,
                hold_violations=hold_viol,
                quality_assessment=quality,
                success=True
            )
        except Exception as e:
            return None


class OpenSTAParser:
    """Parse OpenSTA report files"""
    
    @staticmethod
    def parse_report(report_path: str) -> List[TimingResult]:
        """Parse OpenSTA .rpt file"""
        results = []
        
        with open(report_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Extract design name and corner from header
        design_match = re.search(r'Design:\s+(\w+)', content)
        corner_match = re.search(r'Corner:\s+(\w+)', content)
        
        design = design_match.group(1) if design_match else Path(report_path).stem.replace('_opensta', '')
        corner = corner_match.group(1) if corner_match else 'TT'
        
        # Extract timing metrics
        max_delay = None
        setup_slack = None
        hold_slack = None
        clock_period = None
        frequency = None
        
        # Max Path Delay
        delay_match = re.search(r'Max Path Delay:\s+([\d.]+)\s*ns', content)
        if delay_match:
            max_delay = float(delay_match.group(1))
        
        # Setup Slack
        setup_match = re.search(r'Slack \(Setup\):\s+([\d.]+)\s*ns', content)
        if setup_match:
            setup_slack = float(setup_match.group(1))
        
        # Hold Slack
        hold_match = re.search(r'Slack \(Hold\):\s*([>\d.]+)\s*ns', content)
        if hold_match:
            hold_str = hold_match.group(1).strip()
            if hold_str != '>':
                hold_slack = float(hold_str) if hold_str != '> 0' else 0.0
        
        # Clock Period
        clock_match = re.search(r'Clock Period:\s+([\d.]+)\s*ns\s*\(([\d.]+)\s*MHz\)', content)
        if clock_match:
            clock_period = float(clock_match.group(1))
            frequency = float(clock_match.group(2))
        
        # Calculate WNS from setup slack (WNS = negative of slack if setup is violated)
        wns = None
        if setup_slack is not None:
            wns = -setup_slack if setup_slack < 0 else 0.0
        
        timing_result = TimingResult(
            design=design,
            corner=corner,
            tool='OpenSTA',
            wns=wns,
            whs=hold_slack,
            max_delay=max_delay,
            setup_slack=setup_slack,
            hold_slack=hold_slack,
            clock_period=clock_period,
            frequency=frequency,
            success=True
        )
        results.append(timing_result)
        
        return results


class ComparisonReport:
    """Generate comparison report between Chronos and OpenSTA"""
    
    def __init__(self, chronos_results: List[TimingResult], opensta_results: List[TimingResult]):
        self.chronos_results = {(r.design, r.corner): r for r in chronos_results}
        self.opensta_results = {(r.design, r.corner): r for r in opensta_results}
        
        # Get all unique design-corner pairs
        self.all_designs = sorted(set(list(self.chronos_results.keys()) + list(self.opensta_results.keys())))
    
    def generate_text_report(self) -> str:
        """Generate text-based comparison report"""
        report = []
        report.append("=" * 120)
        report.append("CHRONOS-STA vs OpenSTA DETAILED COMPARISON REPORT")
        report.append("=" * 120)
        report.append("")
        
        # Summary statistics
        report.append("SUMMARY")
        report.append("-" * 120)
        report.append(f"Total Designs Compared: {len(self.all_designs)}")
        report.append(f"Chronos Results: {len(self.chronos_results)}")
        report.append(f"OpenSTA Results: {len(self.opensta_results)}")
        
        # Count designs with data from both tools
        both_tools = sum(1 for d in self.all_designs if d in self.chronos_results and d in self.opensta_results)
        report.append(f"Designs with Both Results: {both_tools}")
        report.append("")
        
        # Detailed comparison - only for designs with both results
        report.append("DETAILED COMPARISON (Common Metrics Only)")
        report.append("-" * 120)
        report.append("")
        
        for design, corner in self.all_designs:
            chronos = self.chronos_results.get((design, corner))
            opensta = self.opensta_results.get((design, corner))
            
            # Skip if either tool doesn't have results
            if not chronos or not opensta:
                continue
            
            report.append(f"\n{'='*120}")
            report.append(f"DESIGN: {design} | CORNER: {corner}")
            report.append(f"{'='*120}")
            
            # Create detailed comparison table
            report.append(f"\n{'Metric':<30} | {'Chronos-STA':<25} | {'OpenSTA':<25} | {'Difference':<20} | {'Match':<10}")
            report.append("-" * 120)
            
            # WNS (Worst Negative Slack) - COMMON METRIC
            chronos_wns = chronos.wns if chronos.wns is not None else None
            opensta_wns = opensta.wns if opensta.wns is not None else None
            
            chronos_wns_str = f"{chronos_wns:.6f} ns" if chronos_wns is not None else "N/A"
            opensta_wns_str = f"{opensta_wns:.6f} ns" if opensta_wns is not None else "N/A"
            
            if chronos_wns is not None and opensta_wns is not None:
                diff = abs(chronos_wns - opensta_wns)
                diff_str = f"{diff:.6f} ns ({diff*100:.4f}%)" if opensta_wns != 0 else f"{diff:.6f} ns"
                match = "✓ YES" if diff < 0.001 else "⚠ NO"
            else:
                diff_str = "N/A"
                match = "-"
            
            report.append(f"{'WNS (Setup)':<30} | {chronos_wns_str:<25} | {opensta_wns_str:<25} | {diff_str:<20} | {match:<10}")
            
            # TNS (Total Negative Slack) - if both have it
            if chronos.tns is not None and hasattr(opensta, 'tns') and opensta.tns is not None:
                chronos_tns_str = f"{chronos.tns:.6f} ns"
                opensta_tns_str = f"{opensta.tns:.6f} ns"
                diff = abs(chronos.tns - opensta.tns)
                diff_str = f"{diff:.6f} ns"
                match = "✓ YES" if diff < 0.001 else "⚠ NO"
                report.append(f"{'TNS (Total Negative Slack)':<30} | {chronos_tns_str:<25} | {opensta_tns_str:<25} | {diff_str:<20} | {match:<10}")
            
            # WHS/Hold Slack - COMMON METRIC
            chronos_whs = chronos.whs if chronos.whs is not None else None
            opensta_whs = opensta.hold_slack if opensta.hold_slack is not None else None
            
            chronos_whs_str = f"{chronos_whs:.6f} ns" if chronos_whs is not None else "N/A"
            opensta_whs_str = f"{opensta_whs:.6f} ns" if opensta_whs is not None else "N/A"
            
            if chronos_whs is not None and opensta_whs is not None:
                diff = abs(chronos_whs - opensta_whs)
                diff_str = f"{diff:.6f} ns"
                match = "✓ YES" if diff < 0.001 else "⚠ NO"
            else:
                diff_str = "N/A"
                match = "-"
            
            report.append(f"{'WHS/Hold Slack':<30} | {chronos_whs_str:<25} | {opensta_whs_str:<25} | {diff_str:<20} | {match:<10}")
            
            # Setup Violations - COMMON METRIC
            if chronos.setup_violations is not None:
                chronos_viol_str = f"{chronos.setup_violations}"
            else:
                chronos_viol_str = "N/A"
            opensta_viol_str = "N/A"  # OpenSTA doesn't provide this in current format
            report.append(f"{'Setup Violations':<30} | {chronos_viol_str:<25} | {opensta_viol_str:<25} | {'N/A':<20} | {'-':<10}")
            
            # Hold Violations - COMMON METRIC
            if chronos.hold_violations is not None:
                chronos_hviol_str = f"{chronos.hold_violations}"
            else:
                chronos_hviol_str = "N/A"
            opensta_hviol_str = "N/A"
            report.append(f"{'Hold Violations':<30} | {chronos_hviol_str:<25} | {opensta_hviol_str:<25} | {'N/A':<20} | {'-':<10}")
            
            # Max Path Delay - COMMON METRIC (if available)
            chronos_delay = chronos.max_delay if hasattr(chronos, 'max_delay') and chronos.max_delay is not None else None
            opensta_delay = opensta.max_delay if opensta.max_delay is not None else None
            
            chronos_delay_str = f"{chronos_delay:.6f} ns" if chronos_delay is not None else "N/A"
            opensta_delay_str = f"{opensta_delay:.6f} ns" if opensta_delay is not None else "N/A"
            
            if chronos_delay is not None and opensta_delay is not None:
                diff = abs(chronos_delay - opensta_delay)
                diff_str = f"{diff:.6f} ns"
                match = "✓ YES" if diff < 0.001 else "⚠ NO"
            else:
                diff_str = "N/A"
                match = "-"
            
            report.append(f"{'Max Path Delay':<30} | {chronos_delay_str:<25} | {opensta_delay_str:<25} | {diff_str:<20} | {match:<10}")
            
            # Setup Slack - COMMON METRIC
            chronos_slack = chronos.setup_slack if hasattr(chronos, 'setup_slack') and chronos.setup_slack is not None else None
            opensta_slack = opensta.setup_slack if opensta.setup_slack is not None else None
            
            chronos_slack_str = f"{chronos_slack:.6f} ns" if chronos_slack is not None else "N/A"
            opensta_slack_str = f"{opensta_slack:.6f} ns" if opensta_slack is not None else "N/A"
            
            if chronos_slack is not None and opensta_slack is not None:
                diff = abs(chronos_slack - opensta_slack)
                diff_str = f"{diff:.6f} ns"
                match = "✓ YES" if diff < 0.001 else "⚠ NO"
            else:
                diff_str = "N/A"
                match = "-"
            
            report.append(f"{'Setup Slack':<30} | {chronos_slack_str:<25} | {opensta_slack_str:<25} | {diff_str:<20} | {match:<10}")
            
            report.append("")
        
        report.append("\n" + "=" * 120)
        report.append("LEGEND")
        report.append("-" * 120)
        report.append("✓ YES  - Values match within 0.001 ns tolerance")
        report.append("⚠ NO   - Values differ beyond tolerance")
        report.append("-      - Cannot compare (data not available from one or both tools)")
        report.append("N/A    - Data not available")
        report.append("=" * 120)
        
        return "\n".join(report)
    
    def generate_csv_report(self, output_path: str):
        """Generate CSV comparison report"""
        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            
            # Header
            writer.writerow([
                'Design', 'Corner',
                'Chronos_WNS', 'OpenSTA_WNS', 'WNS_Diff', 'WNS_Match',
                'Chronos_TNS', 'Chronos_Setup_Viol',
                'Chronos_WHS', 'OpenSTA_Hold_Slack', 'Hold_Diff', 'Hold_Match',
                'Chronos_Hold_Viol',
                'Chronos_Max_Delay', 'OpenSTA_Max_Delay', 'Delay_Diff', 'Delay_Match',
                'Chronos_Setup_Slack', 'OpenSTA_Setup_Slack', 'Slack_Diff', 'Slack_Match',
                'OpenSTA_Clock_Period', 'OpenSTA_Frequency',
                'Chronos_Runtime', 'Chronos_Quality'
            ])
            
            # Data rows - only for designs with both results
            for design, corner in self.all_designs:
                chronos = self.chronos_results.get((design, corner))
                opensta = self.opensta_results.get((design, corner))
                
                # Skip if either tool doesn't have results
                if not chronos or not opensta:
                    continue
                
                # WNS
                chronos_wns = chronos.wns if chronos.wns is not None else ''
                opensta_wns = opensta.wns if opensta.wns is not None else ''
                wns_diff = abs(chronos.wns - opensta.wns) if chronos.wns is not None and opensta.wns is not None else ''
                wns_match = 'YES' if isinstance(wns_diff, float) and wns_diff < 0.001 else ('NO' if wns_diff != '' else '')
                
                # TNS
                chronos_tns = chronos.tns if chronos.tns is not None else ''
                chronos_setup_viol = chronos.setup_violations if chronos.setup_violations is not None else ''
                
                # WHS
                chronos_whs = chronos.whs if chronos.whs is not None else ''
                opensta_hold = opensta.hold_slack if opensta.hold_slack is not None else ''
                hold_diff = abs(chronos.whs - opensta.hold_slack) if chronos.whs is not None and opensta.hold_slack is not None else ''
                hold_match = 'YES' if isinstance(hold_diff, float) and hold_diff < 0.001 else ('NO' if hold_diff != '' else '')
                
                chronos_hold_viol = chronos.hold_violations if chronos.hold_violations is not None else ''
                
                # Max Delay
                chronos_delay = chronos.max_delay if hasattr(chronos, 'max_delay') and chronos.max_delay is not None else ''
                opensta_delay = opensta.max_delay if opensta.max_delay is not None else ''
                delay_diff = abs(chronos_delay - opensta_delay) if chronos_delay != '' and opensta_delay != '' else ''
                delay_match = 'YES' if isinstance(delay_diff, float) and delay_diff < 0.001 else ('NO' if delay_diff != '' else '')
                
                # Setup Slack
                chronos_slack = chronos.setup_slack if hasattr(chronos, 'setup_slack') and chronos.setup_slack is not None else ''
                opensta_slack = opensta.setup_slack if opensta.setup_slack is not None else ''
                slack_diff = abs(chronos_slack - opensta_slack) if chronos_slack != '' and opensta_slack != '' else ''
                slack_match = 'YES' if isinstance(slack_diff, float) and slack_diff < 0.001 else ('NO' if slack_diff != '' else '')
                
                # Clock
                opensta_clk = opensta.clock_period if opensta.clock_period is not None else ''
                opensta_freq = opensta.frequency if opensta.frequency is not None else ''
                
                # Runtime and Quality
                chronos_runtime = chronos.runtime if chronos.runtime is not None else ''
                chronos_quality = chronos.quality_assessment if chronos.quality_assessment is not None else ''
                
                writer.writerow([
                    design, corner,
                    chronos_wns, opensta_wns, wns_diff, wns_match,
                    chronos_tns, chronos_setup_viol,
                    chronos_whs, opensta_hold, hold_diff, hold_match,
                    chronos_hold_viol,
                    chronos_delay, opensta_delay, delay_diff, delay_match,
                    chronos_slack, opensta_slack, slack_diff, slack_match,
                    opensta_clk, opensta_freq,
                    chronos_runtime, chronos_quality
                ])
    
    def generate_markdown_report(self) -> str:
        """Generate Markdown comparison report"""
        report = []
        report.append("# Chronos-STA vs OpenSTA Detailed Comparison Report\n")
        
        # Summary
        report.append("## Summary\n")
        both_tools = sum(1 for d in self.all_designs if d in self.chronos_results and d in self.opensta_results)
        report.append(f"- **Total Designs Compared**: {len(self.all_designs)}")
        report.append(f"- **Chronos Results**: {len(self.chronos_results)}")
        report.append(f"- **OpenSTA Results**: {len(self.opensta_results)}")
        report.append(f"- **Designs with Both Results**: {both_tools}\n")
        
        # Detailed comparison - only for designs with both results
        report.append("## Detailed Comparison (Common Metrics Only)\n")
        
        for design, corner in self.all_designs:
            chronos = self.chronos_results.get((design, corner))
            opensta = self.opensta_results.get((design, corner))
            
            # Skip if either tool doesn't have results
            if not chronos or not opensta:
                continue
            
            report.append(f"### {design} ({corner})\n")
            
            # Create markdown table
            report.append("| Metric | Chronos-STA | OpenSTA | Difference | Match |")
            report.append("|--------|-------------|---------|------------|-------|")
            
            # WNS
            chronos_wns = f"{chronos.wns:.6f} ns" if chronos.wns is not None else "N/A"
            opensta_wns = f"{opensta.wns:.6f} ns" if opensta.wns is not None else "N/A"
            if chronos.wns is not None and opensta.wns is not None:
                diff = abs(chronos.wns - opensta.wns)
                diff_str = f"{diff:.6f} ns"
                match = "✓" if diff < 0.001 else "⚠"
            else:
                diff_str = "N/A"
                match = "-"
            report.append(f"| WNS (Setup) | {chronos_wns} | {opensta_wns} | {diff_str} | {match} |")
            
            # TNS
            if chronos.tns is not None:
                chronos_tns = f"{chronos.tns:.6f} ns"
                report.append(f"| TNS (Total Negative Slack) | {chronos_tns} | - | - | - |")
            
            # WHS/Hold
            chronos_whs = f"{chronos.whs:.6f} ns" if chronos.whs is not None else "N/A"
            opensta_hold = f"{opensta.hold_slack:.6f} ns" if opensta.hold_slack is not None else "N/A"
            if chronos.whs is not None and opensta.hold_slack is not None:
                diff = abs(chronos.whs - opensta.hold_slack)
                diff_str = f"{diff:.6f} ns"
                match = "✓" if diff < 0.001 else "⚠"
            else:
                diff_str = "N/A"
                match = "-"
            report.append(f"| WHS/Hold Slack | {chronos_whs} | {opensta_hold} | {diff_str} | {match} |")
            
            # Violations
            if chronos.setup_violations is not None:
                report.append(f"| Setup Violations | {chronos.setup_violations} | N/A | - | - |")
            if chronos.hold_violations is not None:
                report.append(f"| Hold Violations | {chronos.hold_violations} | N/A | - | - |")
            
            # Max Delay
            chronos_delay = f"{chronos.max_delay:.6f} ns" if hasattr(chronos, 'max_delay') and chronos.max_delay is not None else "N/A"
            opensta_delay = f"{opensta.max_delay:.6f} ns" if opensta.max_delay is not None else "N/A"
            if hasattr(chronos, 'max_delay') and chronos.max_delay is not None and opensta.max_delay is not None:
                diff = abs(chronos.max_delay - opensta.max_delay)
                diff_str = f"{diff:.6f} ns"
                match = "✓" if diff < 0.001 else "⚠"
            else:
                diff_str = "N/A"
                match = "-"
            report.append(f"| Max Path Delay | {chronos_delay} | {opensta_delay} | {diff_str} | {match} |")
            
            # Setup Slack
            chronos_slack = f"{chronos.setup_slack:.6f} ns" if hasattr(chronos, 'setup_slack') and chronos.setup_slack is not None else "N/A"
            opensta_slack = f"{opensta.setup_slack:.6f} ns" if opensta.setup_slack is not None else "N/A"
            if hasattr(chronos, 'setup_slack') and chronos.setup_slack is not None and opensta.setup_slack is not None:
                diff = abs(chronos.setup_slack - opensta.setup_slack)
                diff_str = f"{diff:.6f} ns"
                match = "✓" if diff < 0.001 else "⚠"
            else:
                diff_str = "N/A"
                match = "-"
            report.append(f"| Setup Slack | {chronos_slack} | {opensta_slack} | {diff_str} | {match} |")
            
            # Additional info
            if opensta.clock_period is not None:
                report.append(f"| Clock Period | - | {opensta.clock_period:.6f} ns | - | - |")
            if opensta.frequency is not None:
                report.append(f"| Frequency | - | {opensta.frequency:.2f} MHz | - | - |")
            if chronos.runtime is not None:
                report.append(f"| Runtime | {chronos.runtime:.4f} s | N/A | - | - |")
            if chronos.quality_assessment is not None:
                report.append(f"| Quality Assessment | {chronos.quality_assessment} | - | - | - |")
            
            report.append("")
        
        # Legend
        report.append("## Legend\n")
        report.append("- **✓** - Values match within 0.001 ns tolerance")
        report.append("- **⚠** - Values differ beyond tolerance")
        report.append("- **-** - Cannot compare (data not available)")
        report.append("- **N/A** - Data not available from tool")
        
        return "\n".join(report)


def main():
    """Main comparison function"""
    # Define paths
    script_dir = Path(__file__).parent
    project_root = script_dir.parent
    
    chronos_json = project_root / "reports" / "report_chronos" / "chronos_benchmark_20260212_201332.json"
    chronos_output_dir = project_root / "reports" / "report_chronos"
    opensta_dir = project_root / "reports" / "reports_OpenSTA"
    output_dir = project_root / "reports"
    
    print("=" * 80)
    print("Chronos-STA vs OpenSTA Detailed Comparison Tool")
    print("=" * 80)
    print()
    
    # Parse Chronos results
    print(f"📊 Parsing Chronos results from: {chronos_json}")
    if not chronos_json.exists():
        print(f"❌ Error: Chronos JSON file not found: {chronos_json}")
        return
    
    chronos_results = ChronosParser.parse_json(str(chronos_json))
    print(f"✓ Found {len(chronos_results)} Chronos benchmark results")
    
    # Load detailed JSON data for each design
    print(f"\n📊 Loading detailed Chronos timing data...")
    detailed_results = {}
    for result in chronos_results:
        design = result.design
        corner = result.corner.lower()
        
        # Find the detailed JSON file
        json_pattern = f"{design}_{corner}_output/timing_timing.json"
        json_path = chronos_output_dir / json_pattern.replace('_output/', '_output\\')
        
        if json_path.exists():
            print(f"  - Loading: {design} ({corner})")
            detailed = ChronosParser.parse_detailed_json(str(json_path), design, corner.upper())
            if detailed:
                # Merge with basic result (to get runtime)
                detailed.runtime = result.runtime
                detailed.success = result.success
                detailed.error = result.error
                detailed_results[(design, corner.upper())] = detailed
        else:
            # Use basic result if detailed not found
            detailed_results[(design, corner.upper())] = result
    
    chronos_results = list(detailed_results.values())
    print(f"✓ Loaded detailed data for {len(chronos_results)} designs")
    
    # Parse OpenSTA results
    print(f"\n📊 Parsing OpenSTA reports from: {opensta_dir}")
    opensta_results = []
    
    if opensta_dir.exists():
        for rpt_file in opensta_dir.glob("*.rpt"):
            print(f"  - Reading: {rpt_file.name}")
            results = OpenSTAParser.parse_report(str(rpt_file))
            opensta_results.extend(results)
    else:
        print(f"⚠️  Warning: OpenSTA directory not found: {opensta_dir}")
    
    print(f"✓ Found {len(opensta_results)} OpenSTA results")
    
    # Generate comparison report
    print(f"\n📈 Generating comparison reports...")
    comparison = ComparisonReport(chronos_results, opensta_results)
    
    # Text report
    text_report = comparison.generate_text_report()
    text_output = output_dir / "comparison_report.txt"
    with open(text_output, 'w', encoding='utf-8') as f:
        f.write(text_report)
    print(f"✓ Text report saved: {text_output}")
    
    # CSV report
    csv_output = output_dir / "comparison_report.csv"
    comparison.generate_csv_report(str(csv_output))
    print(f"✓ CSV report saved: {csv_output}")
    
    # Markdown report
    md_report = comparison.generate_markdown_report()
    md_output = output_dir / "comparison_report.md"
    with open(md_output, 'w', encoding='utf-8') as f:
        f.write(md_report)
    print(f"✓ Markdown report saved: {md_output}")
    
    # Display text report
    print("\n" + "=" * 80)
    print("COMPARISON REPORT PREVIEW")
    print("=" * 80)
    print(text_report)
    
    print("\n" + "=" * 80)
    print("✅ Comparison completed successfully!")
    print("=" * 80)


if __name__ == "__main__":
    main()
