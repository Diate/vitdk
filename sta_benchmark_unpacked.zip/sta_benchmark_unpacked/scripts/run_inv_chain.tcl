# ==============================================================================
# OpenSTA Benchmark Script - Inverter Chain
# Purpose: Run STA on inv_chain design and export results
# ==============================================================================

# Read Liberty file (TT corner)
read_liberty ../lib/simple_tt.lib

# Read Verilog netlist
read_verilog ../designs/small/inv_chain.v
link_design inv_chain

# Read parasitics
read_spef ../spef/inv_chain.spef

# Read constraints
read_sdc ../sdc/inv_chain.sdc

# ==============================================================================
# Timing Analysis
# ==============================================================================

# Report timing paths
puts "=============================================="
puts "TIMING REPORT - inv_chain (TT Corner)"
puts "=============================================="

# Report all paths with full details
report_checks -path_delay max -format full_clock_expanded

# Report worst setup path
report_checks -path_delay max -group_count 5

# Report worst hold path
report_checks -path_delay min -group_count 5

# ==============================================================================
# Delay Analysis
# ==============================================================================
puts "\n=============================================="
puts "CELL DELAY REPORT"
puts "=============================================="

# Report cell delays
report_checks -path_delay max -fields {slew cap input_pins fanout}

# ==============================================================================
# Transition Analysis
# ==============================================================================
puts "\n=============================================="
puts "SLEW/TRANSITION REPORT"
puts "=============================================="

report_check_types -max_slew -max_capacitance -max_fanout -violators

# ==============================================================================
# Export Results with Full Metrics
# ==============================================================================

# Get script directory and construct report paths
set script_dir [file dirname [info script]]
set report_dir [file join $script_dir ".." "reports" "reports_OpenSTA"]  
set report_file [file join $report_dir "inv_chain_tt_opensta.rpt"]

# Ensure report directory exists
file mkdir $report_dir

# Redirect output to capture metrics
set redirect_file [file join $report_dir "inv_chain_tt_full.txt"]
redirect -file $redirect_file {
    puts "=========================================================="
    puts "OpenSTA FULL Timing Analysis - inv_chain (TT Corner)"
    puts "=========================================================="
    puts ""
    
    # Report worst slack
    puts "\n=== WORST SLACK (SETUP) ==="
    report_worst_slack -max
    
    puts "\n=== WORST SLACK (HOLD) ==="
    report_worst_slack -min
    
    puts "\n=== DETAILED SETUP PATHS ==="
    report_checks -path_delay max -group_count 5 -format full_clock
    
    puts "\n=== DETAILED HOLD PATHS ==="
    report_checks -path_delay min -group_count 5 -format full_clock
    
    puts "\n=== TNS (Total Negative Slack) ==="
    report_tns
    
    puts "\n=== CHECK TYPES (Violations) ==="
    report_check_types -max_slew -max_capacitance -max_fanout -violators
    
    puts "\n=========================================================="
}

# Create simplified summary report for comparison
if {[catch {
    set fp [open $report_file w]

    puts $fp "=========================================================="
    puts $fp "OpenSTA Timing Report - inv_chain (TT Corner)"
    puts $fp "=========================================================="
    puts $fp ""
    puts $fp "Design: inv_chain"
    puts $fp "Corner: TT (1.1V, 25C)"
    puts $fp "Process: 45nm"
    puts $fp ""
    puts $fp "IMPORTANT: Full timing metrics available in:"
    puts $fp "  $redirect_file"
    puts $fp ""
    puts $fp "For detailed WNS/WHS/TNS/violations, parse the full report."
    puts $fp ""
    puts $fp "Clock Period: 10.0 ns (100 MHz)"
    puts $fp ""
    puts $fp "=========================================================="

    close $fp

    puts "\n=========================================================="
    puts "Summary report: $report_file"
    puts "Full metrics: $redirect_file"
    puts "=========================================================="
} result]} {
    puts "Error writing report: $result"
}

exit
