# ==============================================================================
# OpenSTA Multi-Corner Analysis Script
# Purpose: Run STA across all corners (SS, TT, FF)
# ==============================================================================

proc run_corner {corner lib_file design verilog spef sdc report_dir} {
    puts "\n=============================================="
    puts "Running $corner corner analysis for $design"
    puts "=============================================="

    # Clear previous design
    if {[get_libs -quiet *] ne ""} {
        # Remove old libraries if any
    }

    # Read Liberty
    read_liberty $lib_file

    # Read design
    read_verilog $verilog
    link_design $design

    # Read parasitics
    if {[file exists $spef]} {
        read_spef $spef
    }

    # Read constraints
    read_sdc $sdc

    # Report timing
    puts "\n--- $corner Setup Analysis ---"
    report_checks -path_delay max -group_count 5

    puts "\n--- $corner Hold Analysis ---"
    report_checks -path_delay min -group_count 5

    # Export full metrics for this corner
    set corner_lower [string tolower $corner]
    set redirect_file [file join $report_dir "dff_logic_dff_${corner_lower}_full.txt"]
    redirect -file $redirect_file {
        puts "=========================================================="
        puts "OpenSTA FULL Timing Analysis - dff_logic_dff ($corner Corner)"
        puts "=========================================================="
        puts ""
        
        puts "\n=== WORST SLACK (SETUP) ==="
        report_worst_slack -max
        
        puts "\n=== WORST SLACK (HOLD) ==="
        report_worst_slack -min
        
        puts "\n=== DETAILED SETUP PATHS ==="
        report_checks -path_delay max -group_count 5 -format full_clock
        
        puts "\n=== DETAILED HOLD PATHS ==="
        report_checks -path_delay min -group_count 5 -format full_clock
        
        puts "\n=== TNS (Total Negative Slack) ==="
        report_tns
        
        puts "\n=== CHECK TYPES (Violations) ==="
        report_check_types -max_slew -max_capacitance -max_fanout -violators
        
        puts "\n=========================================================="
    }
    
    # Create summary report for this corner
    set summary_file [file join $report_dir "dff_logic_dff_${corner_lower}_opensta.rpt"]
    set fp [open $summary_file w]
    puts $fp "==========================================================="
    puts $fp "OpenSTA Timing Report - dff_logic_dff ($corner Corner)"
    puts $fp "==========================================================="
    puts $fp ""
    puts $fp "Design: dff_logic_dff"
    puts $fp "Corner: $corner"
    
    if {$corner eq "SS"} {
        puts $fp "Conditions: 0.95V, 125C (Slow-Slow - Worst Setup)"
    } elseif {$corner eq "TT"} {
        puts $fp "Conditions: 1.1V, 25C (Typical)"
    } elseif {$corner eq "FF"} {
        puts $fp "Conditions: 1.25V, -40C (Fast-Fast - Worst Hold)"
    }
    
    puts $fp "Process: 45nm"
    puts $fp ""
    puts $fp "Full metrics exported to: dff_logic_dff_${corner_lower}_full.txt"
    puts $fp "Clock Period: 10.0 ns (100 MHz)"
    puts $fp ""
    puts $fp "==========================================================="
    close $fp
    
    puts "Corner $corner reports saved:"
    puts "  Summary: $summary_file"
    puts "  Full: $redirect_file"

    return [list "0.0" "0.0"]
}

# ==============================================================================
# Design: dff_logic_dff
# ==============================================================================
set design "dff_logic_dff"
set verilog "../designs/small/dff_logic_dff.v"
set spef "../spef/dff_logic_dff.spef"
set sdc "../sdc/dff_logic_dff.sdc"

# Setup report directory
set script_dir [file dirname [info script]]
set report_dir [file join $script_dir ".." "reports" "reports_OpenSTA"]
file mkdir $report_dir

puts "=========================================================="
puts "MULTI-CORNER ANALYSIS: $design"
puts "=========================================================="

# Run SS corner (worst-case setup)
set ss_results [run_corner "SS" "../lib/simple_ss.lib" $design $verilog $spef $sdc $report_dir]

# Run TT corner (typical)
set tt_results [run_corner "TT" "../lib/simple_tt.lib" $design $verilog $spef $sdc $report_dir]

# Run FF corner (worst-case hold)
set ff_results [run_corner "FF" "../lib/simple_ff.lib" $design $verilog $spef $sdc $report_dir]

# ==============================================================================
# Summary
# ==============================================================================
puts "\n=========================================================="
puts "MULTI-CORNER SUMMARY: $design"
puts "=========================================================="
puts "Corner | Setup Slack | Hold Slack"
puts "-------|-------------|------------"
puts "SS     | [lindex $ss_results 0] ns    | [lindex $ss_results 1] ns"
puts "TT     | [lindex $tt_results 0] ns    | [lindex $tt_results 1] ns"
puts "FF     | [lindex $ff_results 0] ns    | [lindex $ff_results 1] ns"
puts ""Multi-Corner Summary
# ==============================================================================

set summary_report [file join $report_dir "multicorner_opensta.rpt"]

if {[catch {
    set fp [open $summary_report w]

    puts $fp "==========================================================="
    puts $fp "OpenSTA Multi-Corner Analysis Report"
    puts $fp "==========================================================="
    puts $fp ""
    puts $fp "Design: $design"
    puts $fp "Process: 45nm"
    puts $fp ""
    puts $fp "CORNER DEFINITIONS:"
    puts $fp "==================="
    puts $fp "SS: 0.95V, 125C  (Slow-Slow - Worst Setup)"
    puts $fp "TT: 1.1V,  25C   (Typical - Nominal)"
    puts $fp "FF: 1.25V, -40C  (Fast-Fast - Worst Hold)"
    puts $fp ""
    puts $fp "INDIVIDUAL CORNER REPORTS:"
    puts $fp "=========================="
    puts $fp "SS: dff_logic_dff_ss_opensta.rpt (full: dff_logic_dff_ss_full.txt)"
    puts $fp "TT: dff_logic_dff_tt_opensta.rpt (full: dff_logic_dff_tt_full.txt)"
    puts $fp "FF: dff_logic_dff_ff_opensta.rpt (full: dff_logic_dff_ff_full.txt)"
    puts $fp ""
    puts $fp "All reports contain complete timing metrics (WNS/WHS/TNS/violations)"
    puts $fp ""
    puts $fp "==========================================================="

    close $fp

    puts "\n==========================================================="
    puts "Multi-corner summary: $summary_report"
    puts "Individual corner reports saved in: $report_dir=================================="

    close $fp

    puts "\n==========================================================="
    puts "Report saved to: $report_file"
    puts "==========================================================="
} result]} {
    puts "Error writing report: $result"
}

exit
