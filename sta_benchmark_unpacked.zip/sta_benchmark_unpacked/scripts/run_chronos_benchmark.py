#!/usr/bin/env python3
"""
==============================================================================
Chronos-STA Benchmark Runner
Purpose: Run benchmarks using Chronos-STA and generate reports
==============================================================================
"""

import sys
import json
import subprocess
import time
from pathlib import Path
from datetime import datetime
from dataclasses import dataclass, field
from typing import List, Dict, Optional


@dataclass
class ChronosBenchmarkResult:
    """Result from running chronos-sta"""
    design_name: str
    corner: str
    runtime_seconds: float
    success: bool
    wns: Optional[float] = None
    whs: Optional[float] = None
    error_message: str = ""
    stdout: str = ""
    stderr: str = ""


class ChronosBenchmarkRunner:
    """Runs benchmarks using Chronos-STA"""

    def __init__(self, benchmark_dir: Path, chronos_sta_path: Path):
        self.benchmark_dir = benchmark_dir
        self.chronos_sta_path = chronos_sta_path
        self.results_dir = benchmark_dir / "reports"
        self.results_dir.mkdir(exist_ok=True)
        self.results = []

    def run_design(self, design_name: str, category: str, corner: str = "TT") -> ChronosBenchmarkResult:
        """Run chronos-sta on a single design"""

        # Construct file paths
        verilog = self.benchmark_dir / f"designs/{category}/{design_name}.v"
        lib = self.benchmark_dir / f"lib/simple_{corner.lower()}.lib"
        sdc = self.benchmark_dir / f"sdc/{design_name}.sdc"
        spef = self.benchmark_dir / f"spef/{design_name}.spef"
        report_file = self.results_dir / f"{design_name}_{corner.lower()}_chronos.rpt"

        # Verify files exist
        if not verilog.exists():
            return ChronosBenchmarkResult(
                design_name=design_name,
                corner=corner,
                runtime_seconds=0,
                success=False,
                error_message=f"Verilog not found: {verilog}"
            )

        if not lib.exists():
            return ChronosBenchmarkResult(
                design_name=design_name,
                corner=corner,
                runtime_seconds=0,
                success=False,
                error_message=f"Liberty not found: {lib}"
            )

        if not sdc.exists():
            return ChronosBenchmarkResult(
                design_name=design_name,
                corner=corner,
                runtime_seconds=0,
                success=False,
                error_message=f"SDC not found: {sdc}"
            )

        print(f"  {design_name} ({corner})...", end=" ", flush=True)

        # Build command - Chronos-STA uses "run" subcommand
        cmd = [
            sys.executable,
            str(self.chronos_sta_path),
            "--no-color",  # Disable colored output (encoding issues on Windows)
            "--quiet",     # Suppress verbose output
            "run",
            "-lib", str(lib),
            "-v", str(verilog),
            "-sdc", str(sdc),
            "-o", str(self.results_dir / f"{design_name}_{corner.lower()}_output"),
            "--format", "json",  # Use JSON format for easier parsing
            "--max-paths", "100"
        ]

        # Add optional SPEF if exists
        if spef.exists():
            cmd.extend(["-spef", str(spef)])

        # Run chronos-sta
        start_time = time.time()
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300,
                cwd=str(self.benchmark_dir)
            )
            runtime = time.time() - start_time

            # Parse output for WNS/WHS
            wns = None
            whs = None
            output = result.stdout + result.stderr

            # Debug: Save full output for first run
            if design_name == "inv_chain" and corner == "TT":
                debug_file = self.results_dir / "chronos_debug_output.txt"
                with open(debug_file, 'w') as f:
                    f.write("=== STDOUT ===\n")
                    f.write(result.stdout)
                    f.write("\n\n=== STDERR ===\n")
                    f.write(result.stderr)
                    f.write("\n\n=== Return Code ===\n")
                    f.write(str(result.returncode))

            # Try to parse JSON report if it exists
            try:
                output_dir = self.results_dir / f"{design_name}_{corner.lower()}_output"
                json_report = output_dir / "timing_timing.json"

                if json_report.exists():
                    with open(json_report, 'r') as f:
                        json_data = json.load(f)

                    # Extract WNS and WHS from JSON structure
                    if 'sections' in json_data:
                        for section in json_data['sections']:
                            if 'tables' in section and section['tables']:
                                for table in section['tables']:
                                    if 'rows' in table:
                                        for row in table['rows']:
                                            if 'Metric' in row and 'WNS (ns)' in row['Metric']:
                                                if 'Setup' in row:
                                                    wns = float(row['Setup'])
                                                if 'Hold' in row:
                                                    whs = float(row['Hold'])
            except Exception as e:
                pass

            # Fallback: Try text parsing if JSON failed
            if wns is None:
                for line in output.split('\n'):
                    line_lower = line.lower()

                    if 'slack' in line_lower or 'wns' in line_lower or 'setup' in line_lower:
                        try:
                            import re
                            nums = re.findall(r'[-+]?\d*\.?\d+', line)
                            if nums:
                                wns = float(nums[-1])
                        except:
                            pass

                    if 'hold' in line_lower or 'whs' in line_lower or 'min' in line_lower:
                        try:
                            import re
                            nums = re.findall(r'[-+]?\d*\.?\d+', line)
                            if nums:
                                whs = float(nums[-1])
                        except:
                            pass

            status = "OK" if result.returncode == 0 else "WARN"
            print(f"{status} ({runtime:.2f}s, WNS: {wns}ns)")

            return ChronosBenchmarkResult(
                design_name=design_name,
                corner=corner,
                runtime_seconds=runtime,
                success=result.returncode == 0,
                wns=wns,
                whs=whs,
                stdout=result.stdout,
                stderr=result.stderr
            )

        except subprocess.TimeoutExpired:
            print("TIMEOUT")
            return ChronosBenchmarkResult(
                design_name=design_name,
                corner=corner,
                runtime_seconds=time.time() - start_time,
                success=False,
                error_message="Timeout (300s)"
            )
        except Exception as e:
            print(f"ERROR: {e}")
            return ChronosBenchmarkResult(
                design_name=design_name,
                corner=corner,
                runtime_seconds=time.time() - start_time,
                success=False,
                error_message=str(e)
            )

    def run_benchmark_suite(self):
        """Run all benchmarks"""

        designs = [
            # Small designs
            ("inv_chain", "small"),
            ("buf_chain", "small"),
            ("dff_logic_dff", "small"),
            ("fanout_tree", "small"),
            ("clock_tree", "small"),
            # Medium designs
            ("adder_8bit", "medium"),
            ("multiplier_4x4", "medium"),
            ("priority_encoder", "medium"),
            ("shift_register", "medium"),
        ]

        print("=" * 70)
        print("CHRONOS-STA BENCHMARK SUITE")
        print("=" * 70)
        print()

        # Single corner run (TT)
        print("--- TT Corner (Typical) ---")
        for design_name, category in designs:
            result = self.run_design(design_name, category, "TT")
            self.results.append(result)

        print()

        # Multi-corner for sequential design
        print("--- Multi-Corner Analysis (dff_logic_dff) ---")
        for corner in ["SS", "FF"]:
            result = self.run_design("dff_logic_dff", "small", corner)
            self.results.append(result)

        print()

        # Print summary
        self._print_summary()

        # Export results
        self._export_results()

    def _print_summary(self):
        """Print summary of all results"""
        print("=" * 70)
        print("BENCHMARK SUMMARY")
        print("=" * 70)

        passed = sum(1 for r in self.results if r.success)
        failed = sum(1 for r in self.results if not r.success)
        total_time = sum(r.runtime_seconds for r in self.results)

        print(f"Total Runs:    {len(self.results)}")
        print(f"Passed:        {passed}")
        print(f"Failed:        {failed}")
        print(f"Total Runtime: {total_time:.2f}s")
        print()

        print("--- Detailed Results ---")
        print(f"{'Design':<25} {'Corner':<8} {'Status':<8} {'WNS (ns)':<12} {'Runtime (s)':<12}")
        print("-" * 75)

        for result in self.results:
            status = "PASS" if result.success else "FAIL"
            wns_str = f"{result.wns:.4f}" if result.wns is not None else "N/A"
            print(f"{result.design_name:<25} {result.corner:<8} {status:<8} {wns_str:<12} {result.runtime_seconds:<12.2f}")

            if not result.success and result.error_message:
                print(f"  Error: {result.error_message}")

    def _export_results(self):
        """Export results to JSON"""
        data = {
            'tool': 'Chronos-STA',
            'timestamp': datetime.now().isoformat(),
            'total_runs': len(self.results),
            'passed': sum(1 for r in self.results if r.success),
            'failed': sum(1 for r in self.results if not r.success),
            'total_runtime_seconds': sum(r.runtime_seconds for r in self.results),
            'results': [
                {
                    'design': r.design_name,
                    'corner': r.corner,
                    'success': r.success,
                    'runtime_seconds': r.runtime_seconds,
                    'wns': r.wns,
                    'whs': r.whs,
                    'error_message': r.error_message
                }
                for r in self.results
            ]
        }

        export_file = self.results_dir / f"chronos_benchmark_{datetime.now():%Y%m%d_%H%M%S}.json"

        with open(export_file, 'w') as f:
            json.dump(data, f, indent=2)

        print(f"\nResults exported to: {export_file}")


def main():
    # Get paths
    script_dir = Path(__file__).parent
    benchmark_dir = script_dir.parent
    chronos_sta_path = Path("E:/EDA/chronos-sta/chronos_sta.py")

    # Check if chronos-sta exists
    if not chronos_sta_path.exists():
        print(f"ERROR: Chronos-STA not found at {chronos_sta_path}")
        print("Please update the path in this script")
        sys.exit(1)

    print(f"Chronos-STA path: {chronos_sta_path}")
    print(f"Benchmark dir:   {benchmark_dir}")
    print()

    # Run benchmarks
    runner = ChronosBenchmarkRunner(benchmark_dir, chronos_sta_path)
    runner.run_benchmark_suite()

    # Return exit code
    failed = sum(1 for r in runner.results if not r.success)
    sys.exit(0 if failed == 0 else 1)


if __name__ == "__main__":
    main()
