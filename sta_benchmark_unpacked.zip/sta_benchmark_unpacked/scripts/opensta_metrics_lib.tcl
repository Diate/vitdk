# ==============================================================================
# Enhanced OpenSTA TCL Script with Metrics Export
# Shared procedures for timing metric extraction
# ==============================================================================

proc extract_timing_metrics {} {
    # Get worst negative slack (setup)
    set wns_list [sta::find_timing_paths -setup -sort_by_slack -nworst 1]
    set wns 0.0
    if {[llength $wns_list] > 0} {
        set path [lindex $wns_list 0]
        set wns [sta::format_time [sta::path_slack_delay $path] 3]
    }
    
    # Get worst hold slack
    set whs_list [sta::find_timing_paths -hold -sort_by_slack -nworst 1]
    set whs 0.0
    if {[llength $whs_list] > 0} {
        set path [lindex $whs_list 0]
        set whs [sta::format_time [sta::path_slack_delay $path] 3]
    }
    
    # Count setup violations
    set setup_viol 0
    set spath_list [sta::find_timing_paths -setup -sort_by_slack -nworst 10000]
    foreach path $spath_list {
        set slack [sta::path_slack_delay $path]
        if {$slack < 0} {
            incr setup_viol
        }
    }
    
    # Count hold violations
    set hold_viol 0
    set hpath_list [sta::find_timing_paths -hold -sort_by_slack -nworst 10000]
    foreach path $hpath_list {
        set slack [sta::path_slack_delay $path]
        if {$slack < 0} {
            incr hold_viol
        }
    }
    
    return [list $wns $whs $setup_viol $hold_viol]
}

proc export_metrics_report {report_file design corner metrics} {
    lassign $metrics wns whs setup_viol hold_viol
    
    set fp [open $report_file w]
    
    puts $fp "=========================================================="
    puts $fp "OpenSTA Timing Report - $design ($corner Corner)"
    puts $fp "=========================================================="
    puts $fp ""
    puts $fp "Design: $design"
    puts $fp "Corner: $corner (1.1V, 25C)"
    puts $fp "Process: 45nm"
    puts $fp ""
    puts $fp "Timing Metrics:"
    puts $fp "---------------"
    puts $fp "WNS (Worst Setup Slack): $wns ns"
    puts $fp "WHS (Worst Hold Slack): $whs ns"
    puts $fp "Setup Violations: $setup_viol"
    puts $fp "Hold Violations: $hold_viol"
    puts $fp ""
    
    # Calculate timing status
    if {$wns >= 0.0 && $whs >= 0.0} {
        puts $fp "Timing Status: ✓ PASS (No violations)"
    } else {
        puts $fp "Timing Status: ✗ FAIL ([expr {$setup_viol + $hold_viol}] total violations)"
    }
    puts $fp ""
    puts $fp "Clock Period: 10.0 ns (100 MHz)"
    puts $fp ""
    puts $fp "=========================================================="
    
    close $fp
}
