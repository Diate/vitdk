#!/bin/bash
# ==============================================================================
# STA Benchmark Runner Script
# Purpose: Run all benchmarks and collect results
# ==============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BENCHMARK_DIR="$(dirname "$SCRIPT_DIR")"

# Create reports directory
mkdir -p "$BENCHMARK_DIR/reports"

echo "=============================================="
echo "STA Benchmark Suite Runner"
echo "=============================================="
echo "Benchmark directory: $BENCHMARK_DIR"
echo ""

# Check if OpenSTA is available
if ! command -v sta &> /dev/null; then
    echo "ERROR: OpenSTA (sta) not found in PATH"
    echo "Please install OpenSTA or add it to PATH"
    exit 1
fi

echo "OpenSTA found: $(which sta)"
echo ""

# ==============================================================================
# Run Small Design Benchmarks
# ==============================================================================
echo "=============================================="
echo "Running Small Design Benchmarks..."
echo "=============================================="

# Inverter chain
echo ">>> inv_chain..."
cd "$SCRIPT_DIR"
sta run_inv_chain.tcl > ../reports/inv_chain_full.log 2>&1
echo "    Done. Log: reports/inv_chain_full.log"

# Buffer chain
echo ">>> buf_chain..."
sta run_buf_chain.tcl > ../reports/buf_chain_full.log 2>&1
echo "    Done. Log: reports/buf_chain_full.log"

# DFF logic DFF
echo ">>> dff_logic_dff..."
sta run_dff_logic_dff.tcl > ../reports/dff_logic_dff_full.log 2>&1
echo "    Done. Log: reports/dff_logic_dff_full.log"

# Fanout tree
echo ">>> fanout_tree..."
sta run_fanout_tree.tcl > ../reports/fanout_tree_full.log 2>&1
echo "    Done. Log: reports/fanout_tree_full.log"

# Clock tree
echo ">>> clock_tree..."
sta run_clock_tree.tcl > ../reports/clock_tree_full.log 2>&1
echo "    Done. Log: reports/clock_tree_full.log"

# ==============================================================================
# Run Medium Design Benchmarks
# ==============================================================================
echo ""
echo "=============================================="
echo "Running Medium Design Benchmarks..."
echo "=============================================="

# 8-bit adder
echo ">>> adder_8bit..."
sta run_adder_8bit.tcl > ../reports/adder_8bit_full.log 2>&1
echo "    Done. Log: reports/adder_8bit_full.log"

# 4x4 multiplier
echo ">>> multiplier_4x4..."
sta run_multiplier_4x4.tcl > ../reports/multiplier_4x4_full.log 2>&1
echo "    Done. Log: reports/multiplier_4x4_full.log"

# Priority encoder
echo ">>> priority_encoder..."
sta run_priority_encoder.tcl > ../reports/priority_encoder_full.log 2>&1
echo "    Done. Log: reports/priority_encoder_full.log"

# Shift register
echo ">>> shift_register..."
sta run_shift_register.tcl > ../reports/shift_register_full.log 2>&1
echo "    Done. Log: reports/shift_register_full.log"

# ==============================================================================
# Run Multi-Corner Analysis
# ==============================================================================
echo ""
echo "=============================================="
echo "Running Multi-Corner Analysis..."
echo "=============================================="

sta run_multicorner.tcl > ../reports/multicorner_full.log 2>&1
echo "    Done. Log: reports/multicorner_full.log"

# ==============================================================================
# Summary
# ==============================================================================
echo ""
echo "=============================================="
echo "Benchmark Suite Complete"
echo "=============================================="
echo "Reports generated in: $BENCHMARK_DIR/reports/"
ls -la "$BENCHMARK_DIR/reports/"

echo ""
echo "To compare with custom STA tool, run:"
echo "  python3 scripts/compare_results.py"
