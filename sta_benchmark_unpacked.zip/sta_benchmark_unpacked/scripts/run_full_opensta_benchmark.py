#!/usr/bin/env python3
"""
==============================================================================
Run Complete OpenSTA Benchmark Suite
Purpose: Generate OpenSTA reports for all 11 designs to enable full comparison
==============================================================================
"""

import os
import sys
import subprocess
import time
from pathlib import Path
from datetime import datetime


class OpenSTABenchmarkRunner:
    """Run OpenSTA on all benchmark designs"""
    
    def __init__(self, benchmark_dir: Path):
        self.benchmark_dir = benchmark_dir
        self.designs_dir = benchmark_dir / "designs"
        self.lib_dir = benchmark_dir / "lib"
        self.sdc_dir = benchmark_dir / "sdc"
        self.spef_dir = benchmark_dir / "spef"
        self.output_dir = benchmark_dir / "reports" / "reports_OpenSTA"
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
    def define_test_cases(self):
        """Define all test cases"""
        test_cases = []
        
        # Small designs (TT corner)
        small_designs = [
            "inv_chain",
            "buf_chain", 
            "dff_logic_dff",
            "fanout_tree",
            "clock_tree"
        ]
        
        for design in small_designs:
            tc = {
                'name': design,
                'verilog': self.designs_dir / "small" / f"{design}.v",
                'liberty': self.lib_dir / "simple_tt.lib",
                'sdc': self.sdc_dir / f"{design}.sdc",
                'spef': self.spef_dir / f"{design}.spef",
                'corner': 'TT',
                'output': self.output_dir / f"{design}_tt_opensta.rpt"
            }
            if tc['verilog'].exists():
                test_cases.append(tc)
        
        # Medium designs (TT corner)
        medium_designs = [
            "adder_8bit",
            "multiplier_4x4",
            "priority_encoder",
            "shift_register"
        ]
        
        for design in medium_designs:
            tc = {
                'name': design,
                'verilog': self.designs_dir / "medium" / f"{design}.v",
                'liberty': self.lib_dir / "simple_tt.lib",
                'sdc': self.sdc_dir / f"{design}.sdc",
                'spef': self.spef_dir / f"{design}.spef",
                'corner': 'TT',
                'output': self.output_dir / f"{design}_tt_opensta.rpt"
            }
            if tc['verilog'].exists():
                test_cases.append(tc)
        
        # Multi-corner for dff_logic_dff
        for corner, lib_file in [("SS", "simple_ss.lib"), ("FF", "simple_ff.lib")]:
            tc = {
                'name': "dff_logic_dff",
                'verilog': self.designs_dir / "small" / "dff_logic_dff.v",
                'liberty': self.lib_dir / lib_file,
                'sdc': self.sdc_dir / "dff_logic_dff.sdc",
                'spef': self.spef_dir / "dff_logic_dff.spef",
                'corner': corner,
                'output': self.output_dir / f"dff_logic_dff_{corner.lower()}_opensta.rpt"
            }
            if tc['liberty'].exists():
                test_cases.append(tc)
        
        return test_cases
    
    def generate_tcl_script(self, test_case):
        """Generate TCL script for OpenSTA"""
        tcl_content = f"""# OpenSTA Timing Analysis Script
# Design: {test_case['name']}
# Corner: {test_case['corner']}
# Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

# Read liberty
puts "Reading liberty file..."
read_liberty {test_case['liberty']}

# Read verilog
puts "Reading verilog file..."
read_verilog {test_case['verilog']}

# Link design
puts "Linking design {test_case['name']}..."
link_design {test_case['name']}

# Read SPEF if exists
"""
        
        if test_case['spef'].exists():
            tcl_content += f"""puts "Reading SPEF file..."
read_spef {test_case['spef']}
"""
        
        tcl_content += f"""
# Read SDC constraints
puts "Reading SDC constraints..."
read_sdc {test_case['sdc']}

# Report timing
puts "\\n=========================================="
puts "Timing Analysis Results"
puts "=========================================="

# Check timing
puts "\\nChecking timing..."
check_setup -verbose

# Report checks
puts "\\nTiming checks:"
report_checks -path_delay min_max -format full_clock_expanded -fields {{input_pin arc edge cell delay arrival required}} -digits 6

# Get worst slack
set setup_paths [find_timing_paths -sort_by_slack -path_delay max]
set hold_paths [find_timing_paths -sort_by_slack -path_delay min]

if {{[llength $setup_paths] > 0}} {{
    set worst_setup [lindex $setup_paths 0]
    set setup_slack [get_property $worst_setup slack]
    puts "\\nWorst Setup Slack: $setup_slack"
}} else {{
    puts "\\nNo setup paths found"
}}

if {{[llength $hold_paths] > 0}} {{
    set worst_hold [lindex $hold_paths 0]
    set hold_slack [get_property $worst_hold slack]
    puts "\\nWorst Hold Slack: $hold_slack"
}} else {{
    puts "\\nNo hold paths found"
}}

# Report total negative slack
report_tns
report_wns

# Report clock summary
puts "\\n=========================================="
puts "Clock Summary"
puts "=========================================="
report_clocks

puts "\\n=========================================="
puts "Analysis Complete"
puts "=========================================="

exit
"""
        return tcl_content
    
    def run_opensta(self, test_case):
        """Run OpenSTA on a single test case"""
        print(f"\n{'='*80}")
        print(f"Running OpenSTA: {test_case['name']} ({test_case['corner']})")
        print(f"{'='*80}")
        
        # Generate TCL script
        tcl_script = self.generate_tcl_script(test_case)
        tcl_file = self.output_dir / f"temp_{test_case['name']}_{test_case['corner'].lower()}.tcl"
        
        with open(tcl_file, 'w') as f:
            f.write(tcl_script)
        
        print(f"✓ TCL script: {tcl_file}")
        
        # Run OpenSTA
        try:
            start_time = time.time()
            
            # Check if sta command exists
            sta_cmd = "sta"  # or "opensta" depending on installation
            
            result = subprocess.run(
                [sta_cmd, str(tcl_file)],
                capture_output=True,
                text=True,
                timeout=60,
                cwd=self.benchmark_dir
            )
            
            runtime = time.time() - start_time
            
            # Save output
            with open(test_case['output'], 'w') as f:
                f.write("=" * 80 + "\n")
                f.write(f"OpenSTA Timing Report - {test_case['name']} ({test_case['corner']} Corner)\n")
                f.write("=" * 80 + "\n\n")
                f.write(f"Design: {test_case['name']}\n")
                f.write(f"Corner: {test_case['corner']}\n")
                f.write(f"Runtime: {runtime:.2f} seconds\n\n")
                f.write("=" * 80 + "\n")
                f.write("STDOUT:\n")
                f.write("=" * 80 + "\n")
                f.write(result.stdout)
                
                if result.stderr:
                    f.write("\n" + "=" * 80 + "\n")
                    f.write("STDERR:\n")
                    f.write("=" * 80 + "\n")
                    f.write(result.stderr)
                
                f.write("\n" + "=" * 80 + "\n")
            
            # Parse results from output
            wns = None
            whs = None
            
            # Try to extract slack values
            for line in result.stdout.split('\n'):
                if 'Worst Setup Slack:' in line:
                    try:
                        wns = float(line.split(':')[1].strip())
                    except:
                        pass
                elif 'Worst Hold Slack:' in line:
                    try:
                        whs = float(line.split(':')[1].strip())
                    except:
                        pass
            
            print(f"✓ Runtime: {runtime:.2f}s")
            print(f"✓ Output: {test_case['output']}")
            if wns is not None:
                print(f"  WNS: {wns:.6f} ns")
            if whs is not None:
                print(f"  WHS: {whs:.6f} ns")
            
            # Clean up TCL file
            tcl_file.unlink()
            
            return {
                'success': result.returncode == 0,
                'runtime': runtime,
                'wns': wns,
                'whs': whs,
                'output': str(test_case['output'])
            }
            
        except FileNotFoundError:
            print(f"❌ Error: OpenSTA not found. Please install OpenSTA first.")
            print(f"   Visit: https://github.com/The-OpenROAD-Project/OpenSTA")
            return {'success': False, 'error': 'OpenSTA not installed'}
        
        except subprocess.TimeoutExpired:
            print(f"❌ Error: OpenSTA timed out (>60s)")
            return {'success': False, 'error': 'Timeout'}
        
        except Exception as e:
            print(f"❌ Error: {str(e)}")
            return {'success': False, 'error': str(e)}
    
    def run_all(self):
        """Run OpenSTA on all test cases"""
        print("=" * 80)
        print("OpenSTA Complete Benchmark Suite")
        print("=" * 80)
        print()
        
        # Get test cases
        test_cases = self.define_test_cases()
        print(f"📊 Found {len(test_cases)} test cases")
        print()
        
        # Run each test
        results = []
        success_count = 0
        
        for i, tc in enumerate(test_cases, 1):
            print(f"\n[{i}/{len(test_cases)}] Processing: {tc['name']} ({tc['corner']})")
            
            if not tc['verilog'].exists():
                print(f"  ⚠️  Verilog not found: {tc['verilog']}")
                continue
            
            if not tc['sdc'].exists():
                print(f"  ⚠️  SDC not found: {tc['sdc']}")
                continue
            
            result = self.run_opensta(tc)
            result['design'] = tc['name']
            result['corner'] = tc['corner']
            results.append(result)
            
            if result.get('success'):
                success_count += 1
        
        # Summary
        print("\n" + "=" * 80)
        print("BENCHMARK SUMMARY")
        print("=" * 80)
        print(f"Total Tests: {len(test_cases)}")
        print(f"Success: {success_count}")
        print(f"Failed: {len(test_cases) - success_count}")
        print()
        
        # List generated reports
        print("Generated Reports:")
        for result in results:
            if result.get('success'):
                status = "✅"
                wns_str = f"WNS={result.get('wns', 'N/A')}"
            else:
                status = "❌"
                wns_str = f"Error: {result.get('error', 'Unknown')}"
            
            print(f"  {status} {result['design']} ({result['corner']}): {wns_str}")
        
        print("\n" + "=" * 80)
        print(f"✅ Reports saved to: {self.output_dir}")
        print("=" * 80)
        
        return results


def main():
    """Main function"""
    script_dir = Path(__file__).parent
    benchmark_dir = script_dir.parent
    
    print("Note: This script requires OpenSTA to be installed and in PATH")
    print("If not installed, visit: https://github.com/The-OpenROAD-Project/OpenSTA")
    print()
    
    response = input("Continue? (y/n): ")
    if response.lower() != 'y':
        print("Cancelled.")
        return
    
    runner = OpenSTABenchmarkRunner(benchmark_dir)
    results = runner.run_all()
    
    print("\n✅ Benchmark complete!")
    print("Next step: Run comparison script to compare all results with Chronos")
    print("Command: python compare_chronos_opensta.py")


if __name__ == "__main__":
    main()
