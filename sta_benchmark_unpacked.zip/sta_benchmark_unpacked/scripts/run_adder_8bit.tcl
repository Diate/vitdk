# ==============================================================================
# OpenSTA Benchmark Script - 8-bit Adder
# Purpose: Test long combinational path timing (carry chain)
# ==============================================================================

# Read Liberty file (TT corner)
read_liberty ../lib/simple_tt.lib

# Read Verilog netlist
read_verilog ../designs/medium/adder_8bit.v
link_design adder_8bit

# Read parasitics
read_spef ../spef/adder_8bit.spef

# Read constraints
read_sdc ../sdc/adder_8bit.sdc

# ==============================================================================
# Critical Path Analysis
# ==============================================================================
puts "=============================================="
puts "CRITICAL PATH REPORT - adder_8bit (TT)"
puts "=============================================="

# Report worst paths
report_checks -path_delay max -group_count 20

# ==============================================================================
# Carry Chain Analysis
# ==============================================================================
puts "\n=============================================="
puts "CARRY CHAIN TIMING"
puts "=============================================="

# CIN to COUT path (critical)
report_checks -from [get_ports CIN] -to [get_ports COUT] -path_delay max

# CIN to each SUM bit
report_checks -from [get_ports CIN] -to [get_ports SUM*] -path_delay max -group_count 8

# ==============================================================================
# Input to Output Delays
# ==============================================================================
puts "\n=============================================="
puts "A/B INPUT PATHS"
puts "=============================================="

report_checks -from [get_ports A*] -to [get_ports COUT] -path_delay max -group_count 4
report_checks -from [get_ports B*] -to [get_ports COUT] -path_delay max -group_count 4

# ==============================================================================
# Transition and Load Analysis
# ==============================================================================
puts "\n=============================================="
puts "TRANSITION/LOAD ANALYSIS"
puts "=============================================="

report_check_types -max_slew -max_capacitance -max_fanout -violators

# ==============================================================================
# Export Results with Full Metrics
# ==============================================================================

set script_dir [file dirname [info script]]
set report_dir [file join $script_dir ".." "reports" "reports_OpenSTA"]
set report_file [file join $report_dir "adder_8bit_tt_opensta.rpt"]

file mkdir $report_dir

set redirect_file [file join $report_dir "adder_8bit_tt_full.txt"]
redirect -file $redirect_file {
    puts "=========================================================="
    puts "OpenSTA FULL Timing Analysis - adder_8bit (TT Corner)"
    puts "=========================================================="
    puts ""
    
    puts "\n=== WORST SLACK (SETUP) ==="
    report_worst_slack -max
    
    puts "\n=== WORST SLACK (HOLD) ==="
    report_worst_slack -min
    
    puts "\n=== DETAILED SETUP PATHS ==="
    report_checks -path_delay max -group_count 5 -format full_clock
    
    puts "\n=== DETAILED HOLD PATHS ==="
    report_checks -path_delay min -group_count 5 -format full_clock
    
    puts "\n=== TNS (Total Negative Slack) ==="
    report_tns
    
    puts "\n=== CHECK TYPES (Violations) ==="
    report_check_types -max_slew -max_capacitance -max_fanout -violators
    
    puts "\n=========================================================="
}

if {[catch {
    set fp [open $report_file w]

    puts $fp "=========================================================="
    puts $fp "OpenSTA Timing Report - adder_8bit (TT Corner)"
    puts $fp "=========================================================="
    puts $fp ""
    puts $fp "Design: adder_8bit"
    puts $fp "Corner: TT (1.1V, 25C)"
    puts $fp "Process: 45nm"
    puts $fp ""
    puts $fp "Full metrics exported to: adder_8bit_tt_full.txt"
    puts $fp "Clock Period: 10.0 ns (100 MHz)"
    puts $fp ""
    puts $fp "=========================================================="

    close $fp

    puts "\n=========================================================="
    puts "Summary: $report_file"
    puts "Full metrics: $redirect_file"
    puts "=========================================================="
} result]} {
    puts "Error writing report: $result"
}

exit
