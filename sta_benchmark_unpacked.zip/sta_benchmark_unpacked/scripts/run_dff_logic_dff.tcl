# ==============================================================================
# OpenSTA Benchmark Script - DFF Logic DFF (Sequential Design)
# Purpose: Test setup/hold timing and reg-to-reg paths
# ==============================================================================

# Read Liberty file (TT corner)
read_liberty ../lib/simple_tt.lib

# Read Verilog netlist
read_verilog ../designs/small/dff_logic_dff.v
link_design dff_logic_dff

# Read parasitics
read_spef ../spef/dff_logic_dff.spef

# Read constraints
read_sdc ../sdc/dff_logic_dff.sdc

# ==============================================================================
# Setup Timing Analysis
# ==============================================================================
puts "=============================================="
puts "SETUP TIMING REPORT - dff_logic_dff (TT)"
puts "=============================================="

# Report worst setup paths
report_checks -path_delay max -group_count 10

# Report reg-to-reg paths
report_checks -from [get_pins DFF1/Q] -to [get_pins DFF2/D] -path_delay max

# ==============================================================================
# Hold Timing Analysis
# ==============================================================================
puts "\n=============================================="
puts "HOLD TIMING REPORT"
puts "=============================================="

report_checks -path_delay min -group_count 10

# ==============================================================================
# Transition and Load Analysis
# ==============================================================================
puts "\n=============================================="
puts "TRANSITION/LOAD ANALYSIS"
puts "=============================================="

report_check_types -max_slew -max_capacitance -max_fanout -violators

# ==============================================================================
# Export Results with Full Metrics
# ==============================================================================

set script_dir [file dirname [info script]]
set report_dir [file join $script_dir ".." "reports" "reports_OpenSTA"]
set report_file [file join $report_dir "dff_logic_dff_tt_opensta.rpt"]

file mkdir $report_dir

set redirect_file [file join $report_dir "dff_logic_dff_tt_full.txt"]
redirect -file $redirect_file {
    puts "=========================================================="
    puts "OpenSTA FULL Timing Analysis - dff_logic_dff (TT Corner)"
    puts "=========================================================="
    puts ""
    
    puts "\n=== WORST SLACK (SETUP) ==="
    report_worst_slack -max
    
    puts "\n=== WORST SLACK (HOLD) ==="
    report_worst_slack -min
    
    puts "\n=== DETAILED SETUP PATHS ==="
    report_checks -path_delay max -group_count 5 -format full_clock
    
    puts "\n=== DETAILED HOLD PATHS ==="
    report_checks -path_delay min -group_count 5 -format full_clock
    
    puts "\n=== TNS (Total Negative Slack) ==="
    report_tns
    
    puts "\n=== CHECK TYPES (Violations) ==="
    report_check_types -max_slew -max_capacitance -max_fanout -violators
    
    puts "\n=========================================================="
}

if {[catch {
    set fp [open $report_file w]

    puts $fp "=========================================================="
    puts $fp "OpenSTA Timing Report - dff_logic_dff (TT Corner)"
    puts $fp "=========================================================="
    puts $fp ""
    puts $fp "Design: dff_logic_dff"
    puts $fp "Corner: TT (1.1V, 25C)"
    puts $fp "Process: 45nm"
    puts $fp ""
    puts $fp "Full metrics exported to: dff_logic_dff_tt_full.txt"
    puts $fp "Clock Period: 10.0 ns (100 MHz)"
    puts $fp ""
    puts $fp "=========================================================="

    close $fp

    puts "\n=========================================================="
    puts "Summary: $report_file"
    puts "Full metrics: $redirect_file"
    puts "=========================================================="
} result]} {
    puts "Error writing report: $result"
}

exit
