#!/usr/bin/env python3
"""
==============================================================================
STA Results Comparison Tool
Purpose: Compare timing results between OpenSTA and custom STA tool
==============================================================================
"""

import re
import sys
import json
import argparse
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple


@dataclass
class TimingPath:
    """Represents a timing path with delays"""
    startpoint: str
    endpoint: str
    path_type: str  # 'setup' or 'hold'
    arrival_time: float
    required_time: float
    slack: float
    path_delay: float
    cell_delays: List[Tuple[str, float]] = field(default_factory=list)


@dataclass
class TimingReport:
    """Container for timing report data"""
    tool_name: str
    design_name: str
    corner: str
    paths: List[TimingPath] = field(default_factory=list)
    worst_setup_slack: Optional[float] = None
    worst_hold_slack: Optional[float] = None
    wns: Optional[float] = None  # Worst Negative Slack
    tns: Optional[float] = None  # Total Negative Slack


def parse_opensta_report(filepath: Path) -> TimingReport:
    """Parse OpenSTA timing report"""
    report = TimingReport(
        tool_name="OpenSTA",
        design_name="",
        corner="TT"
    )

    with open(filepath, 'r') as f:
        content = f.read()

    # Extract design name
    design_match = re.search(r'Design:\s*(\w+)', content)
    if design_match:
        report.design_name = design_match.group(1)

    # Parse timing paths
    path_pattern = re.compile(
        r'Startpoint:\s*(\S+).*?'
        r'Endpoint:\s*(\S+).*?'
        r'Path Type:\s*(\w+).*?'
        r'slack\s*\((?:MET|VIOLATED)\)\s*([-\d.]+)',
        re.DOTALL
    )

    for match in path_pattern.finditer(content):
        path = TimingPath(
            startpoint=match.group(1),
            endpoint=match.group(2),
            path_type=match.group(3).lower(),
            slack=float(match.group(4)),
            arrival_time=0.0,
            required_time=0.0,
            path_delay=0.0
        )
        report.paths.append(path)

    # Calculate worst slacks
    setup_paths = [p for p in report.paths if p.path_type in ['max', 'setup']]
    hold_paths = [p for p in report.paths if p.path_type in ['min', 'hold']]

    if setup_paths:
        report.worst_setup_slack = min(p.slack for p in setup_paths)
    if hold_paths:
        report.worst_hold_slack = min(p.slack for p in hold_paths)

    return report


def parse_custom_sta_report(filepath: Path) -> TimingReport:
    """Parse custom STA tool report (adapt format as needed)"""
    report = TimingReport(
        tool_name="CustomSTA",
        design_name="",
        corner="TT"
    )

    with open(filepath, 'r') as f:
        content = f.read()

    # Adapt this parsing logic based on your custom tool's output format
    # Example format:
    # PATH: startpoint -> endpoint
    # TYPE: setup/hold
    # SLACK: value

    path_pattern = re.compile(
        r'PATH:\s*(\S+)\s*->\s*(\S+).*?'
        r'TYPE:\s*(\w+).*?'
        r'SLACK:\s*([-\d.]+)',
        re.DOTALL
    )

    for match in path_pattern.finditer(content):
        path = TimingPath(
            startpoint=match.group(1),
            endpoint=match.group(2),
            path_type=match.group(3).lower(),
            slack=float(match.group(4)),
            arrival_time=0.0,
            required_time=0.0,
            path_delay=0.0
        )
        report.paths.append(path)

    if report.paths:
        setup_paths = [p for p in report.paths if p.path_type == 'setup']
        hold_paths = [p for p in report.paths if p.path_type == 'hold']

        if setup_paths:
            report.worst_setup_slack = min(p.slack for p in setup_paths)
        if hold_paths:
            report.worst_hold_slack = min(p.slack for p in hold_paths)

    return report


def parse_csv_report(filepath: Path) -> TimingReport:
    """Parse CSV format timing report"""
    report = TimingReport(
        tool_name="Unknown",
        design_name=filepath.stem,
        corner="TT"
    )

    with open(filepath, 'r') as f:
        lines = f.readlines()

    # Skip header
    for line in lines[1:]:
        parts = line.strip().split(',')
        if len(parts) >= 4:
            path = TimingPath(
                startpoint=parts[0],
                endpoint=parts[1],
                path_type=parts[2],
                slack=float(parts[3]),
                arrival_time=float(parts[4]) if len(parts) > 4 else 0.0,
                required_time=float(parts[5]) if len(parts) > 5 else 0.0,
                path_delay=float(parts[6]) if len(parts) > 6 else 0.0
            )
            report.paths.append(path)

    return report


@dataclass
class ComparisonResult:
    """Result of comparing two timing reports"""
    design_name: str
    corner: str
    tool1_name: str
    tool2_name: str

    # Slack comparisons
    setup_slack_diff: Optional[float] = None
    hold_slack_diff: Optional[float] = None

    # Path-by-path comparison
    path_diffs: List[Dict] = field(default_factory=list)

    # Statistics
    max_slack_diff: float = 0.0
    avg_slack_diff: float = 0.0
    correlation: float = 0.0

    # Pass/Fail
    passed: bool = True
    tolerance: float = 0.01  # 10ps default


def compare_reports(
    report1: TimingReport,
    report2: TimingReport,
    tolerance: float = 0.01
) -> ComparisonResult:
    """Compare two timing reports"""
    result = ComparisonResult(
        design_name=report1.design_name or report2.design_name,
        corner=report1.corner,
        tool1_name=report1.tool_name,
        tool2_name=report2.tool_name,
        tolerance=tolerance
    )

    # Compare worst setup slack
    if report1.worst_setup_slack is not None and report2.worst_setup_slack is not None:
        result.setup_slack_diff = abs(report1.worst_setup_slack - report2.worst_setup_slack)

    # Compare worst hold slack
    if report1.worst_hold_slack is not None and report2.worst_hold_slack is not None:
        result.hold_slack_diff = abs(report1.worst_hold_slack - report2.worst_hold_slack)

    # Path-by-path comparison
    slack_diffs = []
    for path1 in report1.paths:
        # Find matching path in report2
        for path2 in report2.paths:
            if (path1.startpoint == path2.startpoint and
                path1.endpoint == path2.endpoint and
                path1.path_type == path2.path_type):

                diff = abs(path1.slack - path2.slack)
                slack_diffs.append(diff)

                result.path_diffs.append({
                    'startpoint': path1.startpoint,
                    'endpoint': path1.endpoint,
                    'type': path1.path_type,
                    'tool1_slack': path1.slack,
                    'tool2_slack': path2.slack,
                    'difference': diff,
                    'within_tolerance': diff <= tolerance
                })
                break

    # Calculate statistics
    if slack_diffs:
        result.max_slack_diff = max(slack_diffs)
        result.avg_slack_diff = sum(slack_diffs) / len(slack_diffs)

        # Check if all paths are within tolerance
        result.passed = all(d <= tolerance for d in slack_diffs)

    # Check slack differences
    if result.setup_slack_diff and result.setup_slack_diff > tolerance:
        result.passed = False
    if result.hold_slack_diff and result.hold_slack_diff > tolerance:
        result.passed = False

    return result


def print_comparison_report(result: ComparisonResult):
    """Print comparison report to console"""
    print("=" * 70)
    print(f"COMPARISON REPORT: {result.design_name}")
    print(f"Corner: {result.corner}")
    print(f"Tools: {result.tool1_name} vs {result.tool2_name}")
    print("=" * 70)

    # Overall status
    status = "PASS ✓" if result.passed else "FAIL ✗"
    color = "\033[92m" if result.passed else "\033[91m"
    reset = "\033[0m"
    print(f"\nOverall Status: {color}{status}{reset}")
    print(f"Tolerance: {result.tolerance * 1000:.1f} ps")

    # Slack summary
    print("\n--- Worst Slack Comparison ---")
    if result.setup_slack_diff is not None:
        print(f"Setup Slack Difference: {result.setup_slack_diff * 1000:.2f} ps")
    if result.hold_slack_diff is not None:
        print(f"Hold Slack Difference:  {result.hold_slack_diff * 1000:.2f} ps")

    # Statistics
    print("\n--- Statistics ---")
    print(f"Max Path Slack Diff: {result.max_slack_diff * 1000:.2f} ps")
    print(f"Avg Path Slack Diff: {result.avg_slack_diff * 1000:.2f} ps")
    print(f"Paths Compared: {len(result.path_diffs)}")

    # Path details
    if result.path_diffs:
        print("\n--- Path-by-Path Comparison ---")
        print(f"{'Startpoint':<20} {'Endpoint':<20} {'Type':<8} "
              f"{'Tool1':<10} {'Tool2':<10} {'Diff(ps)':<10} {'Status':<8}")
        print("-" * 96)

        for path in result.path_diffs[:20]:  # Show first 20 paths
            status = "OK" if path['within_tolerance'] else "DIFF"
            diff_ps = path['difference'] * 1000
            print(f"{path['startpoint']:<20} {path['endpoint']:<20} "
                  f"{path['type']:<8} {path['tool1_slack']:<10.4f} "
                  f"{path['tool2_slack']:<10.4f} {diff_ps:<10.2f} {status:<8}")

        if len(result.path_diffs) > 20:
            print(f"... and {len(result.path_diffs) - 20} more paths")


def export_comparison_csv(result: ComparisonResult, filepath: Path):
    """Export comparison results to CSV"""
    with open(filepath, 'w') as f:
        f.write("startpoint,endpoint,type,tool1_slack,tool2_slack,difference_ns,within_tolerance\n")
        for path in result.path_diffs:
            f.write(f"{path['startpoint']},{path['endpoint']},{path['type']},"
                   f"{path['tool1_slack']},{path['tool2_slack']},"
                   f"{path['difference']},{path['within_tolerance']}\n")


def export_comparison_json(result: ComparisonResult, filepath: Path):
    """Export comparison results to JSON"""
    data = {
        'design': result.design_name,
        'corner': result.corner,
        'tool1': result.tool1_name,
        'tool2': result.tool2_name,
        'passed': result.passed,
        'tolerance_ns': result.tolerance,
        'setup_slack_diff_ns': result.setup_slack_diff,
        'hold_slack_diff_ns': result.hold_slack_diff,
        'max_slack_diff_ns': result.max_slack_diff,
        'avg_slack_diff_ns': result.avg_slack_diff,
        'num_paths_compared': len(result.path_diffs),
        'path_comparisons': result.path_diffs
    }

    with open(filepath, 'w') as f:
        json.dump(data, f, indent=2)


def main():
    parser = argparse.ArgumentParser(
        description='Compare STA timing reports between tools'
    )
    parser.add_argument('report1', help='First timing report file (OpenSTA)')
    parser.add_argument('report2', help='Second timing report file (Custom STA)')
    parser.add_argument('--format1', choices=['opensta', 'custom', 'csv'],
                       default='opensta', help='Format of first report')
    parser.add_argument('--format2', choices=['opensta', 'custom', 'csv'],
                       default='csv', help='Format of second report')
    parser.add_argument('--tolerance', type=float, default=0.01,
                       help='Tolerance in ns (default: 0.01 = 10ps)')
    parser.add_argument('--output-csv', help='Output CSV file path')
    parser.add_argument('--output-json', help='Output JSON file path')

    args = parser.parse_args()

    # Parse reports
    report1_path = Path(args.report1)
    report2_path = Path(args.report2)

    if not report1_path.exists():
        print(f"Error: File not found: {report1_path}")
        sys.exit(1)
    if not report2_path.exists():
        print(f"Error: File not found: {report2_path}")
        sys.exit(1)

    # Select parser based on format
    parsers = {
        'opensta': parse_opensta_report,
        'custom': parse_custom_sta_report,
        'csv': parse_csv_report
    }

    report1 = parsers[args.format1](report1_path)
    report2 = parsers[args.format2](report2_path)

    # Compare
    result = compare_reports(report1, report2, args.tolerance)

    # Print report
    print_comparison_report(result)

    # Export if requested
    if args.output_csv:
        export_comparison_csv(result, Path(args.output_csv))
        print(f"\nCSV exported to: {args.output_csv}")

    if args.output_json:
        export_comparison_json(result, Path(args.output_json))
        print(f"JSON exported to: {args.output_json}")

    # Return exit code based on pass/fail
    sys.exit(0 if result.passed else 1)


if __name__ == "__main__":
    main()
