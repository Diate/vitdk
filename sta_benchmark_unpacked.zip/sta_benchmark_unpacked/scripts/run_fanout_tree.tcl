# ==============================================================================
# OpenSTA Benchmark Script - Fanout Tree
# Purpose: Test fanout loading effects on timing
# ==============================================================================

# Read Liberty file (TT corner)
read_liberty ../lib/simple_tt.lib

# Read Verilog netlist
read_verilog ../designs/small/fanout_tree.v
link_design fanout_tree

# Read parasitics
read_spef ../spef/fanout_tree.spef

# Read constraints
read_sdc ../sdc/fanout_tree.sdc

# ==============================================================================
# Timing Analysis
# ==============================================================================

puts "=============================================="
puts "TIMING REPORT - fanout_tree (TT Corner)"
puts "=============================================="

# Report all paths with full details
report_checks -path_delay max -format full_clock_expanded

# Report worst setup path
report_checks -path_delay max -group_count 10

# Report worst hold path
report_checks -path_delay min -group_count 5

# ==============================================================================
# Fanout Analysis
# ==============================================================================
puts "\n=============================================="
puts "FANOUT LOADING ANALYSIS"
puts "=============================================="

# Input to all outputs
report_checks -from [get_ports IN] -path_delay max -group_count 20

# ==============================================================================
# Capacitance and Fanout
# ==============================================================================
puts "\n=============================================="
puts "LOAD/FANOUT VIOLATIONS"
puts "=============================================="

report_check_types -max_slew -max_capacitance -max_fanout -violators

# ==============================================================================
# Export Results with Full Metrics
# ==============================================================================

set script_dir [file dirname [info script]]
set report_dir [file join $script_dir ".." "reports" "reports_OpenSTA"]
set report_file [file join $report_dir "fanout_tree_tt_opensta.rpt"]

file mkdir $report_dir

set redirect_file [file join $report_dir "fanout_tree_tt_full.txt"]
redirect -file $redirect_file {
    puts "=========================================================="
    puts "OpenSTA FULL Timing Analysis - fanout_tree (TT Corner)"
    puts "=========================================================="
    puts ""
    
    puts "\n=== WORST SLACK (SETUP) ==="
    report_worst_slack -max
    
    puts "\n=== WORST SLACK (HOLD) ==="
    report_worst_slack -min
    
    puts "\n=== DETAILED SETUP PATHS ==="
    report_checks -path_delay max -group_count 5 -format full_clock
    
    puts "\n=== DETAILED HOLD PATHS ==="
    report_checks -path_delay min -group_count 5 -format full_clock
    
    puts "\n=== TNS (Total Negative Slack) ==="
    report_tns
    
    puts "\n=== CHECK TYPES (Violations) ==="
    report_check_types -max_slew -max_capacitance -max_fanout -violators
    
    puts "\n=========================================================="
}

if {[catch {
    set fp [open $report_file w]

    puts $fp "=========================================================="
    puts $fp "OpenSTA Timing Report - fanout_tree (TT Corner)"
    puts $fp "=========================================================="
    puts $fp ""
    puts $fp "Design: fanout_tree"
    puts $fp "Corner: TT (1.1V, 25C)"
    puts $fp "Process: 45nm"
    puts $fp ""
    puts $fp "Full metrics exported to: fanout_tree_tt_full.txt"
    puts $fp "Clock Period: 10.0 ns (100 MHz)"
    puts $fp ""
    puts $fp "=========================================================="

    close $fp

    puts "\n=========================================================="
    puts "Summary: $report_file"
    puts "Full metrics: $redirect_file"
    puts "=========================================================="
} result]} {
    puts "Error writing report: $result"
}

exit
