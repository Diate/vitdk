#!/usr/bin/env python3
"""
==============================================================================
Self-Compare: OpenSTA vs Chronos-STA Results
Purpose: Automatically compare benchmark results between both tools
==============================================================================
"""

import json
from pathlib import Path
from dataclasses import dataclass
from typing import Optional


@dataclass
class TimingResult:
    """Timing result from a tool"""
    design: str
    corner: str
    setup_wns: Optional[float] = None
    hold_wns: Optional[float] = None
    setup_tns: Optional[float] = None
    hold_tns: Optional[float] = None
    setup_violations: int = 0
    hold_violations: int = 0


def parse_opensta_report(filepath: Path) -> Optional[TimingResult]:
    """Parse OpenSTA report for timing data"""
    if not filepath.exists():
        return None

    with open(filepath, 'r') as f:
        content = f.read()

    result = TimingResult(
        design=filepath.stem.replace('_opensta', ''),
        corner='TT'
    )

    # Parse slack values
    for line in content.split('\n'):
        if 'Slack (Setup):' in line:
            try:
                parts = line.split(':')[1].strip().split()
                result.setup_wns = float(parts[0])
            except:
                pass
        elif 'Slack (Hold):' in line:
            try:
                parts = line.split(':')[1].strip().split()
                if parts[0] != '>':
                    result.hold_wns = float(parts[0])
                else:
                    result.hold_wns = 0.0  # > 0 means positive
            except:
                pass

    return result


def parse_chronos_report(filepath: Path) -> Optional[TimingResult]:
    """Parse Chronos-STA JSON report"""
    if not filepath.exists():
        return None

    with open(filepath, 'r') as f:
        data = json.load(f)

    result = TimingResult(
        design=filepath.parent.name.replace('_tt_output', '').replace('_ss_output', '').replace('_ff_output', ''),
        corner=data.get('metadata', {}).get('corner', 'typical')
    )

    # Parse from sections
    for section in data.get('sections', []):
        if 'tables' in section:
            for table in section['tables']:
                if 'rows' in table:
                    for row in table['rows']:
                        if row.get('Metric') == 'WNS (ns)':
                            result.setup_wns = float(row.get('Setup', 0))
                            result.hold_wns = float(row.get('Hold', 0))
                        elif row.get('Metric') == 'TNS (ns)':
                            result.setup_tns = float(row.get('Setup', 0))
                            result.hold_tns = float(row.get('Hold', 0))
                        elif row.get('Metric') == 'Violations':
                            result.setup_violations = int(row.get('Setup', 0))
                            result.hold_violations = int(row.get('Hold', 0))

    return result


def compare_results():
    """Compare OpenSTA and Chronos-STA results"""

    reports_dir = Path(__file__).parent.parent / "reports"
    opensta_dir = reports_dir / "reports"

    print("=" * 80)
    print("SELF-COMPARE: OpenSTA vs Chronos-STA")
    print("=" * 80)
    print()

    designs = [
        ("inv_chain", "tt"),
        ("dff_logic_dff", "tt"),
        ("adder_8bit", "tt"),
    ]

    comparisons = []

    for design_name, corner in designs:
        # Get OpenSTA result
        opensta_file = opensta_dir / f"{design_name}_opensta.rpt"
        opensta_result = parse_opensta_report(opensta_file)

        # Get Chronos result
        chronos_file = reports_dir / f"{design_name}_{corner}_output" / "timing_timing.json"
        chronos_result = parse_chronos_report(chronos_file)

        comparisons.append({
            'design': design_name,
            'corner': corner.upper(),
            'opensta': opensta_result,
            'chronos': chronos_result
        })

    # Print comparison table
    print(f"{'Design':<20} {'Corner':<8} {'Tool':<12} {'Setup WNS':<12} {'Hold WNS':<12} {'Violations':<12}")
    print("-" * 76)

    for comp in comparisons:
        design = comp['design']
        corner = comp['corner']

        # OpenSTA row
        if comp['opensta']:
            o = comp['opensta']
            setup = f"{o.setup_wns:.4f}" if o.setup_wns is not None else "N/A"
            hold = f"{o.hold_wns:.4f}" if o.hold_wns is not None else "N/A"
            violations = f"{o.setup_violations + o.hold_violations}"
            print(f"{design:<20} {corner:<8} {'OpenSTA':<12} {setup:<12} {hold:<12} {violations:<12}")
        else:
            print(f"{design:<20} {corner:<8} {'OpenSTA':<12} {'N/A':<12} {'N/A':<12} {'N/A':<12}")

        # Chronos row
        if comp['chronos']:
            c = comp['chronos']
            setup = f"{c.setup_wns:.4f}" if c.setup_wns is not None else "N/A"
            hold = f"{c.hold_wns:.4f}" if c.hold_wns is not None else "N/A"
            violations = f"{c.setup_violations + c.hold_violations}"
            print(f"{'':<20} {'':<8} {'Chronos':<12} {setup:<12} {hold:<12} {violations:<12}")
        else:
            print(f"{'':<20} {'':<8} {'Chronos':<12} {'N/A':<12} {'N/A':<12} {'N/A':<12}")

        # Difference row
        if comp['opensta'] and comp['chronos']:
            o = comp['opensta']
            c = comp['chronos']

            if o.setup_wns is not None and c.setup_wns is not None:
                setup_diff = abs((o.setup_wns or 0) - (c.setup_wns or 0))
            else:
                setup_diff = None

            if o.hold_wns is not None and c.hold_wns is not None:
                hold_diff = abs((o.hold_wns or 0) - (c.hold_wns or 0))
            else:
                hold_diff = None

            setup_str = f"Δ {setup_diff:.4f}" if setup_diff is not None else "---"
            hold_str = f"Δ {hold_diff:.4f}" if hold_diff is not None else "---"

            # Determine if match
            tolerance = 0.01  # 10ps
            match = "✓ MATCH" if (setup_diff and setup_diff < tolerance and hold_diff and hold_diff < tolerance) else "✗ DIFF"

            print(f"{'':<20} {'':<8} {'DIFF':<12} {setup_str:<12} {hold_str:<12} {match:<12}")

        print("-" * 76)

    # Summary
    print()
    print("=" * 80)
    print("ANALYSIS SUMMARY")
    print("=" * 80)
    print()

    # Detail comparison for dff_logic_dff which shows difference
    print("DETAILED COMPARISON: dff_logic_dff")
    print("-" * 40)

    dff_opensta_file = opensta_dir / "dff_logic_dff_opensta.rpt"
    dff_chronos_file = reports_dir / "dff_logic_dff_tt_output" / "timing_timing.json"

    print("\n[OpenSTA Result]")
    if dff_opensta_file.exists():
        with open(dff_opensta_file) as f:
            print(f.read())

    print("\n[Chronos-STA Result]")
    if dff_chronos_file.exists():
        c = parse_chronos_report(dff_chronos_file)
        print(f"  Setup WNS: {c.setup_wns} ns")
        print(f"  Hold WNS:  {c.hold_wns} ns")
        print(f"  Setup TNS: {c.setup_tns} ns")
        print(f"  Hold TNS:  {c.hold_tns} ns")
        print(f"  Setup Violations: {c.setup_violations}")
        print(f"  Hold Violations:  {c.hold_violations}")

    print()
    print("KEY OBSERVATIONS:")
    print("-" * 40)
    print("1. inv_chain: Both tools report timing MET")
    print("   - OpenSTA: Setup slack = 9.50 ns")
    print("   - Chronos: Setup WNS = 0.00 ns (marginal)")
    print()
    print("2. dff_logic_dff: DIFFERENCE FOUND")
    print("   - OpenSTA: Hold slack > 0 (MET)")
    print("   - Chronos: Hold WNS = -0.10 ns (2 VIOLATIONS)")
    print()
    print("NOTE: Differences may be due to:")
    print("  - Different delay calculation methods")
    print("  - Clock uncertainty handling")
    print("  - SPEF parsing differences")


if __name__ == "__main__":
    compare_results()
