#!/usr/bin/env python3
"""
OpenSTA Full Metrics Parser
Purpose: Extract timing metrics from OpenSTA full reports (*_full.txt)
Author: Generated for Chronos-STA comparison
Date: 2026-02-12
"""

import os
import re
import json
from pathlib import Path
from typing import Dict, Optional


class OpenSTAFullParser:
    """Parse OpenSTA full timing reports"""
    
    @staticmethod
    def parse_full_report(report_path: str) -> Dict:
        """
        Parse OpenSTA full timing report and extract metrics
        
        Args:
            report_path: Path to *_full.txt file
            
        Returns:
            Dictionary with timing metrics:
            - wns: Worst Negative Slack (setup)
            - whs: Worst Hold Slack
            - tns: Total Negative Slack (setup)
            - ths: Total Hold Slack
            - setup_violations: Number of setup violations
            - hold_violations: Number of hold violations
        """
        if not os.path.exists(report_path):
            return {
                'error': f'File not found: {report_path}',
                'success': False
            }
        
        with open(report_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Extract design and corner from path
        filename = Path(report_path).stem
        parts = filename.replace('_full', '').split('_')
        design = '_'.join(parts[:-1]) if len(parts) > 1 else parts[0]
        corner = parts[-1].upper() if len(parts) > 1 else 'TT'
        
        metrics = {
            'design': design,
            'corner': corner,
            'wns': None,
            'whs': None,
            'tns': None,
            'ths': None,
            'setup_violations': 0,
            'hold_violations': 0,
            'success': True
        }
        
        # Extract WNS (Worst Setup Slack)
        wns_section = re.search(r'=== WORST SLACK \(SETUP\) ===(.*?)(?:===|$)', content, re.DOTALL)
        if wns_section:
            # Look for slack value: "slack 1.23" or "worst slack 1.23"
            slack_match = re.search(r'(?:worst\s+)?slack\s+([-\d.]+)', wns_section.group(1), re.IGNORECASE)
            if slack_match:
                metrics['wns'] = float(slack_match.group(1))
            # Alternative: look for "MET" or "VIOLATED"
            elif 'VIOLATED' in wns_section.group(1):
                # Try to extract negative slack
                neg_match = re.search(r'([-\d.]+)\s*ns', wns_section.group(1))
                if neg_match:
                    metrics['wns'] = float(neg_match.group(1))
        
        # Extract WHS (Worst Hold Slack)
        whs_section = re.search(r'=== WORST SLACK \(HOLD\) ===(.*?)(?:===|$)', content, re.DOTALL)
        if whs_section:
            slack_match = re.search(r'(?:worst\s+)?slack\s+([-\d.]+)', whs_section.group(1), re.IGNORECASE)
            if slack_match:
                metrics['whs'] = float(slack_match.group(1))
            elif 'VIOLATED' in whs_section.group(1):
                neg_match = re.search(r'([-\d.]+)\s*ns', whs_section.group(1))
                if neg_match:
                    metrics['whs'] = float(neg_match.group(1))
        
        # Extract TNS (Total Negative Slack)
        tns_section = re.search(r'=== TNS \(Total Negative Slack\) ===(.*?)(?:===|$)', content, re.DOTALL)
        if tns_section:
            # Look for "setup TNS: -1.23" or "tns -1.23"
            tns_match = re.search(r'(?:setup\s+)?tns[:\s]+([-\d.]+)', tns_section.group(1), re.IGNORECASE)
            if tns_match:
                metrics['tns'] = float(tns_match.group(1))
            
            # Look for "hold TNS: -0.50" 
            ths_match = re.search(r'hold\s+tns[:\s]+([-\d.]+)', tns_section.group(1), re.IGNORECASE)
            if ths_match:
                metrics['ths'] = float(ths_match.group(1))
        
        # Count violations from detailed paths
        setup_section = re.search(r'=== DETAILED SETUP PATHS ===(.*?)(?:===|$)', content, re.DOTALL)
        if setup_section:
            # Count lines with "VIOLATED" or negative slack
            violations = len(re.findall(r'VIOLATED|slack\s+-[\d.]+', setup_section.group(1)))
            metrics['setup_violations'] = violations
        
        hold_section = re.search(r'=== DETAILED HOLD PATHS ===(.*?)(?:===|$)', content, re.DOTALL)
        if hold_section:
            violations = len(re.findall(r'VIOLATED|slack\s+-[\d.]+', hold_section.group(1)))
            metrics['hold_violations'] = violations
        
        # Alternative: parse violations from CHECK TYPES section
        violations_section = re.search(r'=== CHECK TYPES \(Violations\) ===(.*?)(?:===|$)', content, re.DOTALL)
        if violations_section:
            setup_viol_match = re.search(r'setup.*?(\d+)\s+endpoint', violations_section.group(1), re.IGNORECASE)
            if setup_viol_match:
                metrics['setup_violations'] = int(setup_viol_match.group(1))
            
            hold_viol_match = re.search(r'hold.*?(\d+)\s+endpoint', violations_section.group(1), re.IGNORECASE)
            if hold_viol_match:
                metrics['hold_violations'] = int(hold_viol_match.group(1))
        
        return metrics


def parse_all_reports(reports_dir: str, output_json: str = None):
    """
    Parse all OpenSTA full reports in directory
    
    Args:
        reports_dir: Directory containing *_full.txt files
        output_json: Optional path to save JSON output
    """
    parser = OpenSTAFullParser()
    reports_path = Path(reports_dir)
    
    if not reports_path.exists():
        print(f"ERROR: Directory not found: {reports_dir}")
        return
    
    # Find all *_full.txt files
    full_reports = list(reports_path.glob('*_full.txt'))
    
    if not full_reports:
        print(f"WARNING: No *_full.txt files found in {reports_dir}")
        return
    
    print(f"Found {len(full_reports)} OpenSTA full reports")
    print("=" * 80)
    
    all_metrics = []
    
    for report_file in sorted(full_reports):
        print(f"\nParsing: {report_file.name}")
        metrics = parser.parse_full_report(str(report_file))
        
        if metrics.get('success'):
            print(f"  Design: {metrics['design']}")
            print(f"  Corner: {metrics['corner']}")
            print(f"  WNS: {metrics['wns']} ns")
            print(f"  WHS: {metrics['whs']} ns")
            print(f"  TNS: {metrics['tns']} ns")
            print(f"  Setup Violations: {metrics['setup_violations']}")
            print(f"  Hold Violations: {metrics['hold_violations']}")
            all_metrics.append(metrics)
        else:
            print(f"  ERROR: {metrics.get('error', 'Unknown error')}")
    
    print("\n" + "=" * 80)
    print(f"Successfully parsed {len(all_metrics)} reports")
    
    # Save to JSON if requested
    if output_json:
        output_path = Path(output_json)
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(all_metrics, f, indent=2)
        print(f"\nMetrics saved to: {output_json}")
    
    return all_metrics


if __name__ == '__main__':
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python parse_opensta_metrics.py <reports_dir> [output.json]")
        print("\nExample:")
        print("  python parse_opensta_metrics.py ../reports/reports_OpenSTA opensta_metrics.json")
        sys.exit(1)
    
    reports_dir = sys.argv[1]
    output_json = sys.argv[2] if len(sys.argv) > 2 else 'opensta_metrics.json'
    
    parse_all_reports(reports_dir, output_json)
