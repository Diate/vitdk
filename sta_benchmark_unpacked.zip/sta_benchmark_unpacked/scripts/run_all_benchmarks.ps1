# ==============================================================================
# STA Benchmark Runner Script (PowerShell)
# Purpose: Run all benchmarks and collect results
# ==============================================================================

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$BenchmarkDir = Split-Path -Parent $ScriptDir

Write-Host "=============================================="
Write-Host "STA Benchmark Suite Runner"
Write-Host "=============================================="
Write-Host "Benchmark directory: $BenchmarkDir"
Write-Host ""

# Create reports directory
$ReportsDir = Join-Path $BenchmarkDir "reports"
if (-not (Test-Path $ReportsDir)) {
    New-Item -ItemType Directory -Path $ReportsDir | Out-Null
}

# Check if OpenSTA is available
$StaPath = Get-Command sta -ErrorAction SilentlyContinue
if (-not $StaPath) {
    Write-Host "ERROR: OpenSTA (sta) not found in PATH" -ForegroundColor Red
    Write-Host "Please install OpenSTA or add it to PATH"
    exit 1
}

Write-Host "OpenSTA found: $($StaPath.Source)"
Write-Host ""

# ==============================================================================
# Run Small Design Benchmarks
# ==============================================================================
Write-Host "=============================================="
Write-Host "Running Small Design Benchmarks..."
Write-Host "=============================================="

Set-Location $ScriptDir

# Inverter chain
Write-Host ">>> inv_chain..."
& sta run_inv_chain.tcl 2>&1 | Out-File -FilePath "$ReportsDir\inv_chain_full.log"
Write-Host "    Done. Log: reports\inv_chain_full.log"

# DFF logic DFF
Write-Host ">>> dff_logic_dff..."
& sta run_dff_logic_dff.tcl 2>&1 | Out-File -FilePath "$ReportsDir\dff_logic_dff_full.log"
Write-Host "    Done. Log: reports\dff_logic_dff_full.log"

# ==============================================================================
# Run Medium Design Benchmarks
# ==============================================================================
Write-Host ""
Write-Host "=============================================="
Write-Host "Running Medium Design Benchmarks..."
Write-Host "=============================================="

# 8-bit adder
Write-Host ">>> adder_8bit..."
& sta run_adder_8bit.tcl 2>&1 | Out-File -FilePath "$ReportsDir\adder_8bit_full.log"
Write-Host "    Done. Log: reports\adder_8bit_full.log"

# ==============================================================================
# Run Multi-Corner Analysis
# ==============================================================================
Write-Host ""
Write-Host "=============================================="
Write-Host "Running Multi-Corner Analysis..."
Write-Host "=============================================="

& sta run_multicorner.tcl 2>&1 | Out-File -FilePath "$ReportsDir\multicorner_full.log"
Write-Host "    Done. Log: reports\multicorner_full.log"

# ==============================================================================
# Summary
# ==============================================================================
Write-Host ""
Write-Host "=============================================="
Write-Host "Benchmark Suite Complete"
Write-Host "=============================================="
Write-Host "Reports generated in: $ReportsDir"
Get-ChildItem $ReportsDir | Format-Table Name, Length, LastWriteTime

Write-Host ""
Write-Host "To compare with custom STA tool, run:"
Write-Host "  python scripts\compare_results.py"
