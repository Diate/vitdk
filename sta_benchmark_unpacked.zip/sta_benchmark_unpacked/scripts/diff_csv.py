#!/usr/bin/env python3
"""
==============================================================================
Timing Report Diff Tool
Purpose: Generate detailed diff between two timing report CSVs
==============================================================================
"""

import sys
import csv
import argparse
from pathlib import Path
from typing import Dict, List, Tuple


def read_timing_csv(filepath: Path) -> Dict[Tuple[str, str, str], Dict]:
    """Read timing CSV file into dictionary keyed by (start, end, type)"""
    data = {}

    with open(filepath, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            key = (
                row.get('startpoint', row.get('start', '')),
                row.get('endpoint', row.get('end', '')),
                row.get('type', row.get('path_type', 'setup'))
            )
            data[key] = {
                'slack': float(row.get('slack', 0)),
                'arrival': float(row.get('arrival', row.get('arrival_time', 0))),
                'required': float(row.get('required', row.get('required_time', 0))),
            }

    return data


def diff_timing_reports(
    file1: Path,
    file2: Path,
    tolerance: float = 0.001
) -> Tuple[List[Dict], Dict]:
    """
    Compare two timing report CSVs
    Returns (differences, summary)
    """
    data1 = read_timing_csv(file1)
    data2 = read_timing_csv(file2)

    differences = []

    # Find all unique paths
    all_keys = set(data1.keys()) | set(data2.keys())

    for key in all_keys:
        path1 = data1.get(key)
        path2 = data2.get(key)

        diff_entry = {
            'startpoint': key[0],
            'endpoint': key[1],
            'type': key[2],
            'in_file1': path1 is not None,
            'in_file2': path2 is not None,
        }

        if path1 and path2:
            slack_diff = abs(path1['slack'] - path2['slack'])
            diff_entry['slack1'] = path1['slack']
            diff_entry['slack2'] = path2['slack']
            diff_entry['slack_diff'] = slack_diff
            diff_entry['within_tolerance'] = slack_diff <= tolerance

            if slack_diff > tolerance:
                differences.append(diff_entry)
        else:
            # Path exists in only one file
            diff_entry['slack1'] = path1['slack'] if path1 else None
            diff_entry['slack2'] = path2['slack'] if path2 else None
            diff_entry['slack_diff'] = None
            diff_entry['within_tolerance'] = False
            differences.append(diff_entry)

    # Calculate summary
    matching = len(data1.keys() & data2.keys())
    only_in_1 = len(data1.keys() - data2.keys())
    only_in_2 = len(data2.keys() - data1.keys())

    slack_diffs = [d['slack_diff'] for d in differences
                   if d['slack_diff'] is not None]

    summary = {
        'total_paths_file1': len(data1),
        'total_paths_file2': len(data2),
        'matching_paths': matching,
        'only_in_file1': only_in_1,
        'only_in_file2': only_in_2,
        'paths_with_diff': len([d for d in differences if d.get('slack_diff')]),
        'max_slack_diff': max(slack_diffs) if slack_diffs else 0,
        'avg_slack_diff': sum(slack_diffs) / len(slack_diffs) if slack_diffs else 0,
        'passed': len(differences) == 0
    }

    return differences, summary


def print_diff_report(differences: List[Dict], summary: Dict, tolerance: float):
    """Print diff report to console"""
    print("=" * 70)
    print("TIMING REPORT DIFF")
    print("=" * 70)

    # Summary
    print(f"\nTolerance: {tolerance * 1000:.1f} ps")
    print(f"\nFile 1 paths: {summary['total_paths_file1']}")
    print(f"File 2 paths: {summary['total_paths_file2']}")
    print(f"Matching:     {summary['matching_paths']}")
    print(f"Only in F1:   {summary['only_in_file1']}")
    print(f"Only in F2:   {summary['only_in_file2']}")

    if summary['paths_with_diff'] > 0:
        print(f"\nMax slack diff: {summary['max_slack_diff'] * 1000:.2f} ps")
        print(f"Avg slack diff: {summary['avg_slack_diff'] * 1000:.2f} ps")

    # Status
    status = "IDENTICAL" if summary['passed'] else "DIFFERENT"
    color = "\033[92m" if summary['passed'] else "\033[91m"
    reset = "\033[0m"
    print(f"\nStatus: {color}{status}{reset}")

    # Details
    if differences:
        print("\n--- Differences ---")
        print(f"{'Startpoint':<25} {'Endpoint':<25} {'Type':<8} "
              f"{'Slack1':<10} {'Slack2':<10} {'Diff(ps)':<10}")
        print("-" * 98)

        for diff in differences[:50]:  # Limit to first 50
            s1 = f"{diff['slack1']:.4f}" if diff['slack1'] is not None else "N/A"
            s2 = f"{diff['slack2']:.4f}" if diff['slack2'] is not None else "N/A"
            d = f"{diff['slack_diff'] * 1000:.2f}" if diff['slack_diff'] is not None else "---"

            print(f"{diff['startpoint']:<25} {diff['endpoint']:<25} "
                  f"{diff['type']:<8} {s1:<10} {s2:<10} {d:<10}")

        if len(differences) > 50:
            print(f"... and {len(differences) - 50} more differences")


def export_diff_csv(differences: List[Dict], filepath: Path):
    """Export diff to CSV file"""
    with open(filepath, 'w', newline='') as f:
        fieldnames = ['startpoint', 'endpoint', 'type', 'in_file1', 'in_file2',
                     'slack1', 'slack2', 'slack_diff', 'within_tolerance']
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(differences)


def main():
    parser = argparse.ArgumentParser(description='Diff two timing report CSVs')
    parser.add_argument('file1', help='First timing report CSV')
    parser.add_argument('file2', help='Second timing report CSV')
    parser.add_argument('--tolerance', type=float, default=0.001,
                       help='Tolerance in ns (default: 0.001 = 1ps)')
    parser.add_argument('--output', help='Output diff CSV file')

    args = parser.parse_args()

    file1 = Path(args.file1)
    file2 = Path(args.file2)

    if not file1.exists():
        print(f"Error: {file1} not found")
        sys.exit(1)
    if not file2.exists():
        print(f"Error: {file2} not found")
        sys.exit(1)

    differences, summary = diff_timing_reports(file1, file2, args.tolerance)
    print_diff_report(differences, summary, args.tolerance)

    if args.output:
        export_diff_csv(differences, Path(args.output))
        print(f"\nDiff exported to: {args.output}")

    sys.exit(0 if summary['passed'] else 1)


if __name__ == "__main__":
    main()
