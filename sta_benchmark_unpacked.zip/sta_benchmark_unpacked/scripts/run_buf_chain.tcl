# ==============================================================================
# OpenSTA Benchmark Script - Buffer Chain
# Purpose: Test buffer chain timing and transition propagation
# ==============================================================================

# Read Liberty file (TT corner)
read_liberty ../lib/simple_tt.lib

# Read Verilog netlist
read_verilog ../designs/small/buf_chain.v
link_design buf_chain

# Read parasitics
read_spef ../spef/buf_chain.spef

# Read constraints
read_sdc ../sdc/buf_chain.sdc

# ==============================================================================
# Timing Analysis
# ==============================================================================

puts "=============================================="
puts "TIMING REPORT - buf_chain (TT Corner)"
puts "=============================================="

# Report all paths with full details
report_checks -path_delay max -format full_clock_expanded

# Report worst setup path
report_checks -path_delay max -group_count 5

# Report worst hold path
report_checks -path_delay min -group_count 5

# ==============================================================================
# Buffer Chain Analysis
# ==============================================================================
puts "\n=============================================="
puts "BUFFER PROPAGATION DELAY"
puts "=============================================="

# Input to output path
report_checks -from [get_ports IN] -to [get_ports OUT] -path_delay max

# ==============================================================================
# Transition Analysis
# ==============================================================================
puts "\n=============================================="
puts "SLEW/TRANSITION REPORT"
puts "=============================================="

report_check_types -max_slew -max_capacitance -max_fanout -violators

# ==============================================================================
# Export Results with Full Metrics
# ==============================================================================

set script_dir [file dirname [info script]]
set report_dir [file join $script_dir ".." "reports" "reports_OpenSTA"]
set report_file [file join $report_dir "buf_chain_tt_opensta.rpt"]

file mkdir $report_dir

# Redirect full timing analysis to capture all metrics
set redirect_file [file join $report_dir "buf_chain_tt_full.txt"]
redirect -file $redirect_file {
    puts "=========================================================="
    puts "OpenSTA FULL Timing Analysis - buf_chain (TT Corner)"
    puts "=========================================================="
    puts ""
    
    puts "\n=== WORST SLACK (SETUP) ==="
    report_worst_slack -max
    
    puts "\n=== WORST SLACK (HOLD) ==="
    report_worst_slack -min
    
    puts "\n=== DETAILED SETUP PATHS ==="
    report_checks -path_delay max -group_count 5 -format full_clock
    
    puts "\n=== DETAILED HOLD PATHS ==="
    report_checks -path_delay min -group_count 5 -format full_clock
    
    puts "\n=== TNS (Total Negative Slack) ==="
    report_tns
    
    puts "\n=== CHECK TYPES (Violations) ==="
    report_check_types -max_slew -max_capacitance -max_fanout -violators
    
    puts "\n=========================================================="
}

if {[catch {
    set fp [open $report_file w]

    puts $fp "=========================================================="
    puts $fp "OpenSTA Timing Report - buf_chain (TT Corner)"
    puts $fp "=========================================================="
    puts $fp ""
    puts $fp "Design: buf_chain"
    puts $fp "Corner: TT (1.1V, 25C)"
    puts $fp "Process: 45nm"
    puts $fp ""
    puts $fp "Full metrics exported to: buf_chain_tt_full.txt"
    puts $fp "Clock Period: 10.0 ns (100 MHz)"
    puts $fp ""
    puts $fp "=========================================================="

    close $fp

    puts "\n=========================================================="
    puts "Summary: $report_file"
    puts "Full metrics: $redirect_file"
    puts "=========================================================="
} result]} {
    puts "Error writing report: $result"
}

exit
