# ==============================================================================
# OpenSTA Benchmark Script - Clock Tree
# Purpose: Test clock distribution and skew
# ==============================================================================

# Read Liberty file (TT corner)
read_liberty ../lib/simple_tt.lib

# Read Verilog netlist
read_verilog ../designs/small/clock_tree.v
link_design clock_tree

# Read parasitics
read_spef ../spef/clock_tree.spef

# Read constraints
read_sdc ../sdc/clock_tree.sdc

# ==============================================================================
# Timing Analysis
# ==============================================================================

puts "=============================================="
puts "TIMING REPORT - clock_tree (TT Corner)"
puts "=============================================="

# Report all paths with full details
report_checks -path_delay max -format full_clock_expanded

# Report worst setup path
report_checks -path_delay max -group_count 10

# Report worst hold path
report_checks -path_delay min -group_count 10

# ==============================================================================
# Clock Tree Analysis
# ==============================================================================
puts "\n=============================================="
puts "CLOCK DISTRIBUTION ANALYSIS"
puts "=============================================="

# Report clock paths
report_clocks

# Clock skew analysis
report_checks -path_delay min_max -group_count 10

# ==============================================================================
# Setup and Hold
# ==============================================================================
puts "\n=============================================="
puts "SETUP/HOLD ANALYSIS"
puts "=============================================="

report_checks -path_delay max -format full_clock
report_checks -path_delay min -format full_clock

# ==============================================================================
# Export Results with Full Metrics
# ==============================================================================

set script_dir [file dirname [info script]]
set report_dir [file join $script_dir ".." "reports" "reports_OpenSTA"]
set report_file [file join $report_dir "clock_tree_tt_opensta.rpt"]

file mkdir $report_dir

set redirect_file [file join $report_dir "clock_tree_tt_full.txt"]
redirect -file $redirect_file {
    puts "=========================================================="
    puts "OpenSTA FULL Timing Analysis - clock_tree (TT Corner)"
    puts "=========================================================="
    puts ""
    
    puts "\n=== WORST SLACK (SETUP) ==="
    report_worst_slack -max
    
    puts "\n=== WORST SLACK (HOLD) ==="
    report_worst_slack -min
    
    puts "\n=== DETAILED SETUP PATHS ==="
    report_checks -path_delay max -group_count 5 -format full_clock
    
    puts "\n=== DETAILED HOLD PATHS ==="
    report_checks -path_delay min -group_count 5 -format full_clock
    
    puts "\n=== TNS (Total Negative Slack) ==="
    report_tns
    
    puts "\n=== CHECK TYPES (Violations) ==="
    report_check_types -max_slew -max_capacitance -max_fanout -violators
    
    puts "\n=========================================================="
}

if {[catch {
    set fp [open $report_file w]

    puts $fp "=========================================================="
    puts $fp "OpenSTA Timing Report - clock_tree (TT Corner)"
    puts $fp "=========================================================="
    puts $fp ""
    puts $fp "Design: clock_tree"
    puts $fp "Corner: TT (1.1V, 25C)"
    puts $fp "Process: 45nm"
    puts $fp ""
    puts $fp "Full metrics exported to: clock_tree_tt_full.txt"
    puts $fp "Clock Period: 10.0 ns (100 MHz)"
    puts $fp ""
    puts $fp "=========================================================="

    close $fp

    puts "\n=========================================================="
    puts "Summary: $report_file"
    puts "Full metrics: $redirect_file"
    puts "=========================================================="
} result]} {
    puts "Error writing report: $result"
}

exit
