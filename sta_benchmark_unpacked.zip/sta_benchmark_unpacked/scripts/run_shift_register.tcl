# ==============================================================================
# OpenSTA Benchmark Script - Shift Register
# Purpose: Test sequential path timing with long register chains
# ==============================================================================

# Read Liberty file (TT corner)
read_liberty ../lib/simple_tt.lib

# Read Verilog netlist
read_verilog ../designs/medium/shift_register.v
link_design shift_register

# Read parasitics
read_spef ../spef/shift_register.spef

# Read constraints
read_sdc ../sdc/shift_register.sdc

# ==============================================================================
# Timing Analysis
# ==============================================================================

puts "=============================================="
puts "TIMING REPORT - shift_register (TT Corner)"
puts "=============================================="

# Report all paths with full details
report_checks -path_delay max -format full_clock_expanded

# Report worst setup paths
report_checks -path_delay max -group_count 15

# Report worst hold paths
report_checks -path_delay min -group_count 15

# ==============================================================================
# Sequential Path Analysis
# ==============================================================================
puts "\n=============================================="
puts "REGISTER TO REGISTER PATHS"
puts "=============================================="

# Clock to Q paths
report_checks -path_delay max -group_count 10

# Setup timing
report_checks -path_delay max -format full_clock

# Hold timing
report_checks -path_delay min -format full_clock

# ==============================================================================
# Clock Analysis
# ==============================================================================
puts "\n=============================================="
puts "CLOCK NETWORK ANALYSIS"
puts "=============================================="

report_clocks

# ==============================================================================
# Export Results with Full Metrics
# ==============================================================================

set script_dir [file dirname [info script]]
set report_dir [file join $script_dir ".." "reports" "reports_OpenSTA"]
set report_file [file join $report_dir "shift_register_tt_opensta.rpt"]

file mkdir $report_dir

set redirect_file [file join $report_dir "shift_register_tt_full.txt"]
redirect -file $redirect_file {
    puts "=========================================================="
    puts "OpenSTA FULL Timing Analysis - shift_register (TT Corner)"
    puts "=========================================================="
    puts ""
    
    puts "\n=== WORST SLACK (SETUP) ==="
    report_worst_slack -max
    
    puts "\n=== WORST SLACK (HOLD) ==="
    report_worst_slack -min
    
    puts "\n=== DETAILED SETUP PATHS ==="
    report_checks -path_delay max -group_count 5 -format full_clock
    
    puts "\n=== DETAILED HOLD PATHS ==="
    report_checks -path_delay min -group_count 5 -format full_clock
    
    puts "\n=== TNS (Total Negative Slack) ==="
    report_tns
    
    puts "\n=== CHECK TYPES (Violations) ==="
    report_check_types -max_slew -max_capacitance -max_fanout -violators
    
    puts "\n=========================================================="
}

if {[catch {
    set fp [open $report_file w]

    puts $fp "=========================================================="
    puts $fp "OpenSTA Timing Report - shift_register (TT Corner)"
    puts $fp "=========================================================="
    puts $fp ""
    puts $fp "Design: shift_register"
    puts $fp "Corner: TT (1.1V, 25C)"
    puts $fp "Process: 45nm"
    puts $fp ""
    puts $fp "Full metrics exported to: shift_register_tt_full.txt"
    puts $fp "Clock Period: 10.0 ns (100 MHz)"
    puts $fp ""
    puts $fp "=========================================================="

    close $fp

    puts "\n=========================================================="
    puts "Summary: $report_file"
    puts "Full metrics: $redirect_file"
    puts "=========================================================="
} result]} {
    puts "Error writing report: $result"
}

exit
