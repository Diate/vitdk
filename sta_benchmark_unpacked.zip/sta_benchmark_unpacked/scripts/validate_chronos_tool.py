#!/usr/bin/env python3
"""
==============================================================================
Chronos-STA Tool Validation & Quality Analysis
Purpose: Independent validation of Chronos STA tool accuracy and reliability
Author: STA Validation Framework
Date: 2026-02-12
==============================================================================

This script performs comprehensive validation of the Chronos STA tool by:
1. Analyzing internal consistency of results
2. Checking against expected values from test fixtures
3. Validating timing metrics logic
4. Cross-corner analysis
5. Performance benchmarking
6. Quality assessment and recommendations
"""

import json
import os
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
import statistics


@dataclass
class ValidationResult:
    """Validation test result"""
    test_name: str
    category: str
    passed: bool
    severity: str  # 'critical', 'major', 'minor', 'info'
    expected: Optional[float] = None
    actual: Optional[float] = None
    tolerance: Optional[float] = None
    difference: Optional[float] = None
    message: str = ""
    details: str = ""


@dataclass
class ValidationReport:
    """Complete validation report"""
    tool_name: str = "Chronos-STA"
    test_date: str = ""
    total_tests: int = 0
    passed_tests: int = 0
    failed_tests: int = 0
    critical_issues: int = 0
    major_issues: int = 0
    minor_issues: int = 0
    overall_score: float = 0.0
    confidence_level: str = ""
    results: List[ValidationResult] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)


class ChronosValidator:
    """Validates Chronos STA tool results"""
    
    def __init__(self, benchmark_dir: Path, chronos_dir: Path):
        self.benchmark_dir = benchmark_dir
        self.chronos_dir = chronos_dir
        self.report = ValidationReport()
        
    def load_chronos_results(self) -> Dict:
        """Load Chronos benchmark results"""
        json_file = self.benchmark_dir / "reports" / "report_chronos" / "chronos_benchmark_20260212_201332.json"
        
        if not json_file.exists():
            print(f"❌ Error: Chronos results not found: {json_file}")
            return None
        
        with open(json_file, 'r') as f:
            data = json.load(f)
        
        # Also load detailed results
        detailed_results = {}
        chronos_reports = self.benchmark_dir / "reports" / "report_chronos"
        
        for result in data.get('results', []):
            design = result['design']
            corner = result['corner'].lower()
            
            # Load detailed JSON
            json_path = chronos_reports / f"{design}_{corner}_output" / "timing_timing.json"
            if json_path.exists():
                with open(json_path, 'r') as f:
                    detailed = json.load(f)
                    detailed_results[f"{design}_{corner}"] = detailed
        
        data['detailed'] = detailed_results
        return data
    
    def load_expected_values(self) -> Dict:
        """Load expected values from test fixtures"""
        expected = {}
        fixtures_dir = self.chronos_dir / "tests" / "fixtures" / "designs"
        
        if not fixtures_dir.exists():
            return expected
        
        for design_dir in fixtures_dir.iterdir():
            if design_dir.is_dir():
                expected_file = design_dir / "expected_outputs.json"
                if expected_file.exists():
                    with open(expected_file, 'r') as f:
                        expected[design_dir.name] = json.load(f)
        
        return expected
    
    def validate_against_expected(self, chronos_data: Dict, expected_data: Dict) -> List[ValidationResult]:
        """Validate Chronos results against expected values"""
        results = []
        
        for design_name, expected in expected_data.items():
            # Find matching Chronos result
            chronos_result = None
            for result in chronos_data.get('results', []):
                if design_name in result['design']:
                    chronos_result = result
                    break
            
            if not chronos_result:
                continue
            
            # Get expected summary
            expected_summary = expected.get('expected_summary', {})
            
            # Validate WNS (Worst Negative Slack)
            if 'wns' in expected_summary:
                expected_wns = expected_summary['wns'] / 1000.0  # Convert ps to ns
                actual_wns = chronos_result.get('wns', 0.0)
                tolerance = expected_summary.get('wns', 0) * 0.1 / 1000.0  # 10% tolerance
                
                diff = abs(expected_wns - actual_wns)
                passed = diff <= tolerance
                
                vr = ValidationResult(
                    test_name=f"{design_name}_WNS",
                    category="Expected Value Match",
                    passed=passed,
                    severity='critical' if not passed else 'info',
                    expected=expected_wns,
                    actual=actual_wns,
                    tolerance=tolerance,
                    difference=diff,
                    message=f"WNS validation for {design_name}",
                    details=f"Expected: {expected_wns:.6f} ns, Actual: {actual_wns:.6f} ns, Diff: {diff:.6f} ns"
                )
                results.append(vr)
            
            # Validate TNS (Total Negative Slack)
            if 'tns' in expected_summary:
                expected_tns = expected_summary['tns'] / 1000.0
                # TNS not directly in basic result, skip for now
                pass
            
            # Validate violations count
            if 'num_setup_violations' in expected_summary:
                expected_viol = expected_summary['num_setup_violations']
                # Need detailed result for this
                pass
        
        return results
    
    def validate_internal_consistency(self, chronos_data: Dict) -> List[ValidationResult]:
        """Check internal consistency of Chronos results"""
        results = []
        
        for result in chronos_data.get('results', []):
            design = result['design']
            corner = result['corner']
            wns = result.get('wns')
            whs = result.get('whs')
            
            # Test 1: WNS should be <= 0 if there are violations, >= 0 if timing met
            if wns is not None:
                passed = wns >= 0  # Since all tests show timing met
                vr = ValidationResult(
                    test_name=f"{design}_{corner}_WNS_Sign",
                    category="Internal Consistency",
                    passed=passed,
                    severity='critical' if not passed else 'info',
                    actual=wns,
                    message=f"WNS sign check for {design} ({corner})",
                    details=f"WNS={wns:.6f} ns. Positive WNS indicates timing met (slack available)."
                )
                results.append(vr)
            
            # Test 2: Success flag should match WNS >= 0
            success = result.get('success', False)
            if wns is not None:
                expected_success = wns >= 0
                passed = success == expected_success
                vr = ValidationResult(
                    test_name=f"{design}_{corner}_Success_Flag",
                    category="Internal Consistency",
                    passed=passed,
                    severity='major' if not passed else 'info',
                    message=f"Success flag consistency for {design} ({corner})",
                    details=f"Success={success}, WNS={wns:.6f}. Flags are {'consistent' if passed else 'inconsistent'}."
                )
                results.append(vr)
            
            # Test 3: Runtime should be reasonable (0.5s to 10s for small designs)
            runtime = result.get('runtime_seconds', 0)
            passed = 0.1 < runtime < 30.0
            severity = 'minor' if not passed else 'info'
            vr = ValidationResult(
                test_name=f"{design}_{corner}_Runtime",
                category="Performance",
                passed=passed,
                severity=severity,
                actual=runtime,
                message=f"Runtime check for {design} ({corner})",
                details=f"Runtime={runtime:.4f}s. {'Acceptable' if passed else 'Unusual - may indicate issues'}"
            )
            results.append(vr)
        
        return results
    
    def validate_cross_corner(self, chronos_data: Dict) -> List[ValidationResult]:
        """Validate cross-corner analysis"""
        results = []
        
        # Group results by design
        by_design = {}
        for result in chronos_data.get('results', []):
            design = result['design']
            if design not in by_design:
                by_design[design] = []
            by_design[design].append(result)
        
        # Check multi-corner designs
        for design, corners in by_design.items():
            if len(corners) > 1:
                # For sequential designs, different corners should have different hold slack
                whs_values = [r.get('whs') for r in corners if r.get('whs') not in [None, float('inf')]]
                
                if len(whs_values) > 1:
                    # WHS should vary across corners (SS < TT < FF typically)
                    all_same = len(set(whs_values)) == 1
                    passed = not all_same
                    vr = ValidationResult(
                        test_name=f"{design}_Cross_Corner_Variation",
                        category="Cross-Corner Analysis",
                        passed=passed,
                        severity='minor' if not passed else 'info',
                        message=f"Cross-corner WHS variation for {design}",
                        details=f"WHS values across corners: {whs_values}. {'Varies as expected' if passed else 'Suspicious - all corners have same WHS'}"
                    )
                    results.append(vr)
        
        return results
    
    def validate_timing_metrics(self, chronos_data: Dict) -> List[ValidationResult]:
        """Validate timing metrics logic"""
        results = []
        
        detailed = chronos_data.get('detailed', {})
        
        for key, data in detailed.items():
            # Extract metrics from detailed JSON
            for section in data.get('sections', []):
                if 'TIMING SUMMARY' in section.get('title', ''):
                    tables = section.get('tables', [])
                    if tables:
                        metrics = {}
                        for row in tables[0].get('rows', []):
                            metric = row.get('Metric', '')
                            setup = row.get('Setup', '')
                            hold = row.get('Hold', '')
                            
                            if metric == 'WNS (ns)':
                                metrics['wns_setup'] = float(setup) if setup and setup != 'inf' else None
                                metrics['wns_hold'] = float(hold) if hold and hold != 'inf' else None
                            elif metric == 'TNS (ns)':
                                metrics['tns_setup'] = float(setup) if setup else None
                                metrics['tns_hold'] = float(hold) if hold else None
                            elif metric == 'Violations':
                                metrics['viol_setup'] = int(float(setup)) if setup else 0
                                metrics['viol_hold'] = int(float(hold)) if hold else 0
                        
                        # Validate: If WNS >= 0, violations should be 0
                        design_name = key.replace('_tt', '').replace('_ss', '').replace('_ff', '')
                        
                        if metrics.get('wns_setup') is not None and metrics.get('viol_setup') is not None:
                            wns = metrics['wns_setup']
                            viol = metrics['viol_setup']
                            passed = (wns >= 0 and viol == 0) or (wns < 0 and viol > 0)
                            
                            vr = ValidationResult(
                                test_name=f"{key}_WNS_Violations_Consistency",
                                category="Metrics Logic",
                                passed=passed,
                                severity='critical' if not passed else 'info',
                                message=f"WNS and violations consistency for {key}",
                                details=f"WNS={wns:.6f}ns, Violations={viol}. {'Consistent' if passed else 'INCONSISTENT!'}"
                            )
                            results.append(vr)
                        
                        # Validate: If TNS = 0, there should be no violations
                        if metrics.get('tns_setup') is not None and metrics.get('viol_setup') is not None:
                            tns = metrics['tns_setup']
                            viol = metrics['viol_setup']
                            passed = (tns == 0 and viol == 0) or (tns != 0 and viol > 0)
                            
                            vr = ValidationResult(
                                test_name=f"{key}_TNS_Violations_Consistency",
                                category="Metrics Logic",
                                passed=passed,
                                severity='major' if not passed else 'info',
                                message=f"TNS and violations consistency for {key}",
                                details=f"TNS={tns:.6f}ns, Violations={viol}. {'Consistent' if passed else 'INCONSISTENT!'}"
                            )
                            results.append(vr)
        
        return results
    
    def calculate_score(self) -> Tuple[float, str]:
        """Calculate overall validation score"""
        if not self.report.results:
            return 0.0, "UNKNOWN"
        
        total = len(self.report.results)
        passed = sum(1 for r in self.report.results if r.passed)
        
        # Weight by severity
        score = 0.0
        max_score = 0.0
        
        for result in self.report.results:
            weight = {'critical': 10, 'major': 5, 'minor': 2, 'info': 1}[result.severity]
            max_score += weight
            if result.passed:
                score += weight
        
        percentage = (score / max_score * 100) if max_score > 0 else 0
        
        # Determine confidence level
        if percentage >= 95:
            confidence = "EXCELLENT - Highly Reliable"
        elif percentage >= 85:
            confidence = "GOOD - Reliable with Minor Issues"
        elif percentage >= 70:
            confidence = "ACCEPTABLE - Has Some Issues"
        elif percentage >= 50:
            confidence = "POOR - Significant Issues Found"
        else:
            confidence = "CRITICAL - Major Problems Detected"
        
        return percentage, confidence
    
    def generate_recommendations(self):
        """Generate recommendations based on validation results"""
        recs = []
        
        # Check for critical issues
        critical = [r for r in self.report.results if not r.passed and r.severity == 'critical']
        if critical:
            recs.append(f"🔴 CRITICAL: {len(critical)} critical issues found - tool may produce incorrect results")
            for issue in critical[:3]:  # Show top 3
                recs.append(f"   - {issue.test_name}: {issue.message}")
        
        # Check for major issues
        major = [r for r in self.report.results if not r.passed and r.severity == 'major']
        if major:
            recs.append(f"🟠 WARNING: {len(major)} major issues found - results may be unreliable")
        
        # Check performance
        runtimes = [r.actual for r in self.report.results if r.category == 'Performance' and r.actual]
        if runtimes:
            avg_runtime = statistics.mean(runtimes)
            if avg_runtime > 5.0:
                recs.append(f"⚡ PERFORMANCE: Average runtime {avg_runtime:.2f}s - consider optimization")
        
        # If all passed
        if self.report.critical_issues == 0 and self.report.major_issues == 0:
            recs.append("✅ VALIDATION PASSED: No critical or major issues found")
            recs.append("✅ Tool appears to be working correctly for tested designs")
            recs.append("📝 Recommendation: Validate with more complex designs and compare with industry tools")
        
        # Always recommend
        recs.append("📊 Next Steps:")
        recs.append("   1. Compare with OpenSTA or commercial tools (PrimeTime, Tempus)")
        recs.append("   2. Test with real production designs")
        recs.append("   3. Validate on corner cases (tight timing, multi-clock domains)")
        recs.append("   4. Benchmark against known golden references")
        
        self.report.recommendations = recs
    
    def run_validation(self) -> ValidationReport:
        """Run complete validation suite"""
        print("=" * 80)
        print("Chronos-STA Tool Validation Analysis")
        print("=" * 80)
        print()
        
        # Load data
        print("📊 Loading Chronos results...")
        chronos_data = self.load_chronos_results()
        if not chronos_data:
            return self.report
        print(f"✓ Loaded {len(chronos_data.get('results', []))} benchmark results")
        
        print("\n📚 Loading expected values from test fixtures...")
        expected_data = self.load_expected_values()
        print(f"✓ Found expected values for {len(expected_data)} designs")
        
        # Run validation tests
        print("\n🔍 Running validation tests...")
        
        print("  1️⃣  Validating against expected values...")
        self.report.results.extend(self.validate_against_expected(chronos_data, expected_data))
        
        print("  2️⃣  Checking internal consistency...")
        self.report.results.extend(self.validate_internal_consistency(chronos_data))
        
        print("  3️⃣  Validating cross-corner analysis...")
        self.report.results.extend(self.validate_cross_corner(chronos_data))
        
        print("  4️⃣  Validating timing metrics logic...")
        self.report.results.extend(self.validate_timing_metrics(chronos_data))
        
        # Calculate statistics
        self.report.total_tests = len(self.report.results)
        self.report.passed_tests = sum(1 for r in self.report.results if r.passed)
        self.report.failed_tests = self.report.total_tests - self.report.passed_tests
        
        self.report.critical_issues = sum(1 for r in self.report.results if not r.passed and r.severity == 'critical')
        self.report.major_issues = sum(1 for r in self.report.results if not r.passed and r.severity == 'major')
        self.report.minor_issues = sum(1 for r in self.report.results if not r.passed and r.severity == 'minor')
        
        self.report.overall_score, self.report.confidence_level = self.calculate_score()
        
        # Generate recommendations
        self.generate_recommendations()
        
        print(f"\n✓ Validation complete: {self.report.passed_tests}/{self.report.total_tests} tests passed")
        
        return self.report
    
    def print_report(self):
        """Print validation report"""
        print("\n" + "=" * 80)
        print("VALIDATION REPORT SUMMARY")
        print("=" * 80)
        print(f"Tool: {self.report.tool_name}")
        print(f"Total Tests: {self.report.total_tests}")
        print(f"Passed: {self.report.passed_tests}")
        print(f"Failed: {self.report.failed_tests}")
        print(f"\nIssues Severity:")
        print(f"  🔴 Critical: {self.report.critical_issues}")
        print(f"  🟠 Major: {self.report.major_issues}")
        print(f"  🟡 Minor: {self.report.minor_issues}")
        print(f"\nOverall Score: {self.report.overall_score:.1f}%")
        print(f"Confidence Level: {self.report.confidence_level}")
        
        # Show failed tests
        failed = [r for r in self.report.results if not r.passed]
        if failed:
            print(f"\n{'='*80}")
            print("FAILED TESTS")
            print("=" * 80)
            for result in failed:
                print(f"\n[{result.severity.upper()}] {result.test_name}")
                print(f"  Category: {result.category}")
                print(f"  Message: {result.message}")
                print(f"  Details: {result.details}")
        
        # Show recommendations
        print(f"\n{'='*80}")
        print("RECOMMENDATIONS")
        print("=" * 80)
        for rec in self.report.recommendations:
            print(rec)
        
        print("\n" + "=" * 80)
    
    def save_report(self, output_path: Path):
        """Save validation report to JSON"""
        report_data = {
            'tool_name': self.report.tool_name,
            'total_tests': self.report.total_tests,
            'passed_tests': self.report.passed_tests,
            'failed_tests': self.report.failed_tests,
            'critical_issues': self.report.critical_issues,
            'major_issues': self.report.major_issues,
            'minor_issues': self.report.minor_issues,
            'overall_score': self.report.overall_score,
            'confidence_level': self.report.confidence_level,
            'results': [
                {
                    'test_name': r.test_name,
                    'category': r.category,
                    'passed': r.passed,
                    'severity': r.severity,
                    'expected': r.expected,
                    'actual': r.actual,
                    'difference': r.difference,
                    'message': r.message,
                    'details': r.details
                }
                for r in self.report.results
            ],
            'recommendations': self.report.recommendations
        }
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(report_data, f, indent=2, ensure_ascii=False)
        
        print(f"\n✓ Report saved to: {output_path}")


def main():
    """Main validation function"""
    script_dir = Path(__file__).parent
    benchmark_dir = script_dir.parent
    chronos_dir = benchmark_dir.parent / "chronos-sta"
    
    validator = ChronosValidator(benchmark_dir, chronos_dir)
    report = validator.run_validation()
    validator.print_report()
    
    # Save report
    output_file = benchmark_dir / "reports" / "chronos_validation_report.json"
    validator.save_report(output_file)
    
    print(f"\n{'='*80}")
    print("✅ Validation Analysis Complete!")
    print("=" * 80)


if __name__ == "__main__":
    main()
