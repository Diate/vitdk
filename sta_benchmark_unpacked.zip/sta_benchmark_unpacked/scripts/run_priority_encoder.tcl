# ==============================================================================
# OpenSTA Benchmark Script - Priority Encoder
# Purpose: Test priority logic timing
# ==============================================================================

# Read Liberty file (TT corner)
read_liberty ../lib/simple_tt.lib

# Read Verilog netlist
read_verilog ../designs/medium/priority_encoder.v
link_design priority_encoder

# Read parasitics
read_spef ../spef/priority_encoder.spef

# Read constraints
read_sdc ../sdc/priority_encoder.sdc

# ==============================================================================
# Timing Analysis
# ==============================================================================

puts "=============================================="
puts "TIMING REPORT - priority_encoder (TT Corner)"
puts "=============================================="

# Report all paths with full details
report_checks -path_delay max -format full_clock_expanded

# Report worst paths
report_checks -path_delay max -group_count 15

# Report hold paths
report_checks -path_delay min -group_count 5

# ==============================================================================
# Priority Logic Analysis
# ==============================================================================
puts "\n=============================================="
puts "PRIORITY ENCODING PATHS"
puts "=============================================="

# Input to output paths
report_checks -from [get_ports REQ*] -to [get_ports GRANT*] -path_delay max -group_count 8

# Valid signal path
report_checks -to [get_ports VALID] -path_delay max -group_count 5

# ==============================================================================
# Logic Depth
# ==============================================================================
puts "\n=============================================="
puts "COMBINATIONAL LOGIC ANALYSIS"
puts "=============================================="

report_checks -path_delay max -fields {slew cap cell delay}

# ==============================================================================
# Export Results with Full Metrics
# ==============================================================================

set script_dir [file dirname [info script]]
set report_dir [file join $script_dir ".." "reports" "reports_OpenSTA"]
set report_file [file join $report_dir "priority_encoder_tt_opensta.rpt"]

file mkdir $report_dir

set redirect_file [file join $report_dir "priority_encoder_tt_full.txt"]
redirect -file $redirect_file {
    puts "=========================================================="
    puts "OpenSTA FULL Timing Analysis - priority_encoder (TT Corner)"
    puts "=========================================================="
    puts ""
    
    puts "\n=== WORST SLACK (SETUP) ==="
    report_worst_slack -max
    
    puts "\n=== WORST SLACK (HOLD) ==="
    report_worst_slack -min
    
    puts "\n=== DETAILED SETUP PATHS ==="
    report_checks -path_delay max -group_count 5 -format full_clock
    
    puts "\n=== DETAILED HOLD PATHS ==="
    report_checks -path_delay min -group_count 5 -format full_clock
    
    puts "\n=== TNS (Total Negative Slack) ==="
    report_tns
    
    puts "\n=== CHECK TYPES (Violations) ==="
    report_check_types -max_slew -max_capacitance -max_fanout -violators
    
    puts "\n=========================================================="
}

if {[catch {
    set fp [open $report_file w]

    puts $fp "=========================================================="
    puts $fp "OpenSTA Timing Report - priority_encoder (TT Corner)"
    puts $fp "=========================================================="
    puts $fp ""
    puts $fp "Design: priority_encoder"
    puts $fp "Corner: TT (1.1V, 25C)"
    puts $fp "Process: 45nm"
    puts $fp ""
    puts $fp "Full metrics exported to: priority_encoder_tt_full.txt"
    puts $fp "Clock Period: 10.0 ns (100 MHz)"
    puts $fp ""
    puts $fp "=========================================================="

    close $fp

    puts "\n=========================================================="
    puts "Summary: $report_file"
    puts "Full metrics: $redirect_file"
    puts "=========================================================="
} result]} {
    puts "Error writing report: $result"
}

exit
