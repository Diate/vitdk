# ==============================================================================
# SDC Constraints for priority_encoder
# Purpose: 8-to-3 priority encoder with MUX logic
# ==============================================================================

# Units
set_units -time ns -capacitance pF -resistance kOhm

# Create virtual clock
create_clock -name vclk -period 10.0

# Input driving cell
set_driving_cell -lib_cell BUF_X1 -pin Y [get_ports IN*]

# Input transitions
set_input_transition 0.05 [get_ports IN*]

# Output loads
set_load 0.012 [get_ports OUT*]
set_load 0.010 [get_ports VALID]

# Input/Output delays
set_input_delay -clock vclk -max 0.1 [get_ports IN*]
set_input_delay -clock vclk -min 0.05 [get_ports IN*]

set_output_delay -clock vclk -max 0.25 [get_ports OUT*]
set_output_delay -clock vclk -min 0.12 [get_ports OUT*]
set_output_delay -clock vclk -max 0.2 [get_ports VALID]
set_output_delay -clock vclk -min 0.1 [get_ports VALID]
