# ==============================================================================
# SDC Constraints for inv_chain
# Purpose: Test basic timing constraints on combinational path
# ==============================================================================

# Units
set_units -time ns -capacitance pF -resistance kOhm

# Create virtual clock for combinational path analysis
create_clock -name vclk -period 10.0

# Input driving cell
set_driving_cell -lib_cell BUF_X1 -pin Y [get_ports IN]

# Input transition (slew)
set_input_transition 0.05 [get_ports IN]

# Output load capacitance
set_load 0.010 [get_ports OUT]

# Input delay relative to virtual clock
set_input_delay -clock vclk -max 0.1 [get_ports IN]
set_input_delay -clock vclk -min 0.05 [get_ports IN]

# Output delay relative to virtual clock
set_output_delay -clock vclk -max 0.2 [get_ports OUT]
set_output_delay -clock vclk -min 0.1 [get_ports OUT]

# Max transition constraint
set_max_transition 0.3 [current_design]

# Max capacitance constraint
set_max_capacitance 0.05 [current_design]
