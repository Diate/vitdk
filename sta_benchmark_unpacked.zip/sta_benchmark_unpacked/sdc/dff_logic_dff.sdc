# ==============================================================================
# SDC Constraints for dff_logic_dff
# Purpose: Test setup/hold timing with register-to-register paths
# ==============================================================================

# Units
set_units -time ns -capacitance pF -resistance kOhm

# ==============================================================================
# Clock Definition
# ==============================================================================
# Main clock: 500 MHz (2ns period)
create_clock -name CLK -period 2.0 -waveform {0 1.0} [get_ports CLK]

# Clock uncertainty for setup (jitter + skew)
set_clock_uncertainty -setup 0.1 [get_clocks CLK]

# Clock uncertainty for hold
set_clock_uncertainty -hold 0.05 [get_clocks CLK]

# Clock transition
set_clock_transition 0.05 [get_clocks CLK]

# Clock latency (source + network)
set_clock_latency -source 0.1 [get_clocks CLK]
set_clock_latency 0.15 [get_clocks CLK]

# ==============================================================================
# Input Constraints
# ==============================================================================
# Input driving cells
set_driving_cell -lib_cell BUF_X1 -pin Y [get_ports D_IN]
set_driving_cell -lib_cell BUF_X1 -pin Y [get_ports RST_N]

# Input transition
set_input_transition 0.05 [get_ports D_IN]
set_input_transition 0.03 [get_ports RST_N]

# Input delay relative to clock
set_input_delay -clock CLK -max 0.5 [get_ports D_IN]
set_input_delay -clock CLK -min 0.1 [get_ports D_IN]

# Reset is asynchronous but constrain for recovery/removal
set_input_delay -clock CLK -max 0.3 [get_ports RST_N]
set_input_delay -clock CLK -min 0.05 [get_ports RST_N]

# ==============================================================================
# Output Constraints
# ==============================================================================
# Output load
set_load 0.020 [get_ports Q_OUT]

# Output delay relative to clock
set_output_delay -clock CLK -max 0.4 [get_ports Q_OUT]
set_output_delay -clock CLK -min 0.1 [get_ports Q_OUT]

# ==============================================================================
# Design Constraints
# ==============================================================================
# Max transition
set_max_transition 0.2 [current_design]

# Max capacitance
set_max_capacitance 0.05 [current_design]

# Max fanout
set_max_fanout 10 [current_design]

# ==============================================================================
# False Paths and Exceptions
# ==============================================================================
# Reset is asynchronous - set as false path for setup analysis
# set_false_path -from [get_ports RST_N] -to [get_pins */Q]
