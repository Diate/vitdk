# ==============================================================================
# SDC Constraints for adder_8bit
# Purpose: Test combinational timing with long carry chain
# ==============================================================================

# Units
set_units -time ns -capacitance pF -resistance kOhm

# ==============================================================================
# Virtual Clock (for pure combinational design)
# ==============================================================================
create_clock -name VCLK -period 5.0

# ==============================================================================
# Input Constraints
# ==============================================================================
# Driving cells
set_driving_cell -lib_cell BUF_X1 -pin Y [get_ports A[*]]
set_driving_cell -lib_cell BUF_X1 -pin Y [get_ports B[*]]
set_driving_cell -lib_cell BUF_X1 -pin Y [get_ports CIN]

# Input transitions
set_input_transition 0.05 [get_ports A[*]]
set_input_transition 0.05 [get_ports B[*]]
set_input_transition 0.04 [get_ports CIN]

# Input delays (relative to virtual clock)
set_input_delay -clock VCLK -max 1.0 [get_ports A[*]]
set_input_delay -clock VCLK -min 0.2 [get_ports A[*]]

set_input_delay -clock VCLK -max 1.0 [get_ports B[*]]
set_input_delay -clock VCLK -min 0.2 [get_ports B[*]]

# CIN might arrive later (from previous adder stage)
set_input_delay -clock VCLK -max 1.5 [get_ports CIN]
set_input_delay -clock VCLK -min 0.3 [get_ports CIN]

# ==============================================================================
# Output Constraints
# ==============================================================================
# Output loads
set_load 0.015 [get_ports SUM[*]]
set_load 0.020 [get_ports COUT]

# Output delays
set_output_delay -clock VCLK -max 1.0 [get_ports SUM[*]]
set_output_delay -clock VCLK -min 0.2 [get_ports SUM[*]]

# COUT is critical (feeds next stage)
set_output_delay -clock VCLK -max 0.8 [get_ports COUT]
set_output_delay -clock VCLK -min 0.15 [get_ports COUT]

# ==============================================================================
# Design Constraints
# ==============================================================================
set_max_transition 0.25 [current_design]
set_max_capacitance 0.04 [current_design]
set_max_fanout 8 [current_design]

# ==============================================================================
# Path Groups for Analysis
# ==============================================================================
# Critical path is carry chain
# group_path -name CARRY_CHAIN -from [get_ports CIN] -to [get_ports COUT]
# group_path -name DATA_PATH -from [get_ports A[*]] -to [get_ports SUM[*]]
