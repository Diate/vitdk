# ==============================================================================
# SDC Constraints for clock_tree
# Purpose: Test clock network timing and skew analysis
# ==============================================================================

# Units
set_units -time ns -capacitance pF -resistance kOhm

# ==============================================================================
# Clock Definition
# ==============================================================================
# Main clock: 1 GHz (1ns period)
create_clock -name CLK_IN -period 1.0 -waveform {0 0.5} [get_ports CLK_IN]

# Tight clock uncertainty for skew testing
set_clock_uncertainty -setup 0.05 [get_clocks CLK_IN]
set_clock_uncertainty -hold 0.02 [get_clocks CLK_IN]

# Clock transition at source
set_clock_transition 0.03 [get_clocks CLK_IN]

# Ideal clock latency (no latency - to see actual clock tree delays)
set_clock_latency -source 0 [get_clocks CLK_IN]

# ==============================================================================
# Input Constraints
# ==============================================================================
# Driving cells for data inputs
set_driving_cell -lib_cell CLKBUF_X1 -pin Z [get_ports D[*]]
set_driving_cell -lib_cell BUF_X1 -pin Y [get_ports RST_N]

# Input transitions
set_input_transition 0.02 [get_ports D[*]]
set_input_transition 0.02 [get_ports RST_N]

# Data input delays (tight for high frequency)
set_input_delay -clock CLK_IN -max 0.3 [get_ports D[*]]
set_input_delay -clock CLK_IN -min 0.05 [get_ports D[*]]

# Reset timing
set_input_delay -clock CLK_IN -max 0.2 [get_ports RST_N]
set_input_delay -clock CLK_IN -min 0.03 [get_ports RST_N]

# ==============================================================================
# Output Constraints
# ==============================================================================
# Output loads
set_load 0.015 [get_ports Q[*]]

# Output delays
set_output_delay -clock CLK_IN -max 0.25 [get_ports Q[*]]
set_output_delay -clock CLK_IN -min 0.05 [get_ports Q[*]]

# ==============================================================================
# Design Constraints
# ==============================================================================
# Tight transition for high speed
set_max_transition 0.1 [current_design]

# Max capacitance
set_max_capacitance 0.03 [current_design]

# ==============================================================================
# Clock Tree Specific Constraints
# ==============================================================================
# Don't touch clock buffers (ideal for analysis)
# set_dont_touch [get_cells CLKBUF_*]

# Report clock network separately
# set_propagated_clock [get_clocks CLK_IN]
