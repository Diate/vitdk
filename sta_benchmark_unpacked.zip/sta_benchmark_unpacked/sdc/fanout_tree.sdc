# ==============================================================================
# SDC Constraints for fanout_tree
# Purpose: Multi-fanout tree with capacitive loading
# ==============================================================================

# Units
set_units -time ns -capacitance pF -resistance kOhm

# Create virtual clock
create_clock -name vclk -period 10.0

# Input driving cell
set_driving_cell -lib_cell BUF_X1 -pin Y [get_ports IN]

# Input transition
set_input_transition 0.05 [get_ports IN]

# Output loads (multiple fanout)
set_load 0.010 [get_ports OUT0]
set_load 0.010 [get_ports OUT1]
set_load 0.010 [get_ports OUT2]
set_load 0.010 [get_ports OUT3]

# Input/Output delays
set_input_delay -clock vclk -max 0.1 [get_ports IN]
set_input_delay -clock vclk -min 0.05 [get_ports IN]

set_output_delay -clock vclk -max 0.2 [get_ports OUT*]
set_output_delay -clock vclk -min 0.1 [get_ports OUT*]
