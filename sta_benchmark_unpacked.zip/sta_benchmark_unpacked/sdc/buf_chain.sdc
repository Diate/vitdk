# ==============================================================================
# SDC Constraints for buf_chain
# Purpose: Test timing with positive unate path
# ==============================================================================

# Units
set_units -time ns -capacitance pF -resistance kOhm

# Input driving cell
set_driving_cell -lib_cell INV_X1 -pin Y [get_ports IN]

# Input transition
set_input_transition 0.04 [get_ports IN]

# Output load
set_load 0.015 [get_ports OUT]

# Input delay
set_input_delay -max 0.15 [get_ports IN]
set_input_delay -min 0.08 [get_ports IN]

# Output delay
set_output_delay -max 0.25 [get_ports OUT]
set_output_delay -min 0.12 [get_ports OUT]

# Max transition
set_max_transition 0.25 [current_design]

# Max fanout
set_max_fanout 8 [current_design]
