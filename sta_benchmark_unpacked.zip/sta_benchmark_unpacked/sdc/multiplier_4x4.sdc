# ==============================================================================
# SDC Constraints for multiplier_4x4
# Purpose: Array multiplier with complex multi-level logic
# ==============================================================================

# Units
set_units -time ns -capacitance pF -resistance kOhm

# Create virtual clock
create_clock -name vclk -period 10.0

# Input driving cells
set_driving_cell -lib_cell BUF_X1 -pin Y [get_ports A*]
set_driving_cell -lib_cell BUF_X1 -pin Y [get_ports B*]

# Input transitions
set_input_transition 0.05 [get_ports A*]
set_input_transition 0.05 [get_ports B*]

# Output loads
foreach_in_collection out [get_ports P*] {
    set_load 0.015 $out
}

# Input/Output delays
set_input_delay -clock vclk -max 0.1 [get_ports A*]
set_input_delay -clock vclk -min 0.05 [get_ports A*]
set_input_delay -clock vclk -max 0.1 [get_ports B*]
set_input_delay -clock vclk -min 0.05 [get_ports B*]

set_output_delay -clock vclk -max 0.3 [get_ports P*]
set_output_delay -clock vclk -min 0.15 [get_ports P*]

# Transition constraints
set_max_transition 0.3 [current_design]
