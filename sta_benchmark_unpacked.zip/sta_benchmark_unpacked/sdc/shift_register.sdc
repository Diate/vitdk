# ==============================================================================
# SDC Constraints for shift_register_4bit
# Purpose: Test sequential timing with MUX-based data paths
# ==============================================================================

# Units
set_units -time ns -capacitance pF -resistance kOhm

# ==============================================================================
# Clock Definition
# ==============================================================================
# Main clock: 250 MHz (4ns period)
create_clock -name CLK -period 4.0 -waveform {0 2.0} [get_ports CLK]

# Clock uncertainty
set_clock_uncertainty -setup 0.15 [get_clocks CLK]
set_clock_uncertainty -hold 0.08 [get_clocks CLK]

# Clock transition
set_clock_transition 0.06 [get_clocks CLK]

# Clock latency
set_clock_latency -source 0.1 [get_clocks CLK]
set_clock_latency 0.2 [get_clocks CLK]

# ==============================================================================
# Input Constraints
# ==============================================================================
# Driving cells
set_driving_cell -lib_cell BUF_X1 -pin Y [get_ports D[*]]
set_driving_cell -lib_cell BUF_X1 -pin Y [get_ports SHIFT_IN]
set_driving_cell -lib_cell BUF_X1 -pin Y [get_ports LOAD]
set_driving_cell -lib_cell BUF_X1 -pin Y [get_ports RST_N]

# Input transitions
set_input_transition 0.06 [get_ports D[*]]
set_input_transition 0.05 [get_ports SHIFT_IN]
set_input_transition 0.04 [get_ports LOAD]
set_input_transition 0.03 [get_ports RST_N]

# Input delays
set_input_delay -clock CLK -max 1.0 [get_ports D[*]]
set_input_delay -clock CLK -min 0.2 [get_ports D[*]]

set_input_delay -clock CLK -max 0.8 [get_ports SHIFT_IN]
set_input_delay -clock CLK -min 0.15 [get_ports SHIFT_IN]

# LOAD and RST_N are control signals - may have different timing
set_input_delay -clock CLK -max 0.5 [get_ports LOAD]
set_input_delay -clock CLK -min 0.1 [get_ports LOAD]

set_input_delay -clock CLK -max 0.4 [get_ports RST_N]
set_input_delay -clock CLK -min 0.08 [get_ports RST_N]

# ==============================================================================
# Output Constraints
# ==============================================================================
# Output loads
set_load 0.018 [get_ports Q[*]]
set_load 0.020 [get_ports SHIFT_OUT]

# Output delays
set_output_delay -clock CLK -max 0.8 [get_ports Q[*]]
set_output_delay -clock CLK -min 0.15 [get_ports Q[*]]

set_output_delay -clock CLK -max 0.6 [get_ports SHIFT_OUT]
set_output_delay -clock CLK -min 0.12 [get_ports SHIFT_OUT]

# ==============================================================================
# Design Constraints
# ==============================================================================
set_max_transition 0.2 [current_design]
set_max_capacitance 0.05 [current_design]
set_max_fanout 10 [current_design]

# ==============================================================================
# Multicycle Paths (if needed)
# ==============================================================================
# Example: If LOAD changes only every 2 cycles
# set_multicycle_path 2 -setup -from [get_ports LOAD]
# set_multicycle_path 1 -hold -from [get_ports LOAD]
