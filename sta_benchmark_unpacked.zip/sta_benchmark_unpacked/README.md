# STA Benchmark Sample Suite

Bộ benchmark mẫu để kiểm tra và so sánh công cụ STA (Static Timing Analysis) tự phát triển với OpenSTA.

## 📁 Cấu Trúc Thư Mục
