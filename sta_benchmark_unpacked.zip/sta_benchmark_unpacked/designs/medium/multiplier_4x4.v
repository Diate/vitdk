// ============================================================================
// Benchmark Design: 4x4 Multiplier (Array Multiplier)
// Purpose: Test complex timing through multi-level logic
// Contains multiple parallel and serial paths
// ============================================================================

module multiplier_4x4 (
    input  wire [3:0] A,
    input  wire [3:0] B,
    output wire [7:0] P
);

    // Partial products
    wire pp00, pp01, pp02, pp03;
    wire pp10, pp11, pp12, pp13;
    wire pp20, pp21, pp22, pp23;
    wire pp30, pp31, pp32, pp33;

    // Generate partial products (AND gates)
    AND2_X1 PP_00 (.A1(A[0]), .A2(B[0]), .ZN(pp00));
    AND2_X1 PP_01 (.A1(A[1]), .A2(B[0]), .ZN(pp01));
    AND2_X1 PP_02 (.A1(A[2]), .A2(B[0]), .ZN(pp02));
    AND2_X1 PP_03 (.A1(A[3]), .A2(B[0]), .ZN(pp03));

    AND2_X1 PP_10 (.A1(A[0]), .A2(B[1]), .ZN(pp10));
    AND2_X1 PP_11 (.A1(A[1]), .A2(B[1]), .ZN(pp11));
    AND2_X1 PP_12 (.A1(A[2]), .A2(B[1]), .ZN(pp12));
    AND2_X1 PP_13 (.A1(A[3]), .A2(B[1]), .ZN(pp13));

    AND2_X1 PP_20 (.A1(A[0]), .A2(B[2]), .ZN(pp20));
    AND2_X1 PP_21 (.A1(A[1]), .A2(B[2]), .ZN(pp21));
    AND2_X1 PP_22 (.A1(A[2]), .A2(B[2]), .ZN(pp22));
    AND2_X1 PP_23 (.A1(A[3]), .A2(B[2]), .ZN(pp23));

    AND2_X1 PP_30 (.A1(A[0]), .A2(B[3]), .ZN(pp30));
    AND2_X1 PP_31 (.A1(A[1]), .A2(B[3]), .ZN(pp31));
    AND2_X1 PP_32 (.A1(A[2]), .A2(B[3]), .ZN(pp32));
    AND2_X1 PP_33 (.A1(A[3]), .A2(B[3]), .ZN(pp33));

    // P[0] = pp00 (direct)
    BUF_X1 BUF_P0 (.A(pp00), .Y(P[0]));

    // Row 1 addition: pp01 + pp10
    wire s1_0, c1_0;
    wire xor_tmp1;
    XOR2_X1 XOR_R1_0 (.A(pp01), .B(pp10), .Z(s1_0));
    AND2_X1 AND_R1_0 (.A1(pp01), .A2(pp10), .ZN(c1_0));
    BUF_X1 BUF_P1 (.A(s1_0), .Y(P[1]));

    // Row 1 continuation: pp02 + pp11 + c1_0
    wire s1_1, c1_1_a, c1_1_b, c1_1;
    wire xor_tmp2;
    XOR2_X1 XOR_R1_1A (.A(pp02), .B(pp11), .Z(xor_tmp2));
    XOR2_X1 XOR_R1_1B (.A(xor_tmp2), .B(c1_0), .Z(s1_1));
    AND2_X1 AND_R1_1A (.A1(pp02), .A2(pp11), .ZN(c1_1_a));
    AND2_X1 AND_R1_1B (.A1(xor_tmp2), .A2(c1_0), .ZN(c1_1_b));
    OR2_X1 OR_R1_1 (.A1(c1_1_a), .A2(c1_1_b), .ZN(c1_1));

    // Row 1: pp03 + pp12 + c1_1
    wire s1_2, c1_2_a, c1_2_b, c1_2;
    wire xor_tmp3;
    XOR2_X1 XOR_R1_2A (.A(pp03), .B(pp12), .Z(xor_tmp3));
    XOR2_X1 XOR_R1_2B (.A(xor_tmp3), .B(c1_1), .Z(s1_2));
    AND2_X1 AND_R1_2A (.A1(pp03), .A2(pp12), .ZN(c1_2_a));
    AND2_X1 AND_R1_2B (.A1(xor_tmp3), .A2(c1_1), .ZN(c1_2_b));
    OR2_X1 OR_R1_2 (.A1(c1_2_a), .A2(c1_2_b), .ZN(c1_2));

    // Row 1: pp13 + c1_2
    wire s1_3, c1_3;
    XOR2_X1 XOR_R1_3 (.A(pp13), .B(c1_2), .Z(s1_3));
    AND2_X1 AND_R1_3 (.A1(pp13), .A2(c1_2), .ZN(c1_3));

    // Row 2: s1_1 + pp20
    wire s2_0, c2_0;
    XOR2_X1 XOR_R2_0 (.A(s1_1), .B(pp20), .Z(s2_0));
    AND2_X1 AND_R2_0 (.A1(s1_1), .A2(pp20), .ZN(c2_0));
    BUF_X1 BUF_P2 (.A(s2_0), .Y(P[2]));

    // Row 2: s1_2 + pp21 + c2_0
    wire s2_1, c2_1_a, c2_1_b, c2_1;
    wire xor_tmp4;
    XOR2_X1 XOR_R2_1A (.A(s1_2), .B(pp21), .Z(xor_tmp4));
    XOR2_X1 XOR_R2_1B (.A(xor_tmp4), .B(c2_0), .Z(s2_1));
    AND2_X1 AND_R2_1A (.A1(s1_2), .A2(pp21), .ZN(c2_1_a));
    AND2_X1 AND_R2_1B (.A1(xor_tmp4), .A2(c2_0), .ZN(c2_1_b));
    OR2_X1 OR_R2_1 (.A1(c2_1_a), .A2(c2_1_b), .ZN(c2_1));

    // Row 2: s1_3 + pp22 + c2_1
    wire s2_2, c2_2_a, c2_2_b, c2_2;
    wire xor_tmp5;
    XOR2_X1 XOR_R2_2A (.A(s1_3), .B(pp22), .Z(xor_tmp5));
    XOR2_X1 XOR_R2_2B (.A(xor_tmp5), .B(c2_1), .Z(s2_2));
    AND2_X1 AND_R2_2A (.A1(s1_3), .A2(pp22), .ZN(c2_2_a));
    AND2_X1 AND_R2_2B (.A1(xor_tmp5), .A2(c2_1), .ZN(c2_2_b));
    OR2_X1 OR_R2_2 (.A1(c2_2_a), .A2(c2_2_b), .ZN(c2_2));

    // Row 2: c1_3 + pp23 + c2_2
    wire s2_3, c2_3_a, c2_3_b, c2_3;
    wire xor_tmp6;
    XOR2_X1 XOR_R2_3A (.A(c1_3), .B(pp23), .Z(xor_tmp6));
    XOR2_X1 XOR_R2_3B (.A(xor_tmp6), .B(c2_2), .Z(s2_3));
    AND2_X1 AND_R2_3A (.A1(c1_3), .A2(pp23), .ZN(c2_3_a));
    AND2_X1 AND_R2_3B (.A1(xor_tmp6), .A2(c2_2), .ZN(c2_3_b));
    OR2_X1 OR_R2_3 (.A1(c2_3_a), .A2(c2_3_b), .ZN(c2_3));

    // Row 3: s2_1 + pp30
    wire s3_0, c3_0;
    XOR2_X1 XOR_R3_0 (.A(s2_1), .B(pp30), .Z(s3_0));
    AND2_X1 AND_R3_0 (.A1(s2_1), .A2(pp30), .ZN(c3_0));
    BUF_X1 BUF_P3 (.A(s3_0), .Y(P[3]));

    // Row 3: s2_2 + pp31 + c3_0
    wire s3_1, c3_1_a, c3_1_b, c3_1;
    wire xor_tmp7;
    XOR2_X1 XOR_R3_1A (.A(s2_2), .B(pp31), .Z(xor_tmp7));
    XOR2_X1 XOR_R3_1B (.A(xor_tmp7), .B(c3_0), .Z(s3_1));
    AND2_X1 AND_R3_1A (.A1(s2_2), .A2(pp31), .ZN(c3_1_a));
    AND2_X1 AND_R3_1B (.A1(xor_tmp7), .A2(c3_0), .ZN(c3_1_b));
    OR2_X1 OR_R3_1 (.A1(c3_1_a), .A2(c3_1_b), .ZN(c3_1));
    BUF_X1 BUF_P4 (.A(s3_1), .Y(P[4]));

    // Row 3: s2_3 + pp32 + c3_1
    wire s3_2, c3_2_a, c3_2_b, c3_2;
    wire xor_tmp8;
    XOR2_X1 XOR_R3_2A (.A(s2_3), .B(pp32), .Z(xor_tmp8));
    XOR2_X1 XOR_R3_2B (.A(xor_tmp8), .B(c3_1), .Z(s3_2));
    AND2_X1 AND_R3_2A (.A1(s2_3), .A2(pp32), .ZN(c3_2_a));
    AND2_X1 AND_R3_2B (.A1(xor_tmp8), .A2(c3_1), .ZN(c3_2_b));
    OR2_X1 OR_R3_2 (.A1(c3_2_a), .A2(c3_2_b), .ZN(c3_2));
    BUF_X1 BUF_P5 (.A(s3_2), .Y(P[5]));

    // Row 3: c2_3 + pp33 + c3_2
    wire s3_3, c3_3_a, c3_3_b, c3_3;
    wire xor_tmp9;
    XOR2_X1 XOR_R3_3A (.A(c2_3), .B(pp33), .Z(xor_tmp9));
    XOR2_X1 XOR_R3_3B (.A(xor_tmp9), .B(c3_2), .Z(s3_3));
    AND2_X1 AND_R3_3A (.A1(c2_3), .A2(pp33), .ZN(c3_3_a));
    AND2_X1 AND_R3_3B (.A1(xor_tmp9), .A2(c3_2), .ZN(c3_3_b));
    OR2_X1 OR_R3_3 (.A1(c3_3_a), .A2(c3_3_b), .ZN(c3_3));
    BUF_X1 BUF_P6 (.A(s3_3), .Y(P[6]));
    BUF_X1 BUF_P7 (.A(c3_3), .Y(P[7]));

endmodule
