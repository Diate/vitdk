// ============================================================================
// Benchmark Design: 4-bit Shift Register with Parallel Load
// Purpose: Test sequential timing with complex clock and data paths
// ============================================================================

module shift_register_4bit (
    input  wire CLK,
    input  wire RST_N,
    input  wire LOAD,      // 1 = parallel load, 0 = shift
    input  wire SHIFT_IN,  // Serial input for shift mode
    input  wire [3:0] D,   // Parallel data input
    output wire [3:0] Q,   // Parallel output
    output wire SHIFT_OUT  // Serial output
);

    wire [3:0] mux_out;
    wire [3:0] q_int;
    wire load_n;

    // Invert LOAD for shift mode selection
    INV_X1 INV_LOAD (.A(LOAD), .Y(load_n));

    // MUX for bit 0: select between D[0] (load) and SHIFT_IN (shift)
    MUX2_X1 MUX_D0 (.A(SHIFT_IN), .B(D[0]), .S(LOAD), .Z(mux_out[0]));

    // MUX for bit 1: select between D[1] (load) and Q[0] (shift)
    MUX2_X1 MUX_D1 (.A(q_int[0]), .B(D[1]), .S(LOAD), .Z(mux_out[1]));

    // MUX for bit 2: select between D[2] (load) and Q[1] (shift)
    MUX2_X1 MUX_D2 (.A(q_int[1]), .B(D[2]), .S(LOAD), .Z(mux_out[2]));

    // MUX for bit 3: select between D[3] (load) and Q[2] (shift)
    MUX2_X1 MUX_D3 (.A(q_int[2]), .B(D[3]), .S(LOAD), .Z(mux_out[3]));

    // Clock buffer
    wire clk_buf;
    CLKBUF_X1 CLKBUF_MAIN (.A(CLK), .Z(clk_buf));

    // Flip-flops
    DFFR_X1 FF0 (
        .CK(clk_buf),
        .RN(RST_N),
        .D(mux_out[0]),
        .Q(q_int[0]),
        .QN()
    );

    DFFR_X1 FF1 (
        .CK(clk_buf),
        .RN(RST_N),
        .D(mux_out[1]),
        .Q(q_int[1]),
        .QN()
    );

    DFFR_X1 FF2 (
        .CK(clk_buf),
        .RN(RST_N),
        .D(mux_out[2]),
        .Q(q_int[2]),
        .QN()
    );

    DFFR_X1 FF3 (
        .CK(clk_buf),
        .RN(RST_N),
        .D(mux_out[3]),
        .Q(q_int[3]),
        .QN()
    );

    // Output buffers
    BUF_X1 BUF_Q0 (.A(q_int[0]), .Y(Q[0]));
    BUF_X1 BUF_Q1 (.A(q_int[1]), .Y(Q[1]));
    BUF_X1 BUF_Q2 (.A(q_int[2]), .Y(Q[2]));
    BUF_X1 BUF_Q3 (.A(q_int[3]), .Y(Q[3]));
    BUF_X1 BUF_SO (.A(q_int[3]), .Y(SHIFT_OUT));

endmodule
