// ============================================================================
// Benchmark Design: 8-to-3 Priority Encoder
// Purpose: Test complex timing with MUX trees and priority logic
// ============================================================================

module priority_encoder_8to3 (
    input  wire [7:0] IN,
    input  wire EN,
    output wire [2:0] OUT,
    output wire VALID
);

    // Internal signals
    wire en_buf;
    wire [7:0] in_buf;
    wire any_high;

    // Input buffers
    BUF_X1 BUF_EN (.A(EN), .Y(en_buf));
    BUF_X1 BUF_IN0 (.A(IN[0]), .Y(in_buf[0]));
    BUF_X1 BUF_IN1 (.A(IN[1]), .Y(in_buf[1]));
    BUF_X1 BUF_IN2 (.A(IN[2]), .Y(in_buf[2]));
    BUF_X1 BUF_IN3 (.A(IN[3]), .Y(in_buf[3]));
    BUF_X1 BUF_IN4 (.A(IN[4]), .Y(in_buf[4]));
    BUF_X1 BUF_IN5 (.A(IN[5]), .Y(in_buf[5]));
    BUF_X1 BUF_IN6 (.A(IN[6]), .Y(in_buf[6]));
    BUF_X1 BUF_IN7 (.A(IN[7]), .Y(in_buf[7]));

    // Priority logic - higher index has higher priority
    // Compute inverse of inputs for masking
    wire [7:0] in_n;
    INV_X1 INV_IN0 (.A(in_buf[0]), .Y(in_n[0]));
    INV_X1 INV_IN1 (.A(in_buf[1]), .Y(in_n[1]));
    INV_X1 INV_IN2 (.A(in_buf[2]), .Y(in_n[2]));
    INV_X1 INV_IN3 (.A(in_buf[3]), .Y(in_n[3]));
    INV_X1 INV_IN4 (.A(in_buf[4]), .Y(in_n[4]));
    INV_X1 INV_IN5 (.A(in_buf[5]), .Y(in_n[5]));
    INV_X1 INV_IN6 (.A(in_buf[6]), .Y(in_n[6]));
    INV_X1 INV_IN7 (.A(in_buf[7]), .Y(in_n[7]));

    // OUT[2] = IN[7] | IN[6] | IN[5] | IN[4]
    wire or2_h0, or2_h1, out2_pre;
    OR2_X1 OR2_H0 (.A1(in_buf[7]), .A2(in_buf[6]), .ZN(or2_h0));
    OR2_X1 OR2_H1 (.A1(in_buf[5]), .A2(in_buf[4]), .ZN(or2_h1));
    OR2_X1 OR2_H2 (.A1(or2_h0), .A2(or2_h1), .ZN(out2_pre));

    // OUT[1] = IN[7] | IN[6] | (!IN[5] & !IN[4] & (IN[3] | IN[2]))
    wire or1_h, or1_l, and1_mask, and1_l, out1_pre;
    OR2_X1 OR1_H (.A1(in_buf[7]), .A2(in_buf[6]), .ZN(or1_h));
    OR2_X1 OR1_L (.A1(in_buf[3]), .A2(in_buf[2]), .ZN(or1_l));
    NAND2_X1 NAND1_MASK (.A1(in_n[5]), .A2(in_n[4]), .ZN(and1_mask));
    wire and1_mask_n;
    INV_X1 INV_MASK1 (.A(and1_mask), .Y(and1_mask_n));
    AND2_X1 AND1_L (.A1(and1_mask_n), .A2(or1_l), .ZN(and1_l));
    OR2_X1 OR1_OUT (.A1(or1_h), .A2(and1_l), .ZN(out1_pre));

    // OUT[0] - complex priority logic
    // OUT[0] = IN[7] | (!IN[6] & IN[5]) | (!IN[6] & !IN[5] & !IN[4] & IN[3]) |
    //          (!IN[6] & !IN[5] & !IN[4] & !IN[3] & !IN[2] & IN[1])

    wire term0_7;
    BUF_X1 BUF_T0_7 (.A(in_buf[7]), .Y(term0_7));

    wire term0_5;
    AND2_X1 AND_T0_5 (.A1(in_n[6]), .A2(in_buf[5]), .ZN(term0_5));

    wire and_654, term0_3;
    NAND2_X1 NAND_65 (.A1(in_n[6]), .A2(in_n[5]), .ZN(and_654));
    wire and_654_n;
    INV_X1 INV_654 (.A(and_654), .Y(and_654_n));
    wire and_654_4;
    AND2_X1 AND_654_4 (.A1(and_654_n), .A2(in_n[4]), .ZN(and_654_4));
    AND2_X1 AND_T0_3 (.A1(and_654_4), .A2(in_buf[3]), .ZN(term0_3));

    wire and_6543, and_65432, term0_1;
    AND2_X1 AND_6543 (.A1(and_654_4), .A2(in_n[3]), .ZN(and_6543));
    AND2_X1 AND_65432 (.A1(and_6543), .A2(in_n[2]), .ZN(and_65432));
    AND2_X1 AND_T0_1 (.A1(and_65432), .A2(in_buf[1]), .ZN(term0_1));

    wire or0_75, or0_753, out0_pre;
    OR2_X1 OR0_75 (.A1(term0_7), .A2(term0_5), .ZN(or0_75));
    OR2_X1 OR0_753 (.A1(or0_75), .A2(term0_3), .ZN(or0_753));
    OR2_X1 OR0_OUT (.A1(or0_753), .A2(term0_1), .ZN(out0_pre));

    // VALID = any input is high AND enable
    wire or_v0, or_v1, or_v2, any_input;
    OR2_X1 OR_V0 (.A1(in_buf[0]), .A2(in_buf[1]), .ZN(or_v0));
    OR2_X1 OR_V1 (.A1(in_buf[2]), .A2(in_buf[3]), .ZN(or_v1));
    OR2_X1 OR_V2 (.A1(in_buf[4]), .A2(in_buf[5]), .ZN(or_v2));
    wire or_v3, or_v4;
    OR2_X1 OR_V3 (.A1(in_buf[6]), .A2(in_buf[7]), .ZN(or_v3));
    OR2_X1 OR_V4 (.A1(or_v0), .A2(or_v1), .ZN(or_v4));
    wire or_v5, or_v6;
    OR2_X1 OR_V5 (.A1(or_v2), .A2(or_v3), .ZN(or_v5));
    OR2_X1 OR_V6 (.A1(or_v4), .A2(or_v5), .ZN(any_input));

    wire valid_pre;
    AND2_X1 AND_VALID (.A1(any_input), .A2(en_buf), .ZN(valid_pre));

    // Output gating with enable
    wire out0_gated, out1_gated, out2_gated;
    AND2_X1 AND_OUT0 (.A1(out0_pre), .A2(en_buf), .ZN(out0_gated));
    AND2_X1 AND_OUT1 (.A1(out1_pre), .A2(en_buf), .ZN(out1_gated));
    AND2_X1 AND_OUT2 (.A1(out2_pre), .A2(en_buf), .ZN(out2_gated));

    // Output buffers
    BUF_X1 BUF_OUT0 (.A(out0_gated), .Y(OUT[0]));
    BUF_X1 BUF_OUT1 (.A(out1_gated), .Y(OUT[1]));
    BUF_X1 BUF_OUT2 (.A(out2_gated), .Y(OUT[2]));
    BUF_X1 BUF_VALID (.A(valid_pre), .Y(VALID));

endmodule
