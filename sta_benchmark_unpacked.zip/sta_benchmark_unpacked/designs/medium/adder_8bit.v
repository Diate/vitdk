// ============================================================================
// Benchmark Design: 8-bit Ripple Carry Adder
// Purpose: Test timing through multi-stage combinational logic
// Critical path: Carry chain from LSB to MSB
// ============================================================================

module adder_8bit (
    input  wire [7:0] A,
    input  wire [7:0] B,
    input  wire CIN,
    output wire [7:0] SUM,
    output wire COUT
);

    wire [7:0] carry;
    wire [7:0] p, g;  // Propagate and Generate
    wire [7:0] sum_internal;

    // Full Adder bit 0
    XOR2_X1 XOR_P0 (.A(A[0]), .B(B[0]), .Z(p[0]));
    AND2_X1 AND_G0 (.A1(A[0]), .A2(B[0]), .ZN(g[0]));
    XOR2_X1 XOR_S0 (.A(p[0]), .B(CIN), .Z(sum_internal[0]));
    wire c0_and;
    AND2_X1 AND_C0 (.A1(p[0]), .A2(CIN), .ZN(c0_and));
    OR2_X1  OR_C0  (.A1(g[0]), .A2(c0_and), .ZN(carry[0]));

    // Full Adder bit 1
    XOR2_X1 XOR_P1 (.A(A[1]), .B(B[1]), .Z(p[1]));
    AND2_X1 AND_G1 (.A1(A[1]), .A2(B[1]), .ZN(g[1]));
    XOR2_X1 XOR_S1 (.A(p[1]), .B(carry[0]), .Z(sum_internal[1]));
    wire c1_and;
    AND2_X1 AND_C1 (.A1(p[1]), .A2(carry[0]), .ZN(c1_and));
    OR2_X1  OR_C1  (.A1(g[1]), .A2(c1_and), .ZN(carry[1]));

    // Full Adder bit 2
    XOR2_X1 XOR_P2 (.A(A[2]), .B(B[2]), .Z(p[2]));
    AND2_X1 AND_G2 (.A1(A[2]), .A2(B[2]), .ZN(g[2]));
    XOR2_X1 XOR_S2 (.A(p[2]), .B(carry[1]), .Z(sum_internal[2]));
    wire c2_and;
    AND2_X1 AND_C2 (.A1(p[2]), .A2(carry[1]), .ZN(c2_and));
    OR2_X1  OR_C2  (.A1(g[2]), .A2(c2_and), .ZN(carry[2]));

    // Full Adder bit 3
    XOR2_X1 XOR_P3 (.A(A[3]), .B(B[3]), .Z(p[3]));
    AND2_X1 AND_G3 (.A1(A[3]), .A2(B[3]), .ZN(g[3]));
    XOR2_X1 XOR_S3 (.A(p[3]), .B(carry[2]), .Z(sum_internal[3]));
    wire c3_and;
    AND2_X1 AND_C3 (.A1(p[3]), .A2(carry[2]), .ZN(c3_and));
    OR2_X1  OR_C3  (.A1(g[3]), .A2(c3_and), .ZN(carry[3]));

    // Full Adder bit 4
    XOR2_X1 XOR_P4 (.A(A[4]), .B(B[4]), .Z(p[4]));
    AND2_X1 AND_G4 (.A1(A[4]), .A2(B[4]), .ZN(g[4]));
    XOR2_X1 XOR_S4 (.A(p[4]), .B(carry[3]), .Z(sum_internal[4]));
    wire c4_and;
    AND2_X1 AND_C4 (.A1(p[4]), .A2(carry[3]), .ZN(c4_and));
    OR2_X1  OR_C4  (.A1(g[4]), .A2(c4_and), .ZN(carry[4]));

    // Full Adder bit 5
    XOR2_X1 XOR_P5 (.A(A[5]), .B(B[5]), .Z(p[5]));
    AND2_X1 AND_G5 (.A1(A[5]), .A2(B[5]), .ZN(g[5]));
    XOR2_X1 XOR_S5 (.A(p[5]), .B(carry[4]), .Z(sum_internal[5]));
    wire c5_and;
    AND2_X1 AND_C5 (.A1(p[5]), .A2(carry[4]), .ZN(c5_and));
    OR2_X1  OR_C5  (.A1(g[5]), .A2(c5_and), .ZN(carry[5]));

    // Full Adder bit 6
    XOR2_X1 XOR_P6 (.A(A[6]), .B(B[6]), .Z(p[6]));
    AND2_X1 AND_G6 (.A1(A[6]), .A2(B[6]), .ZN(g[6]));
    XOR2_X1 XOR_S6 (.A(p[6]), .B(carry[5]), .Z(sum_internal[6]));
    wire c6_and;
    AND2_X1 AND_C6 (.A1(p[6]), .A2(carry[5]), .ZN(c6_and));
    OR2_X1  OR_C6  (.A1(g[6]), .A2(c6_and), .ZN(carry[6]));

    // Full Adder bit 7
    XOR2_X1 XOR_P7 (.A(A[7]), .B(B[7]), .Z(p[7]));
    AND2_X1 AND_G7 (.A1(A[7]), .A2(B[7]), .ZN(g[7]));
    XOR2_X1 XOR_S7 (.A(p[7]), .B(carry[6]), .Z(sum_internal[7]));
    wire c7_and;
    AND2_X1 AND_C7 (.A1(p[7]), .A2(carry[6]), .ZN(c7_and));
    OR2_X1  OR_C7  (.A1(g[7]), .A2(c7_and), .ZN(carry[7]));

    // Output buffers
    BUF_X1 BUF_S0 (.A(sum_internal[0]), .Y(SUM[0]));
    BUF_X1 BUF_S1 (.A(sum_internal[1]), .Y(SUM[1]));
    BUF_X1 BUF_S2 (.A(sum_internal[2]), .Y(SUM[2]));
    BUF_X1 BUF_S3 (.A(sum_internal[3]), .Y(SUM[3]));
    BUF_X1 BUF_S4 (.A(sum_internal[4]), .Y(SUM[4]));
    BUF_X1 BUF_S5 (.A(sum_internal[5]), .Y(SUM[5]));
    BUF_X1 BUF_S6 (.A(sum_internal[6]), .Y(SUM[6]));
    BUF_X1 BUF_S7 (.A(sum_internal[7]), .Y(SUM[7]));
    BUF_X1 BUF_CO (.A(carry[7]), .Y(COUT));

endmodule
