// ============================================================================
// Benchmark Design: Multi-Fanout Tree
// Purpose: Test fanout handling and load capacitance effects
// One driver fans out to 8 loads at different levels
// ============================================================================

module fanout_tree (
    input  wire IN,
    output wire [7:0] OUT
);

    wire buf_out;
    wire level1_0, level1_1;
    wire level2_0, level2_1, level2_2, level2_3;

    // Root buffer driving large fanout
    BUF_X1 BUF_ROOT (.A(IN), .Y(buf_out));

    // Level 1: 2 buffers
    BUF_X1 BUF_L1_0 (.A(buf_out), .Y(level1_0));
    BUF_X1 BUF_L1_1 (.A(buf_out), .Y(level1_1));

    // Level 2: 4 buffers
    BUF_X1 BUF_L2_0 (.A(level1_0), .Y(level2_0));
    BUF_X1 BUF_L2_1 (.A(level1_0), .Y(level2_1));
    BUF_X1 BUF_L2_2 (.A(level1_1), .Y(level2_2));
    BUF_X1 BUF_L2_3 (.A(level1_1), .Y(level2_3));

    // Level 3: 8 inverters driving outputs
    INV_X1 INV_L3_0 (.A(level2_0), .Y(OUT[0]));
    INV_X1 INV_L3_1 (.A(level2_0), .Y(OUT[1]));
    INV_X1 INV_L3_2 (.A(level2_1), .Y(OUT[2]));
    INV_X1 INV_L3_3 (.A(level2_1), .Y(OUT[3]));
    INV_X1 INV_L3_4 (.A(level2_2), .Y(OUT[4]));
    INV_X1 INV_L3_5 (.A(level2_2), .Y(OUT[5]));
    INV_X1 INV_L3_6 (.A(level2_3), .Y(OUT[6]));
    INV_X1 INV_L3_7 (.A(level2_3), .Y(OUT[7]));

endmodule
