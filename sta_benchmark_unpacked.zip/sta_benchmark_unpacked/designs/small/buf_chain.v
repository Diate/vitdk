// ============================================================================
// Benchmark Design: Buffer Chain (10-stage)
// Purpose: Test delay accumulation with positive unate timing
// Path: IN -> BUF0 -> BUF1 -> ... -> BUF9 -> OUT
// ============================================================================

module buf_chain (
    input  wire IN,
    output wire OUT
);

    wire n1, n2, n3, n4, n5, n6, n7, n8, n9;

    BUF_X1 BUF0 (.A(IN), .Y(n1));
    BUF_X1 BUF1 (.A(n1), .Y(n2));
    BUF_X1 BUF2 (.A(n2), .Y(n3));
    BUF_X1 BUF3 (.A(n3), .Y(n4));
    BUF_X1 BUF4 (.A(n4), .Y(n5));
    BUF_X1 BUF5 (.A(n5), .Y(n6));
    BUF_X1 BUF6 (.A(n6), .Y(n7));
    BUF_X1 BUF7 (.A(n7), .Y(n8));
    BUF_X1 BUF8 (.A(n8), .Y(n9));
    BUF_X1 BUF9 (.A(n9), .Y(OUT));

endmodule
