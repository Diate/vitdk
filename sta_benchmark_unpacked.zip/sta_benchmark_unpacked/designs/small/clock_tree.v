// ============================================================================
// Benchmark Design: Clock Tree with Skew
// Purpose: Test clock network timing and skew analysis
// Clock distributed through different path lengths
// ============================================================================

module clock_tree (
    input  wire CLK_IN,
    input  wire RST_N,
    input  wire [3:0] D,
    output wire [3:0] Q
);

    wire clk_buf0, clk_buf1, clk_buf2;
    wire clk_ff0, clk_ff1, clk_ff2, clk_ff3;

    // Clock distribution tree with different path lengths
    // Main clock buffer
    CLKBUF_X1 CLKBUF_ROOT (.A(CLK_IN), .Z(clk_buf0));

    // Second level - asymmetric
    CLKBUF_X1 CLKBUF_L1_A (.A(clk_buf0), .Z(clk_buf1));
    CLKBUF_X1 CLKBUF_L1_B (.A(clk_buf0), .Z(clk_buf2));

    // Third level - different paths create skew
    CLKBUF_X1 CLKBUF_L2_0 (.A(clk_buf1), .Z(clk_ff0));  // Short path
    CLKBUF_X1 CLKBUF_L2_1_A (.A(clk_buf1), .Z(clk_ff1)); // Medium path
    CLKBUF_X1 CLKBUF_L2_2 (.A(clk_buf2), .Z(clk_ff2));  // Medium path

    // Extra buffer for skew testing
    wire clk_intermediate;
    CLKBUF_X1 CLKBUF_EXTRA (.A(clk_buf2), .Z(clk_intermediate));
    CLKBUF_X1 CLKBUF_L2_3 (.A(clk_intermediate), .Z(clk_ff3)); // Long path

    // Flip-flops with different clock arrival times
    DFFR_X1 FF0 (
        .CK(clk_ff0),
        .RN(RST_N),
        .D(D[0]),
        .Q(Q[0]),
        .QN()
    );

    DFFR_X1 FF1 (
        .CK(clk_ff1),
        .RN(RST_N),
        .D(D[1]),
        .Q(Q[1]),
        .QN()
    );

    DFFR_X1 FF2 (
        .CK(clk_ff2),
        .RN(RST_N),
        .D(D[2]),
        .Q(Q[2]),
        .QN()
    );

    DFFR_X1 FF3 (
        .CK(clk_ff3),
        .RN(RST_N),
        .D(D[3]),
        .Q(Q[3]),
        .QN()
    );

endmodule
