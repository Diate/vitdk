// ============================================================================
// Benchmark Design: Inverter Chain (10-stage)
// Purpose: Test basic delay path expansion and slew propagation
// Path: IN -> INV0 -> INV1 -> ... -> INV9 -> OUT
// ============================================================================

module inv_chain (
    input  wire IN,
    output wire OUT
);

    wire n1, n2, n3, n4, n5, n6, n7, n8, n9;

    INV_X1 INV0 (.A(IN), .Y(n1));
    INV_X1 INV1 (.A(n1), .Y(n2));
    INV_X1 INV2 (.A(n2), .Y(n3));
    INV_X1 INV3 (.A(n3), .Y(n4));
    INV_X1 INV4 (.A(n4), .Y(n5));
    INV_X1 INV5 (.A(n5), .Y(n6));
    INV_X1 INV6 (.A(n6), .Y(n7));
    INV_X1 INV7 (.A(n7), .Y(n8));
    INV_X1 INV8 (.A(n8), .Y(n9));
    INV_X1 INV9 (.A(n9), .Y(OUT));

endmodule
