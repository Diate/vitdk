// ============================================================================
// Benchmark Design: DFF to Logic to DFF
// Purpose: Test setup/hold timing constraints and reg-to-reg paths
// Path: D_IN -> DFF1/Q -> LOGIC -> DFF2/D
// ============================================================================

module dff_logic_dff (
    input  wire CLK,
    input  wire RST_N,
    input  wire D_IN,
    output wire Q_OUT
);

    wire q1, n1, n2, n3, n4, d2;

    // First DFF - input capture
    DFFR_X1 DFF1 (
        .CK(CLK),
        .RN(RST_N),
        .D(D_IN),
        .Q(q1),
        .QN()
    );

    // Combinational logic path
    INV_X1  INV1  (.A(q1), .Y(n1));
    NAND2_X1 NAND1 (.A1(q1), .A2(n1), .ZN(n2));
    NOR2_X1  NOR1  (.A1(n1), .A2(n2), .ZN(n3));
    AND2_X1  AND1  (.A1(n2), .A2(n3), .ZN(n4));
    OR2_X1   OR1   (.A1(n3), .A2(n4), .ZN(d2));

    // Second DFF - output register
    DFFR_X1 DFF2 (
        .CK(CLK),
        .RN(RST_N),
        .D(d2),
        .Q(Q_OUT),
        .QN()
    );

endmodule
